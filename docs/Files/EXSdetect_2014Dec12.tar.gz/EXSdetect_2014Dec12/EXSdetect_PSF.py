import numpy as np
import pyfits as pf
import sys
color = lambda s,ncolor,nfont: "\033["+str(nfont)+";"+str(ncolor)+"m"+s+"\033[0m"
class PSF(object):
	debug = False
	specialtry=False
	def __init__(self,**kwargs):#{{{
		if PSF.debug: print 'Prepare PSF'
		self.Instrum = kwargs.pop('Instrument','SWIFT')
		self.CoreRad = kwargs.pop('CoreRadius',5)
		self.PixSize = kwargs.pop('PixSize',None)
		self.Npsf = 50 #max psf size
		self.Indi = np.indices((self.Npsf*2+1,self.Npsf*2+1))-self.Npsf
		self.Radi = np.sqrt(self.Indi[0]**2+self.Indi[1]**2)
		ImageFile = kwargs.pop('ImageFile',None)
		if self.Instrum == 'SWIFT':
			self.ConsPSF = True #PSF is constant across the field
			#SWIFT XRT PSF
			#rc=5.3arcsec  5.3/2.36 = 2.245762711864407
			#beta=0.67     0.67*3-0.5 = 1.51
			self.rc2 = 5.04345 #in unit of pixel size
			if PSF.specialtry: self.rc2 /= 4.
			self.beta=1.51
			#King = lambda r: (1+r**2/self.rc2)**(-self.beta)
			King2pr = lambda r: (1+r**2/self.rc2)**(-self.beta)*r*2*np.pi #King function * 2 pi r, integrable
			inverKing = lambda f: np.sqrt(self.rc2*(f**(-1/self.beta)-1))
			inteKing2pr = lambda r: np.pi*self.rc2/(1-self.beta)*((1+r**2/self.rc2)**(1-self.beta)-1)
			inverinteKing2pr = lambda F: np.sqrt(self.rc2*((1-F)**(1/(1-self.beta))-1)) #inverse of normalized cummulative function
			self.CoreInte = inteKing2pr(np.sqrt((self.Radi<=self.CoreRad).sum()/np.pi))
		elif self.Instrum == 'CHANDRA':
			self.ConsPSF = False
			self.keV = 1.5
			try:
				if PSF.debug: print 'Load CIAO tasks'
				if os.path.isfile('psf.py') or os.path.isfile('psf.pyc'):
					print 'ERROR: psf.py or psf.pyc exists, please rename'
				from ciao_contrib.runtool import calquiz
				#from ciao_contrib.runtool import dmcoords
				#from pycrates import read_file,get_transform
				import psf as ChandraPSF
				self.ChandraPSF = ChandraPSF
			except:
				sys.exit('ERROR: Failed to load CIAO tasks')
			try:
				calquiz(telescope="CHANDRA", product="REEF")
				self.ChandraPData = self.ChandraPSF.psfInit(calquiz.outfile)
			except:
				print 'ERROR: CIAO failed'
				raise
			self.RA_NOM, self.DEC_NOM, self.ROLL_NOM, self.LTV1, self.LTV2, self.CDELT1, self.CDELT2, self.CDELT1P, self.CDELT2P, NAXIS1, NAXIS2 = \
				PSF.getHeader(ImageFile,'RA_NOM','DEC_NOM','ROLL_NOM','LTV1','LTV2','CDELT1','CDELT2','CDELT1P','CDELT2P','NAXIS1','NAXIS2')
			if self.CDELT1P>1 or self.CDELT2P>1: print color('Warning: This image is binned (%d,%d)' % (self.CDELT1P,self.CDELT2P),31,1)

			if self.PixSize is None:
				self.PixSize = abs(np.float32(self.CDELT1))*3600 #in unit of arcsec
				if round(self.PixSize,8)!=round(abs(np.float32(self.CDELT2))*3600,8): sys.exit('ERROR: why CDELT1!=CDELT2 in the header')
			assert self.PixSize >= 0, 'ERROR: Can not find CDELT1 key from the header, please specify --pixelsize'
			self.PhyCenter=[4096.5,4096.5] #For Chandra, RA_NOM,DEC_NOM generally <=> physical(4096.5,4096.5)
			Xctr,Yctr = (NAXIS2-1.)/2.,(NAXIS1-1.)/2.
			Ximg,Yimg = self.PhyCenter[1]/self.CDELT2P+self.LTV2-1, self.PhyCenter[0]/self.CDELT1P+self.LTV1-1
			print 'Aiming Point (%.1f,%.1f) %.1f pixels away from Image Center (%.1f,%.1f)' %(Yimg+1,Ximg+1,np.sqrt((Ximg-Xctr)**2+(Yimg-Yctr)**2),Yctr+1,Xctr+1)

		elif self.Instrum == 'WFXT':
			self.ConsPSF = False #PSF varies with off-axis angle
			if self.PixSize is None: sys.exit('ERROR: for WFXT, Pixel Size is needed')
			WFXT_enf = np.loadtxt(os.path.dirname(sys.argv[0])+'/wfxt_psf.dat')
			self.CoreInte = WFXT_enf[:,1]
			self.WFXT_psf = np.float32(pf.getdata(os.path.dirname(sys.argv[0])+'/wfxt_psf.fits'))
			if (np.array(self.WFXT_psf.names)!=np.array(["%02d" % x for x in WFXT_enf[:,0]])).any(): sys.exit('ERROR: WFXT psf columns not match')
			self.WFXT_psf = [self.WFXT_psf.field(name) for name in self.WFXT_psf.names]
		if PSF.debug: print 'Pixel Scale:', self.PixSize
		if PSF.debug: print 'Core Radius:', self.CoreRad
#}}}
	def Img2Pos(self,XYimg,verbose=0):#{{{
		Img2Sky = lambda Ximg,Yimg: ((Yimg+1-self.LTV1)*self.CDELT1P,(Ximg+1-self.LTV2)*self.CDELT2P)
		Xi,Yi = XYimg
		Xs,Ys = Img2Sky(Xi,Yi) #X,Y sky (physical)
		Phi = np.arctan2((Ys-self.PhyCenter[0]),(Xs-self.PhyCenter[1]))*180/np.pi + self.ROLL_NOM #in degree
		#Phi[Phi>360]-=360
		if Phi>360: Phi-=360
		Theta = np.sqrt((Xs-self.PhyCenter[0])**2+(Ys-self.PhyCenter[1])**2)*self.PixSize/60 #in arcmin
		if verbose>0: print 'Img',Xi,Yi,'Phy',Xs,Ys,'Off',Theta,Phi
		return Theta,Phi
#}}}
	def getflux(self,Radius=None,CoreCts=None,offaxis=None,Npsf=0,verbose=0):#{{{
		'''
		Return the flux (Cts/pixel) at given "Radius" of the PSF normalized to "CoreCts"
		PSF profile								--	Observed Source
		CoreInte: integrate within core radius	--	Core Count
		Radius ->
		PSFvalue: value on this profile			->	Flux

		Attention:
		PSF interpolation
		Be care of the first bin, which should be the highest but may be 0 due to badly-chosen bins.
		It makes the interpolation much more curvely than expected.
		The monotonicity of the PSF should be preserved.
		'''
		if self.Instrum == 'SWIFT':
			#Here Radius can be one value or an array
			if Radius is None:
				if Npsf==0: sys.exit('ERROR: Npsf==0')
				if Npsf>self.Npsf:
					self.Npsf = Npsf #max psf size
					self.Indi = np.indices((self.Npsf*2+1,self.Npsf*2+1))-self.Npsf
					self.Radi = np.sqrt(self.Indi[0]**2+self.Indi[1]**2)
				Radius = self.Radi[self.Npsf-Npsf:self.Npsf+Npsf+1,self.Npsf-Npsf:self.Npsf+Npsf+1]
			King = lambda r: (1+r**2/self.rc2)**(-self.beta)
			if CoreCts is None: return King(Radius)
			else:
				return King(Radius) * CoreCts / self.CoreInte
		elif self.Instrum == 'CHANDRA':
			assert len(offaxis)==2
			if getattr(np,'unique1d',None) is None:
				unique = np.unique
			else:
				unique = np.unique1d
			theta,phi = self.Img2Pos(offaxis,verbose=verbose)
			if Radius is None:
				assert Npsf>0 #input
				if Npsf>self.Npsf:
					self.Npsf = Npsf #max psf size
					self.Indi = np.indices((Npsf*2+1,Npsf*2+1))-Npsf
					self.Radi = np.sqrt(d[0]**2+d[1]**2)
				Radius = self.Radi[self.Npsf-Npsf:self.Npsf+Npsf+1,self.Npsf-Npsf:self.Npsf+Npsf+1] #radius matric
				D,I = unique(Radius.ravel(),return_inverse=True) #radius list and the mapper back to matrix
				i = np.arange(D.size)[I].reshape((Npsf*2+1,Npsf*2+1)) #mapper from matrix to list
				A = np.array([(i==n).sum() for n in np.arange(D.size)]) #area list
				F = np.zeros_like(D) #frac list
				Dc = np.sqrt(A.cumsum()/np.pi) #According Circle Distances list
				N = np.argwhere(D==Npsf)
				#assert N.size==1
				N = N[0,0]+1
				for n in np.arange(N):
					F[n+1] = self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize*Dc[n])
				F[:-1] = np.diff(F)
				F[N:] = 0
				F /= A
				F = F[i]
				#assert np.round(F.sum(),5) == np.round(self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize*Dc[N-1]),5)
			elif np.ndim(Radius)==0:
				Radius=np.float32(Radius)
				if Radius>0.3:
					d1=Radius-0.2
					d2=Radius+0.2-0.04/Radius
					F = ( self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize*d2) - self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize*d1) ) /np.pi /(d2**2-d1**2)
				else:
					F = self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize*0.3) /np.pi /0.09
			else:
				Radius=np.float32(Radius)
				F=Radius.flatten()
				for n in np.arange(F.size):
					if F[n]>0.3:
						d1=F[n]-0.2
						d2=F[n]+0.2-0.04/F[n]
						F[n] = ( self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize*d2) - self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize*d1) ) /np.pi /(d2**2-d1**2)
					else:
						F[n] = self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize*0.3) /np.pi /0.09
				F = F.reshape(Radius.shape)
				#print CoreCts,self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize*self.CoreRad) , self.keV, theta, phi, self.PixSize*self.CoreRad
			if CoreCts is None: return F
			else:
				return F * CoreCts / self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize*self.CoreRad)
		elif self.Instrum == 'WFXT':
			if offaxis is None: sys.exit('ERROR: WFXT PSF varies across the field')
			#input offaxis in unit of pixel size
			#convert into index of the list of PSF profiles
			Noffaxis = np.int32(offaxis*self.PixSize/180.+0.5) #3 arcmin step
			psf = self.WFXT_psf[Noffaxis]
			x = np.arange(psf.size)
			for n in x:
				if psf[n]>0: break
			x = x[n:]
			psf = psf[n:]
			profile = ip.interp1d(x,psf,kind='cubic')
			if np.any(Radius<profile.x.min()): sys.exit('ERROR: can not calculate PSF <%.1f' %(profile.x.min()))
			p = np.zeros_like(Radius)
			p[Radius<profile.x.max()] = profile(Radius[Radius<profile.x.max()])
			p[Radius>=profile.x.max()] = 0
			return p * CoreCts / self.CoreInte[Noffaxis]
#}}}
	def fluxwhere(self,Flux,CoreCts,offaxis=None,verbose=0):#{{{
		'''
		Return the radius where the "CoreCts" normalized PSF equals the "Flux".
		PSF profile								--	Observed Source
		CoreInte: integrate within core radius	--	Core Count
		PSFvalue: value on this profile			<-	Flux
		-> Radius
		'''
		MinRad = 0.5
		MaxRad = 200
		if self.Instrum == 'SWIFT':
			inverKing = lambda f: np.sqrt(self.rc2*(f**(-1/self.beta)-1))
			PSFvalue = Flux * self.CoreInte/CoreCts
			if PSFvalue>=0.9:
				#print 'Warning: Very Small Point Source'
				rad = MinRad
			else: rad = inverKing(PSFvalue)
			if rad<MinRad: rad=MinRad
			if rad>min(self.Npsf,MaxRad):
				print 'Warning: Very Large Point Source radius > %d, CoreCts %d' %(min(self.Npsf,MaxRad),CoreCts)
				#rad=self.Npsf #No, this size is useful (to compare with FoF region)
			if rad>MaxRad:
				rad=MaxRad
			return rad
		elif self.Instrum == 'CHANDRA':
			assert len(offaxis)==2
			theta,phi = self.Img2Pos(offaxis)
			CoreInte = self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize* np.sqrt((self.Radi<=self.CoreRad).sum()/np.pi))
			PSFvalue = Flux * CoreInte/CoreCts
			if verbose>0: print PSFvalue,Flux,CoreInte,CoreCts
			Rlast = 900. #a very large value
			Flast = 0.
			for D in np.arange(MinRad+0.25,self.Npsf+0.1,0.5):
				F = self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize*D)
				Res = abs( (F-Flast)/np.pi/(D**2-(D-0.5)**2) - PSFvalue )
				if verbose>0: print D,F,Res
				if D>2 and Res>Rlast: return D-0.75 #center of the last ring
				Rlast,Flast = Res,F
			return D-0.75

		elif self.Instrum == 'WFXT':
			if offaxis is None: sys.exit('ERROR: WFXT PSF varies across the field')
			#input offaxis in unit of pixel size
			#convert into index of the list of PSF profiles
			Noffaxis = np.int32(offaxis*self.PixSize/180.+0.5) #3 arcmin step
			psf = self.WFXT_psf[Noffaxis]
			PSFvalue = Flux * self.CoreInte[Noffaxis] / CoreCts
			rad = np.argwhere(psf>PSFvalue).max()
			if rad<MinRad: rad=MinRad
			if rad>self.Npsf:
				#print 'Warning: Very Large Point Source radius > %d' %(self.Npsf)
				rad=self.Npsf
			return rad
#}}}
	def getradius(self,Frac,offaxis=None):#{{{
		#get the radius (in unit of pixel) according to the input encircled energy fraction
		assert Frac<1
		if Frac<=0: return 0
		if self.Instrum == 'SWIFT':
			inverinteKing2pr = lambda F: np.sqrt(self.rc2*((1-F)**(1/(1-self.beta))-1)) #inverse of normalized cummulative function
			return inverinteKing2pr(Frac)
		elif self.Instrum == 'CHANDRA':
			assert len(offaxis)==2
			theta,phi = self.Img2Pos(offaxis)
			return self.ChandraPSF.psfSize(self.ChandraPData, self.keV, theta, phi, Frac)/self.PixSize
	def getfraction(self,Rad,offaxis=None):
		#get encircled energy fraction according to the input radius (in unit of pixel)
		assert Rad>0 and Rad<200
		if self.Instrum == 'SWIFT':
			inteKing2pr = lambda r: np.pi*self.rc2/(1-self.beta)*((1+r**2/self.rc2)**(1-self.beta)-1)
			return inteKing2pr(Rad) / (np.pi*self.rc2/(self.beta-1))
		elif self.Instrum == 'CHANDRA':
			assert len(offaxis)==2
			theta,phi = self.Img2Pos(offaxis)
			return self.ChandraPSF.psfFrac(self.ChandraPData, self.keV, theta, phi, self.PixSize* Rad)

	@staticmethod#}}}
	def getHeader(*argv,**kwargs):#{{{
		Print = kwargs.pop('Print',False)
		try:
			if int(pf.__version__.split('.')[0]) <= 1:
				Fits = pf.open(argv[0])
			else:
				Fits = pf.open(argv[0],ignore_missing_end=True)
		except:
			sys.exit('ERROR: Failed reading the fits file!')
		else:
			if len(argv)==1:
				if Print:
					for Hdu in Fits: print Hdu.header
			elif len(argv)==2:
				for Hdu in Fits:
					Value = Hdu.header.get(argv[1])
					if Value is None: continue
					else:
						if Print: print Value
						return Value
				sys.exit("ERROR: "+argv[1]+" not found in header")
			else:
				Values=[]
				for Key in argv[1:]:
					for Hdu in Fits:
						Value = Hdu.header.get(Key)
						if Value is None: continue
						else:
							if Print: print Value
							Values.append(Value)
							break
					if Value is None:
						print "ERROR: "+Key+" not found in header"
						Values.append(None)
				return Values#}}}
	def InteInside(self,r):
		if self.Instrum == 'SWIFT':
			inteKing2pr = lambda r: np.pi*self.rc2/(1-self.beta)*((1+r**2/self.rc2)**(1-self.beta)-1)
			return inteKing2pr(r)
