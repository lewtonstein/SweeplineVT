This is an example from SXCS. "i.fits" is the image file, and "e.fits" is the exposure map. Just run:
EXSdetect_Swift i.fits -e e.fits
