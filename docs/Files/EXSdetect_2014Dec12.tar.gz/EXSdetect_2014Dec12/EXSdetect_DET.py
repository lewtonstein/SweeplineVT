import numpy as np
import pyfits as pf
from tempfile import NamedTemporaryFile
import scipy.interpolate as ip
from scipy.signal import convolve
from scipy.ndimage import interpolation
import itertools
from EXSdetect_SrcList import SrcList
from EXSdetect_FOF import Percolate
color = lambda s,ncolor,nfont: "\033["+str(nfont)+";"+str(ncolor)+"m"+s+"\033[0m"
import re
grep = lambda string,slist: filter(re.compile(string).search, slist)
import os,cPickle,time,sys
class DET(object):
	Version = 'Unknown'
	debug = False
	developing= False
	General = False
	def __init__(self,img,ExpMap,**kwargs):
		if DET.debug: startinit=time.time()
		#self.MinCoreCts = kwargs.pop('MinCoreCts',0)
		self.CtrLevel = kwargs.pop('CtrLevel',10)
		self.src = kwargs.pop('SrcList',None)
		self.SepExt = kwargs.pop('SepExt',False)
		self.ModiExtSrc = kwargs.pop('ModiExtSrc',True) or self.SepExt
		self.OptimizeCore = kwargs.pop('OptimizeCore',False)
		self.ExtLowDist = kwargs.pop('ExtLowDist',10)
		self.ExtSepLevel = kwargs.pop('ExtSepLevel',2)
		self.ReliProbLowr = kwargs.pop('ReliProbLowr',20)
		self.OverFlowLevel = kwargs.pop('OverFlowLevel',2)
		self.FileName = kwargs.pop('FileName','FileName')
		self.VorFile = kwargs.pop('VorFile',None)
		self.PSF = kwargs.pop('PSF',None)
		self.OutFile = kwargs.pop('OutFile','OutFile')
		self.InputPntSrc = kwargs.pop('InputPntSrc',None)
		self.InputExtSrc = kwargs.pop('InputExtSrc',None)
		self.Hdr = kwargs.pop('Hdr',pf.Header())
		self.LnkScal2 = kwargs.pop('LnkScal2',1) #only used in case of DET.General
		BkgMap = kwargs.pop('BkgMap',None)
		self.Bkg = kwargs.pop('Bkg',None)
		self.PixNum2CalCenter = kwargs.pop('PixNum2CalCenter',27)
		self.MinAreaSeparated = kwargs.pop('MinAreaSeparated',3)
		self.EmpInside = kwargs.pop('FillEmptyHoles',False)
		self.CutLines = kwargs.pop('CutLines',None)
		self.OutPutPolygon = kwargs.pop('OutPutPolygon',True)
		self.fitsmask = kwargs.pop('OutPutFitsMask',True)
		if not DET.General:
			if self.PSF is None: sys.exit('ERROR: PSF needed')
			self.PSFTEW = self.PSF.CoreRad #<PSFHEW
		self.TmpFile = {}
		self.Nfull=None
		self.PsfBox=None
		self.IndD=None
		if self.SepExt:
			print color("Blended Extended Sources will be separated",34,1)
		else: print color("Blended Extended Sources will not be separated",34,1)

		VorFile = np.load(self.VorFile)
		vmap = VorFile['vmap']
		Amap = VorFile['Amap']
		vdmap = VorFile['dmap']
		EgPt = VorFile['EgPt']
		del VorFile

		self.Cmap = np.float32(img) #Count Map (Original image)
		if ExpMap is None:
			#self.Exp = None
			self.Exp = np.ones_like(self.Cmap)
		else:
			self.Exp = np.float32(pf.getdata(ExpMap))
			self.Cmap[self.Exp<=0] = 0
			vmap[self.Exp<=0] = 0
			MinExp = kwargs.pop('MinExp',None)
			if MinExp is not None and self.Exp.max()>20*MinExp:
				print color('Warning: %d out of %d pixels ignored because exposure time <%d' % (np.sum((self.Exp>0)&(self.Exp<MinExp)),np.sum(self.Exp>0),MinExp),31,1)
				self.Exp[self.Exp<MinExp] = 0

		################################################################################
		#check consistency
		assert self.Exp.shape == self.Cmap.shape, 'ERROR: Exposure Map and Image file have different shape!'
		if self.Cmap[self.Cmap<0].sum() > -0.01: self.Cmap[self.Cmap<0]=0 #just in particular case
		self.Px = np.zeros((self.Cmap>0).sum()+1,dtype='int32')
		self.Py = self.Px.copy()
		self.Py[1:],self.Px[1:] = np.where(self.Cmap.T>0)
		assert vmap.shape==self.Cmap.shape and (vmap[self.Px[1:],self.Py[1:]]==np.arange(1,(self.Cmap>0).sum()+1)).all(), \
			'ERROR: Voronoi Diragram not consistent with image'

		################################################################################
		self.TmpFile_new('vdmap',vdmap)
		self.dmap = np.zeros_like(self.Cmap) #Count Density, the image we use
		self.dmap[self.Px[1:],self.Py[1:]] = vdmap[self.Px[1:],self.Py[1:]]
		for N in EgPt: self.dmap[self.Px[N],self.Py[N]] = 0 # This sentence is added after Version 3.1, July 1, 2014
		if DET.debug: pf.writeto('density.fits',self.dmap,clobber=True)
		if DET.debug: pf.writeto('vdensity.fits',vdmap,clobber=True)

		################################################################################
		#MakeGraphAdjacency Part I
		PPdis = np.load(self.VorFile)['PPdis']**2 #square, to compare with Lmap
		Esid = np.load(self.VorFile)['Esid']
		assert PPdis.size==Esid.shape[0]
		site = np.zeros((Esid.shape[0],2),dtype='int32')
		site[:,0] = vmap[Esid[:,0],Esid[:,1]]
		site[:,1] = vmap[Esid[:,2],Esid[:,3]]
		Xpos = np.int32((Esid[:,0]+Esid[:,2])/2.+0.5)
		Ypos = np.int32((Esid[:,1]+Esid[:,3])/2.+0.5)
		Adj = [[] for _ in itertools.repeat(None,vmap.max()+1)]
		for n1,n2 in site:
			Adj[n1].append(n2)
			Adj[n2].append(n1)
		self.TmpFile_new('Oadj',Adj)
		del Esid
		################################################################################
		try:
			#assert False
			if BkgMap is None: BkgMap = self.FileName+'BkgMap.fits'
			self.Bkg = np.float32(pf.getdata(BkgMap))
			print color("<< "+BkgMap,34,1)
		except:
			self.MakeBkgMap(**kwargs)
		#exit()

		if DET.General:
			Lmap = np.zeros(self.Cmap.shape,dtype='float32')+self.LnkScal2
		else:
			Lmap = np.zeros(self.Cmap.shape,dtype='float32')
			Lmap[self.Bkg>0] = 1./self.Bkg[self.Bkg>0]
			Lmap[self.Bkg<=0] = Lmap[self.Bkg>0].mean()
			#if DET.debug: pf.writeto('lmap0.fits',Lmap,clobber=True)

			if Lmap.max()-Lmap[Lmap>0].min()>1: #do quick smooth with my approximate method
				x,y = np.indices(Lmap.shape)
				x,y = x.ravel(),y.ravel()
				A,bx,by=np.histogram2d(x,y,bins=[np.arange(-0.5,Lmap.shape[0],7),np.arange(-0.5,Lmap.shape[1],7)],weights=Lmap[x,y])
				A/=49.
				xn = (bx[1:]+bx[:-1])/2.
				yn = (by[1:]+by[:-1])/2.
				assert (xn==np.int32(xn+0.5)).all() and (yn==np.int32(yn+0.5)).all()
				Lmap[x,y]=ip.RectBivariateSpline(xn,yn,A).ev(x,y)

			Lmap[Lmap>1600] = 1600 #40 as the maximum #physically meaningless
			#if DET.debug: pf.writeto('Lmap.fits',Lmap,clobber=True)
		################################################################################
		#MakeGraphAdjacency Part II
		Adj = [[] for _ in itertools.repeat(None,vmap.max()+1)]
		inLPPs = np.array([False]*len(site))
		if DET.developing: cutfile=file('cutconnection.reg','w')
		if self.CutLines is not None:
			regions= file(self.CutLines).readlines()
			CutLines = grep('^line',regions)
			if len(CutLines)==0:
				sys.exit("ERROR: Format error in "+self.CutLines)
			CutLines = np.float32([s.split()[0].replace('line(','').replace(')','').split(',') for s in CutLines])
			LPPs = []
			for CutLine in CutLines:
				#LPPs.append(np.unique(vmap[DET.LinePassingPixels((CutLine[1],CutLine[0]),(CutLine[3],CutLine[2]))]))
				LinePassPixels = DET.LinePassingPixels((CutLine[1],CutLine[0]),(CutLine[3],CutLine[2]))
				if DET.developing:
					for n in range(len(LinePassPixels[0])): print >>cutfile,"circle(%.1f,%.1f,0.5) # color=blue" % (LinePassPixels[1][n]+1,LinePassPixels[0][n]+1)
				LPPs.append(list(np.unique(vmap[LinePassPixels])))
			lppsflat = []
			for n in LPPs: lppsflat.extend(n)
			inLPPs = np.array([(n1 in lppsflat or n2 in lppsflat) for n1,n2 in site])
			del lppsflat
		for n1,n2 in site[(PPdis<Lmap[Xpos,Ypos])&(inLPPs)]:
			Crossing=False
			for n in range(len(CutLines)):
				if n1 in LPPs[n] or n2 in LPPs[n]:
					CutLine = CutLines[n]
					if DET.DiffSideOfLine((CutLine[1],CutLine[0]),(CutLine[3],CutLine[2]),(self.Px[n1],self.Py[n1]),(self.Px[n2],self.Py[n2])): Crossing=True
			if Crossing:
				if DET.developing:
					print >>cutfile,"line(%.1f,%.1f,%.1f,%.1f) # color=red" % (self.Py[n1]+1,self.Px[n1]+1,self.Py[n2]+1,self.Px[n2]+1)
			else:
				Adj[n1].append(n2)
				Adj[n2].append(n1)
		if DET.developing: cutfile.close()
		for n1,n2 in site[(PPdis<Lmap[Xpos,Ypos])&(~inLPPs)]:
			Adj[n1].append(n2)
			Adj[n2].append(n1)
		self.TmpFile_new('Adj',Adj)
		del Adj,site,PPdis,Xpos,Ypos
		################################################################################

		self.MaxRad = 20
		self.ProbLowr = 4
		self.AreaLowr = 9
		self.AreaLowE = 25
		self.NCtsLowP = 5     #Should not be too high, or else mis-deblending
		self.NCtsLowE = 20     #Should not be too high, or else mis-deblending

		#if use Nmap/Amap instead of Cmap/Amap, negative values need some attention
		#if self.dmap[self.dmap<0].sum() > -0.1: self.dmap[self.dmap<0]=0
		#else: sys.exit("ERROR: DET.init(): Negative value in the image! %f" %(self.dmap[self.dmap<0].sum()))
		self.dmap[self.dmap<=self.Bkg] = 0 #Bkg can be a value or an array with the same shape of img
		#Both Bkg and Count Density are physical, so they are comparable
		#??why do this here??

		#The number of next new source / The number of rows of self.src
		self.Nsource = 1

		#Point Map, on which we run FOF
		self.pmap= np.zeros(self.Cmap.shape,dtype='int32')
		#==0 fraction: empty pixels
		#<0 fraction: occupied pixels not yet detected
		#>0 fraction: Number of Sources

		#Source data, whose first column saves the source Numbers in self.pmap
		if self.src is None: self.src = SrcList()
	#END_OF_def __init__(self,img,ExpMap,**kwargs):

	################################################################################
	#Downloaded from web.
	@staticmethod
	def WeightedPercentile(data, wt, percentiles):
		"""Compute weighted percentiles.
		If the weights are equal, this is the same as normal percentiles.
		Elements of the C{data} and C{wt} arrays correspond to
		each other and must have equal length (unless C{wt} is C{None}).

		@param data: The data.
		@type data: A L{np.ndarray} array or a C{list} of numbers.
		@param wt: How important is a given piece of data.
		@type wt: C{None} or a L{np.ndarray} array or a C{list} of numbers.
			All the weights must be non-negative and the sum must be
			greater than zero.
		@param percentiles: what percentiles to use.  (Not really percentiles,
			as the range is 0-1 rather than 0-100.)
		@type percentiles: a C{list} of numbers between 0 and 1.
		@rtype: [ C{float}, ... ]
		@return: the weighted percentiles of the data.
		"""
		assert np.greater_equal(percentiles, 0.0).all(), "Percentiles less than zero"
		assert np.less_equal(percentiles, 1.0).all(), "Percentiles greater than one"
		data = np.asarray(data)
		assert len(data.shape) == 1
		if wt is None:
			wt = np.ones(data.shape, np.float)
		else:
			wt = np.asarray(wt, np.float)
			assert wt.shape == data.shape
			assert np.greater_equal(wt, 0.0).all(), "Not all weights are non-negative."
		assert len(wt.shape) == 1
		n = data.shape[0]
		assert n > 0
		i = np.argsort(data)
		sd = np.take(data, i, axis=0)
		sw = np.take(wt, i, axis=0)
		aw = np.add.accumulate(sw)
		if not aw[-1] > 0:
			raise ValueError, "Nonpositive weight sum"
		w = (aw-0.5*sw)/aw[-1]
		spots = np.searchsorted(w, percentiles)
		o = []
		for (s, p) in zip(spots, percentiles):
			if s == 0:
				o.append(sd[0])
			elif s == n:
				o.append(sd[n-1])
			else:
				f1 = (w[s] - p)/(w[s] - w[s-1])
				f2 = (p - w[s-1])/(w[s] - w[s-1])
				assert f1>=0 and f2>=0 and f1<=1 and f2<=1
				assert abs(f1+f2-1.0) < 1e-6
				o.append(sd[s-1]*f1 + sd[s]*f2)
		return o
	#END_OF_def WeightedPercentile(data, wt, percentiles):
	@staticmethod
	def wtd_median(data, wt):
		"""The weighted median is the point where half the weight is above
		and half the weight is below.   If the weights are equal, this is the
		same as the median.   Elements of the C{data} and C{wt} arrays correspond to
		each other and must have equal length (unless C{wt} is C{None}).

		@param data: The data.
		@type data: A L{np.ndarray} array or a C{list} of numbers.
		@param wt: How important is a given piece of data.
		@type wt: C{None} or a L{np.ndarray} array or a C{list} of numbers.
			All the weights must be non-negative and the sum must be
			greater than zero.
		@rtype: C{float}
		@return: the weighted median of the data.
		"""
		spots = DET.WeightedPercentile(data, wt, [0.5])
		assert len(spots)==1
		return spots[0]
	#END_OF_def wtd_median(data, wt):
	################################################################################

	@staticmethod
	def Peak2Mean(p):
		#a,b,c = 0.3023,0.7860,0.0001 #result from polyfit 2
		a,b,c = 0.3023,0.7860,0.000 #result from polyfit 2
		#In view of error, c==0. However numerically it's best to let c==0 precisely,
		#in order to avoid negative result in very low flux case.
		return np.sqrt((p+b**2/4/a-c)/a)-b/a/2
	@staticmethod
	def BkgCorrec(p):
		#a,b,c = 0.2180,0.9816,0.0001, var = 0.0083 #result from polyfit 2
		a,b,c = 0.2180,0.9816,0
		#In view of error, c==0. However numerically it's best to let c==0 precisely,
		#in order to avoid negative result in very low flux case.
		return np.sqrt((p+b**2/4/a-c)/a)-b/a/2
	def TmpFile_new(self,key,data,**kwargs):
		assert type(key) is type('str')
		assert key not in self.TmpFile.keys()
		prefix = kwargs.pop('prefix','tmp_'+key+'_')
		suffix = kwargs.pop('suffix','')
		if type(data) is np.ndarray: suffix += '.npz'
		else: suffix += '.cpk'
		self.TmpFile[key] = NamedTemporaryFile(prefix=prefix,suffix=suffix,delete=True,**kwargs)
		if type(data) is np.ndarray: np.savez(self.TmpFile[key],data)
		else: cPickle.dump(data,self.TmpFile[key])
		self.TmpFile[key].seek(0)
	def TmpFile_set(self,key,data):
		TmpFile = self.TmpFile[key]
		if TmpFile.name.split('.')[-1] == 'npz':
			np.savez(TmpFile,data)
		elif TmpFile.name.split('.')[-1] == 'cpk':
			cPickle.dump(data,TmpFile)
		else:
			print 'ERROR: suffix not recognized:',TmpFile.name
		TmpFile.seek(0)
	def TmpFile_get(self,key,name='arr_0'):
		TmpFile = self.TmpFile[key]
		if TmpFile.name.split('.')[-1] == 'npz':
			d = np.load(file(TmpFile.name,'r'))[name]
		elif TmpFile.name.split('.')[-1] == 'cpk':
			d = cPickle.load(TmpFile)
		else:
			print 'ERROR: suffix not recognized:',TmpFile.name
		TmpFile.seek(0)
		return d
	def TmpFile_del(self,key):
		self.TmpFile[key].close()
		self.TmpFile.pop(key)
	def TmpFile_clear(self):
		for k in self.TmpFile.keys(): self.TmpFile_del(k)
		if not DET.developing: os.remove(self.VorFile)
	def TmpFile_save(self):
		kwargs={}
		for k in self.TmpFile.keys():
			if self.TmpFile[k].name.split('.')[-1] == 'npz':
				kwargs[k] = np.load(self.TmpFile[k])['arr_0']
				name = self.TmpFile[k].name
				self.TmpFile[k].close()
				self.TmpFile[k] = name
		np.savez('tpf.npz',**kwargs)
		f1 = self.TmpFile.get('Adj',None)
		f2 = self.TmpFile.get('Oadj',None)
		cPickle.dump((cPickle.load(f1),cPickle.load(f2)),file('tpf.cpk','w'))
		self.TmpFile['Adj'].close()
		self.TmpFile['Adj'] = 'Adj'
		self.TmpFile['Oadj'].close()
		self.TmpFile['Oadj'] = 'Oadj'
	def TmpFile_read(self):
		d=np.load('tpf.npz')
		for k in d.files:
			self.TmpFile.pop(k)
			self.TmpFile_new(k,d[k])
		d=cPickle.load(file('tpf.cpk','r'))
		self.TmpFile.pop('Adj')
		self.TmpFile_new('Adj',d[0])
		self.TmpFile.pop('Oadj')
		self.TmpFile_new('Oadj',d[1])

	def CreateBkgMap(self,FlatBkg=False):
		#if DET.debug: print 'Module path'+os.path.dirname(sys.argv[0])+'/exsc/lib/python2.'+str(sys.version_info[1])+'/site-packages'
		#sys.path.append(os.path.dirname(sys.argv[0])+'/exsc/lib/python2.'+str(sys.version_info[1])+'/site-packages')
		#from exsc import CalLowFreqBkg
		BkgHdr = pf.Header()

		def nonmono(n,nmax):
			i=nmax
			for repeat in [1,2]:
				i -= 1
				if i<0: break
				if n[i]>n[i+1]: return True
			i=nmax
			for repeat in [1,2]:
				i += 1
				if i>9: break
				if n[i]>n[i-1]: return True
			return False
		def histpeak(v,Vmin,Vmax):
			Bstep = (Vmax-Vmin)/100.
			Ebins = np.arange(Vmin,Vmax+Bstep/2.,Bstep)
			Cbins = (Ebins[:-10]+Ebins[10:])/2.
			hist = np.zeros_like(Cbins)
			for i in np.arange(10):
				NB = np.arange(i,Ebins.size,10)
				hist[NB[:-1]],bins = np.histogram(v,bins=Ebins[NB])
			if False:
				import pylab as pl
				pl.plot(Cbins,hist,'r-')
				pl.hist(v,range=(Vmin,Vmax))
				pl.show()
			sigma = 5
			while True:
				y = DET.smooth1d(hist,sigma) #smoothing reduces the varance
				nmax = y.argmax()
				dy = np.diff(y)
				if (dy[:nmax]>=0).all() and (dy[nmax:]<=0).all(): break
				sigma+=1
			return Cbins[nmax]

		low = (self.dmap<1)
		Bkg = self.Cmap[low].sum() / self.Exp[low].sum() * self.Exp
		#boxsize = int(np.sqrt(1.*(self.Exp>0).sum()/(self.Cmap>0).sum()))
		#if boxsize>20: boxsize=20
		i = DET.gaussmooth(self.dmap-Bkg*3,self.PSF.CoreRad,N=self.PSF.CoreRad*2)
		#remove negative regions, leaving source regions
		i[i<0] = 0
		I = np.zeros_like(self.dmap)
		I[(I.shape[0]-i.shape[0])/2:(I.shape[0]+i.shape[0])/2,(I.shape[1]-i.shape[1])/2:(I.shape[1]+i.shape[1])/2] = i
		if DET.debug: pf.writeto('SrcMap.fits',I,clobber=True)
		#Use the smoothed image I as the new bkg region mask
		BkgReg = DET.BkgReg(I,self.Exp)
		#The background level averaged from BkgReg is not reliable
		#because BkgReg depends on parameters
		del i,I,Bkg

		#Estimate average background level from all
		v = self.dmap[BkgReg]/self.Exp[BkgReg]
		v = v[v>0]
		#N = v.size
		#if DET.debug: print 'tot',N
		V = np.log10(v)
		Vmin = V.min()
		Vmax = V.max()
		while True:
			n,bins = np.histogram(V,10,range=(Vmin,Vmax))
			nmax = n.argmax()
			if DET.debug: print 'nmax',nmax,bins[nmax],bins
			if nmax==0:
				Vmax = bins[nmax+2]
			elif nmax==9:
				Vmin = bins[nmax-1]
			else:
				Vmin = bins[nmax-1]
				Vmax = bins[nmax+2]
			if Vmax-Vmin<1:
				if DET.debug: print 'range<1 log out'
				break
		Vmin = 10**Vmin
		Vmax = 10**Vmax
		Nrepeat = 0
		while True:
			Nrepeat += 1
			if Nrepeat>10: print 'WARNING: repeating!'
			n,bins = np.histogram(v,10,range=(Vmin,Vmax))
			nmax = n.argmax()
			while nonmono(n,nmax):
				if DET.debug: print 'Nonmono %.3f,%.3f ->' %(Vmin,Vmax),
				Vmin /= 2.
				Vmax += (Vmax-Vmin)
				if DET.debug: print '%.3f,%.3f' %(Vmin,Vmax)
				n,bins = np.histogram(v,10,range=(Vmin,Vmax))
				nmax = n.argmax()
			if DET.debug: print 'nmax',nmax,bins[nmax],
			if DET.debug: print "%.3f,%.3f" %(Vmin,Vmax)
			if nmax<=2:
				Vmax = bins[nmax+2]
			elif nmax>=7:
				Vmin = bins[nmax-1]
			else:
				#Vmax = bins[nmax+2]
				#Vmin = bins[nmax-1]
				if DET.debug: print 'center range out',bins[nmax-1],bins[nmax+2]
				break
		peak = histpeak(v,Vmin,Vmax)
		BkgHdr.update('BkgPeak',peak)
		print color("Peak in whole image %e" %(peak),32,0)
		if FlatBkg:
			#The peak value is not affected by point sources, however it can be enlarged by very faint and diffuse extended sources.
			#This overestimation becomes a problem when the faint diffuse extended source dominates the area.
			#That's why we abandon the bkg variation estimation,
			#local bkg can be enlarged by extended source edge,
			#resulting in underestimated source region and overestimated source background,
			#thus extended source bias themself.

			self.Bkg = DET.Peak2Mean(self.Exp * peak)
			pf.writeto(self.FileName+'_BkgMap.fits',self.Bkg,BkgHdr,clobber=True)
			return

		rmap = self.dmap.copy()
		rmap[self.Exp>0] /= self.Exp[self.Exp>0]
		rmap[self.Exp<=0] = 0

		if DET.debug: st=time.time()
		self.Bkg = np.zeros_like(self.dmap)
		Nbin = 1.*((rmap>Vmin)&(rmap<Vmax)).sum() * self.Cmap.size / (self.Exp>0).sum() #Number of useable pixels
		if DET.debug: print 'tot num to use',Nbin
		Nbin = int(np.sqrt(Nbin/1000)*10+0.5) #each box contains 1000 usable pixels
		if DET.debug: print 'Number of small bins',Nbin
		if Nbin<=15:
			self.Bkg += peak
			BkgHdr.update('BkgNbin',1)
			BkgHdr.update('BkgBinX',self.Cmap.shape[0])
			BkgHdr.update('BkgBinY',self.Cmap.shape[1])
			AverPeak = peak
		else:
			SbX = self.Cmap.shape[0]/Nbin
			SbY = self.Cmap.shape[1]/Nbin
			BkgHdr.update('BkgNbin',Nbin)
			BkgHdr.update('BkgBinX',SbX)
			BkgHdr.update('BkgBinY',SbY)
			EbX = np.arange(0,self.Cmap.shape[0]+SbX/2,SbX)
			EbY = np.arange(0,self.Cmap.shape[1]+SbY/2,SbY)
			CbX = (EbX[10:]+EbX[:-10])/2
			CbY = (EbY[10:]+EbY[:-10])/2
			BkgRough = np.zeros((CbX.size,CbY.size),dtype='float32')
			for i in np.arange(0,EbX.size-10):
				for j in np.arange(0,EbY.size-10):
					d = rmap[EbX[i]:EbX[i+10],EbY[j]:EbY[j+10]].ravel()
					BkgRough[i,j] = np.sqrt(i**2+j**2)
					if ((d>Vmin)&(d<Vmax)).sum()<500:
						BkgRough[i,j]=-1
					else: BkgRough[i,j] = histpeak(d,Vmin,Vmax)
			if DET.debug: print 'empty fraction',1.*(BkgRough<=0).sum()/BkgRough.size
			if DET.debug: pf.writeto('BkgRough.fits',BkgRough,clobber=True)
			if DET.debug: print 'time',time.time()-st
			AverPeak = BkgRough[BkgRough>0].mean()
			BkgRough[BkgRough<=0] = peak
			print color("Average Peak %e" %(AverPeak),32,0)

			x,y = np.indices(self.Cmap.shape)
			x=x.ravel()
			y=y.ravel()
			self.Bkg[x,y] = ip.RectBivariateSpline(CbX,CbY,BkgRough).ev(x,y)
		if DET.debug: pf.writeto('peakmap.fits',self.Bkg,clobber=True)

		AverBkg = AverPeak*DET.Peak2Mean
		print color("Average Background %e" %(AverBkg),32,0)
		BkgHdr.update('BkgPeakA',AverPeak)
		BkgHdr.update('BkgAver',AverBkg)

		self.Bkg *= self.Exp
		self.Bkg = self.Bkg*DET.Peak2Mean
		pf.writeto(self.FileName+'_BkgMap.fits',self.Bkg,BkgHdr,clobber=True)
		return


		#the old method, not nonparametic, not reliable
		'''
		AverBkg=peak
		#print AverBkg
		for repeat in [1]: #should not repeat, gets higher and higher
			#Estimate source map with the peak value
			self.Bkg = AverBkg*self.Exp #underestimated background map (peak<mean)
			#smoothed image i (smaller) and I(full size)
			if scale>7:
				scale=7
				print 'scale too large, reduced to ',scale
			i = DET.gaussmooth(self.dmap-self.Bkg,scale)
			#remove negative regions, leaving source regions
			i[i<0] = 0
			I = np.zeros_like(self.dmap)
			I[(I.shape[0]-i.shape[0])/2:(I.shape[0]+i.shape[0])/2,(I.shape[1]-i.shape[1])/2:(I.shape[1]+i.shape[1])/2] = i
			if DET.debug: pf.writeto('srcMap.fits',self.dmap-self.Bkg, clobber=True)
			if DET.debug: pf.writeto('SrcMap.fits',I,clobber=True)

			#Replace the source map with peak value to make a rough background map
			#Use the smoothed image I as the new bkg region mask
			BkgReg = DET.BkgReg(I,self.Exp)

			#The background level averaged from BkgReg is not reliable
			#because BkgReg depends on parameters
			AverBkg  = 1.*self.Cmap[BkgReg].sum() / self.Exp[BkgReg].sum()
			print 'aver',AverBkg,
			#This value too high, not as good as above
			#v = (self.dmap[BkgReg&skyregion]/self.Exp[BkgReg&skyregion])
			#AverBkg = v[v>0].mean()
			#print 'aver',AverBkg
			if DET.debug: pf.writeto('BkgRough.fits',AverBkg*self.Exp,clobber=True)

		i = self.dmap.copy()
		i[self.Exp>0] /= self.Exp[self.Exp>0]
		i[(self.Exp>0)&(~BkgReg)] = 0
		i[self.Exp<=0] = 0
		'''

		#the CalLowFreBkg implemented in C no more useful
		#because setting Vmin and Vmax
		#the mean value calculated between them is so strongly restricted by them
		#thus very near the peak value of the total image
		#thus smoothed the low frequency fluctuation
		'''

		#Calculate low frequence background map
		if DET.debug: st=time.time()
		for n in np.arange(1,11):
			Vmin = peak*(10-n)/10
			Vmax = peak*(10+n)/10
			Nusable = ((v>Vmin)&(v<Vmax)).sum()
			if Nusable>800: break
		Nhalf = int(np.sqrt(50.*(self.Exp>0).sum()/Nusable/4)+0.5)
		if DET.debug: print 'Box Size',Nhalf*2
		if Nhalf<5: Nhalf=5
		self.Bkg = CalLowFreqBkg(np.float32(rmap),Nhalf,np.float32(Vmin),np.float32(Vmax))
		if DET.debug:
			rmap[rmap<Vmin]=0
			rmap[rmap>Vmax]=0
			pf.writeto('used.fits',rmap,clobber=True)
		AverLowBkg = self.Bkg[self.Bkg>0].mean()
		print color("Average LowF Background %e" %(AverLowBkg),32,0)
		BkgHdr.update('BkgAver1',AverLowBkg)
		self.Bkg[self.Bkg==-1] = AverLowBkg
		if DET.debug: print 'exsc time: ',time.time()-st
		if DET.debug: pf.writeto('bkgLowF.fits',self.Bkg,clobber=True)
		'''
	#END_OF_def CreateBkgMap

	@staticmethod
	def FitBkg(Area, FRTF=0.8,CalLowPoint=False,MaxFitIteration=100):
		#A a list of cell areas
		from scipy.optimize import curve_fit
		Tot_Area = Area.sum(dtype='float64')
		def PcumC(f,faver,c):
			F=np.float64(faver)/f
			FF=F*F
			cc=c*c
			return np.exp(-c*F)*(FF*F*cc*c/6+FF*cc/2+F*c+1)*faver*Tot_Area
		Pcum = lambda f,faver : PcumC(f,faver,-0.627233*faver + 3.936584)
		def Poly2(x,p2,p1,p0): # ensuring p2**2 > 0
			return (p2*x)**2 + p1*x + p0

		Npixlow = 100
		density = np.float64(1)/Area
		density.sort()
		p0 = np.float64(2)/Area.mean()
		Ncum = np.arange(1,density.size+1,dtype='float64')
		if DET.debug:
			import pylab as pl
			pl.subplots_adjust(hspace=0)
			ax1=pl.subplot(211)
			ax2=pl.subplot(212,sharex=ax1)
			print "Mean_init FRTF Num_pix_use Mean_fit ReduChiS ReduCsta"
		Pite = [p0,p0,p0,p0,p0] #save five historical value because there may be undulate variation around best-fitted value
		NFitIte=0
		while True:
			NFitIte+=1
			ok = density<FRTF*Pite[-1]
			Dof=ok.sum()-1
			c,m = curve_fit(Pcum,density[ok],Ncum[ok],p0=Pite[-1],maxfev=5000)
			#c,m = curve_fit(Pcum,density[ok],Ncum[ok],sigma=np.sqrt(Ncum[ok]),p0=Pite[-1],maxfev=5000)
			#involving sigma doesn't help significantly
			residual = Ncum-Pcum(density,c[0])
			if Dof<27 and False: #27% FRTF<0.8 for random distributions
			#This is not good, because FRTf affects bkgflux, thus low exposure bin with high FRTF may get higher bkgflux than high exposure bin. Set MinPixToCalBkg to avoid such condition.
				print color('Warning: Dof %d<27, enlarge FRTF from %g to %g' %(Dof,FRTF,FRTF+0.2),31,1)
				FRTF+=0.2
				ok = density<FRTF*Pite[-1]
				Dof=ok.sum()-1
				c,m = curve_fit(Pcum,density[ok],Ncum[ok],p0=Pite[-1],maxfev=5000)
				residual = Ncum-Pcum(density,c[0])
			ReduChiS = ( residual[ok]**2 / Ncum[ok] ).sum() / Dof
			#here I use sum(sigma2/observed) rather than sum(sigma2/expected)
			#because expected value may <1, which may result in very big weight
			SmoothSigma=residual.size/100
			#if SmoothSigma<2: SmoothSigma=2
			#if DET.developing: print "Smooth Sigma",SmoothSigma
			#residual = DET.smooth1d(residual,SmoothSigma)
			residual/=Ncum[-1]
			Nright = np.max(np.where(residual<=0)[0])
			lowpoint = density[Nright-1]
			if CalLowPoint:
				Nleft = np.max(np.where(residual[:Nright]>0)[0])
				if density[Nleft]>Pite[-1]:
					Nleft = np.max(np.where(density<Pite[-1])[0])
					Nleft = np.max(np.where(residual[:Nleft]>0)[0])
				(polyp2,polyp1,polyp0),m = curve_fit(Poly2,density[Nleft:Nright+1],residual[Nleft:Nright+1],p0=[100,10,0],maxfev=5000)
				polyp2 = polyp2**2
				lowpoint=-0.5*polyp1/polyp2
				#print "%g x2 + %g x + %g   -- %g" %(polyp2,polyp1,polyp0,lowpoint)
			if DET.debug:
				pp=Pite[-1]
				f = density/pp
				pl.gcf().get_axes()[0].clear()
				pl.gcf().get_axes()[1].clear()
				ax1.plot(f,Ncum,'r.',mec='r',label='data')
				ax1.plot(f[ok],Ncum[ok],'b.',mec='b',label='data fitted')
				ax1.plot(f,Pcum(density,c[0]),'g-',mec='g',label='model')
				ax1.plot([FRTF,FRTF],[0,f.size],'b-',label='fitted range')
				ax2.plot(f,np.zeros_like(f),'k-',mec='k')
				ax2.plot(f,residual,'b-',mec='b',label='residual')
				ax2.plot([f[Nright],f[Nright]],[residual.min(),residual.max()],'b-',label='range')
				if CalLowPoint:
					ax2.plot([f[Nleft],f[Nleft]],[residual.min(),residual.max()],'b-',label='range')
					ax2.plot([lowpoint/pp,lowpoint/pp],[residual.min(),residual.max()],'r-',label='lowpoint')
					ax2.plot(f[:Nright+10],np.polyval([polyp2,polyp1,polyp0],density[:Nright+10]),'r-')
				ax1.legend(loc='upper left',numpoints=1)
				ax2.legend(loc='upper left',numpoints=1)
				#ax1.legend(loc='lower right',numpoints=1)
				#ax2.legend(loc='lower right',numpoints=1)
				ax1.semilogx()
				ax2.semilogx()
				#ax1.set_xlim(0,5)
				#ax2.set_xlim(0,5)
				pl.setp(ax1.get_xticklabels(),visible=False)
				pl.xlabel('Photon density / average',fontsize='large')
				ax1.set_ylabel('Pixel number',fontsize='large')
				ax2.set_ylabel('residual fraction',fontsize='large')
				#pl.show()
				pl.savefig('bkg'+str(NFitIte)+'.png')
				print 'bkg'+str(NFitIte)+'.png'
				print Pite,c[0],FRTF,Dof,ReduChiS
			if any([abs(c[0]-p0)/p0<1e-5 for p0 in Pite]): break
			Pite.pop(0)
			Pite.append(c[0])
			if NFitIte>50: Pite=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+Pite
			if NFitIte>MaxFitIteration: sys.exit('ERROR: MaxFitIteration exceeded')
		if DET.debug: pl.clf()
		#END_OF_while True:
		if CalLowPoint:
			assert polyp2>0 #
			if lowpoint<density[Nleft]: lowpoint=density[Nleft]
			assert lowpoint<density[Nright]
		if ReduChiS>100: sys.exit(color("ERROR: Background Fitting Failed. ReduChiS>100",31,1))
		if residual[-1]<0: print color('Warning: data < bkg model at the brightest end, abnormal unless no source',31,1)
		return Pite[-1],FRTF,ReduChiS,Dof,density[Nright],lowpoint
	#END_OF_def FitBkg()

	@staticmethod
	def FitBkgOld(Area, FRTF=0.8,CalLowPoint=False,MaxFitIteration=100):
		#A a list of cell areas
		from scipy.optimize import curve_fit
		Tot_Area = Area.sum(dtype='float64')
		#ImP1,ImP2,ImP3 = 3.75,7.14,6.45
		def Pcum(f,faver):
			F = np.float64(faver)/f
			FF = F*F
			return np.exp(-4*F)*(FF*F*10.6666666666666667+FF*8+F*4+1)*faver*Tot_Area
			#return np.exp(-ImP1*F)*(FF*F*ImP3+FF*ImP2+F*ImP1+1)*faver*Tot_Area
		def Poly2(x,p2,p1,p0): # ensuring p2**2 > 0
			return (p2*x)**2 + p1*x + p0

		Npixlow = 100
		density = np.float64(1)/Area
		density.sort()
		p0 = np.float64(2)/Area.mean()
		Ncum = np.arange(1,density.size+1,dtype='float64')
		if DET.debug:
			import pylab as pl
			pl.subplots_adjust(hspace=0)
			ax1=pl.subplot(211)
			ax2=pl.subplot(212,sharex=ax1)
			print "Mean_init FRTF Num_pix_use Mean_fit ReduChiS ReduCsta"
		Pite = [p0,p0,p0,p0,p0] #save five historical value because there may be undulate variation around best-fitted value
		NFitIte=0
		while True:
			NFitIte+=1
			ok = density<FRTF*Pite[-1]
			Dof=ok.sum()-1
			c,m = curve_fit(Pcum,density[ok][5:],Ncum[ok][5:],p0=Pite[-1],maxfev=5000)
			residual = Ncum-Pcum(density,c[0])
			if residual[-1]<=0 or Dof<20:
				#In this case there is no source signals, so fit the whole range to measure bkg
				FRTF=10
				ok = density<FRTF*Pite[-1]
				Dof=ok.sum()-1
				c,m = curve_fit(Pcum,density[ok][5:],Ncum[ok][5:],p0=Pite[-1],maxfev=5000)
				residual = Ncum-Pcum(density,c[0])
			if Dof<20: sys.exit(color("ERROR: Background Fitting Failed. <20 pixels involved. Too few!",31,1))
			ReduChiS = ( residual[ok]**2 / Ncum[ok] ).sum() / Dof
			#here I use sum(sigma2/observed) rather than sum(sigma2/expected)
			#because expected value may <1, which may result in very big weight
			SmoothSigma=residual.size/100
			#if SmoothSigma<2: SmoothSigma=2
			#if DET.developing: print "Smooth Sigma",SmoothSigma
			#residual = DET.smooth1d(residual,SmoothSigma)
			residual/=Ncum[-1]
			Nright = np.max(np.where(residual<=0)[0])
			lowpoint = density[Nright-1]
			if CalLowPoint:
				Nleft = np.max(np.where(residual[:Nright]>0)[0])
				if density[Nleft]>Pite[-1]:
					Nleft = np.max(np.where(density<Pite[-1])[0])
					Nleft = np.max(np.where(residual[:Nleft]>0)[0])
				(polyp2,polyp1,polyp0),m = curve_fit(Poly2,density[Nleft:Nright+1],residual[Nleft:Nright+1],p0=[100,10,0],maxfev=5000)
				polyp2 = polyp2**2
				lowpoint=-0.5*polyp1/polyp2
				#print "%g x2 + %g x + %g   -- %g" %(polyp2,polyp1,polyp0,lowpoint)
			if DET.debug:
				pp=Pite[-1]
				f = density/pp
				pl.gcf().get_axes()[0].clear()
				pl.gcf().get_axes()[1].clear()
				ax1.plot(f,Ncum,'r.',mec='r',label='data')
				ax1.plot(f[ok],Ncum[ok],'b.',mec='b',label='data fitted')
				ax1.plot(f,Pcum(density,c[0]),'g-',mec='g',label='model')
				ax1.plot([FRTF,FRTF],[0,f.size],'b-',label='fitted range')
				ax2.plot(f,np.zeros_like(f),'k-',mec='k')
				ax2.plot(f,residual,'b-',mec='b',label='residual')
				ax2.plot([f[Nright],f[Nright]],[residual.min(),residual.max()],'b-',label='range')
				if CalLowPoint:
					ax2.plot([f[Nleft],f[Nleft]],[residual.min(),residual.max()],'b-',label='range')
					ax2.plot([lowpoint/pp,lowpoint/pp],[residual.min(),residual.max()],'r-',label='lowpoint')
					ax2.plot(f[:Nright+10],polyval([polyp2,polyp1,polyp0],density[:Nright+10]),'r-')
				ax1.legend(loc='upper left',numpoints=1)
				ax2.legend(loc='upper left',numpoints=1)
				#ax1.legend(loc='lower right',numpoints=1)
				#ax2.legend(loc='lower right',numpoints=1)
				ax1.semilogx()
				ax2.semilogx()
				#ax1.set_xlim(0,5)
				#ax2.set_xlim(0,5)
				pl.setp(ax1.get_xticklabels(),visible=False)
				pl.xlabel('Photon density / average',fontsize='large')
				ax1.set_ylabel('Pixel number',fontsize='large')
				ax2.set_ylabel('residual fraction',fontsize='large')
				#pl.show()
				pl.savefig('bkg'+str(NFitIte)+'.png')
				print 'bkg'+str(NFitIte)+'.png'
				print Pite[-1],FRTF,Dof,c[0],ReduChiS,Pite
			if any([abs(c[0]-p0)/p0<1e-5 for p0 in Pite]): break
			Pite.pop(0)
			Pite.append(c[0])
			if NFitIte>50: Pite=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]+Pite
			if NFitIte>MaxFitIteration: sys.exit('ERROR: MaxFitIteration exceeded')
		if DET.debug: pl.clf()
		#END_OF_while True:
		if CalLowPoint:
			assert polyp2>0 #
			if lowpoint<density[Nleft]: lowpoint=density[Nleft]
			assert lowpoint<density[Nright]
		if ReduChiS>100: sys.exit(color("ERROR: Background Fitting Failed. ReduChiS>100",31,1))
		return Pite[-1],FRTF,ReduChiS,Dof,density[Nright],lowpoint
	#END_OF_def FitBkgOld()

	def MakeBkgMap(self,**kwargs):
		FRTF = kwargs.pop('FRTF',0.8)
		BkgRegion = kwargs.pop('BkgRegion',None)
		BkgRadius = None #old method, no longer used
		MaxFitIteration = kwargs.pop('MaxFitIteration',100)
		BkgHdr = pf.Header()
		BkgHdr.update('Version',DET.Version)
		if self.Bkg is None:
			if DET.developing:
				dmap=self.dmap.copy()
				dmap[self.Exp<=0] = 0
				dmap[self.Exp>0] /= self.Exp[self.Exp>0]
			Exp = self.Exp.copy()
			Adj = self.TmpFile_get('Oadj')
			Amap = np.load(self.VorFile)['Amap']
			EgPt = np.load(self.VorFile)['EgPt']
			vmap = np.load(self.VorFile)['vmap']
			a = []
			for N in EgPt:
				a.append(N)
				a.extend(Adj[N])
			for N in np.unique(a):
				Amap[self.Px[N],self.Py[N]] = 0
				if DET.developing: dmap[self.Px[N],self.Py[N]] = 0
				Exp[vmap==N] = 0
			del Adj,EgPt,vmap

			if BkgRegion is not None:
				BkgReg = DET.BkgRegMask(BkgRegion,Shape=Amap.shape)
				Amap[~BkgReg] = 0
				Exp[~BkgReg] = 0
				BkgHdr.update('BkgRegF',BkgRegion)
				if DET.developing: dmap[~BkgReg] = 0
			elif BkgRadius is not None and np.sum(Amap>0)>100:
				if BkgRadius == 0: BkgRadius=Amap.shape[0]/2-80
				#this option is for the convenience of my simulation which does not put any source at the edge region.
				IndX,IndY = np.indices(Amap.shape)
				IndX -= Amap.shape[0]/2
				IndY -= Amap.shape[1]/2
				IndD = IndX**2+IndY**2
				InC = IndD>BkgRadius**2
				#Exp[InC] = 0
				Amap[InC] = 0
				if DET.developing: dmap[InC] = 0
				del IndX,IndY,IndD,InC

			if True: # and False:
				Nsmooth=100
				MinPixToCalBkg=300
				MaxNstep=10
				expA=interpolation.zoom(self.Exp,0.1)
				expA=DET.boxsmooth(expA,int(Nsmooth*0.1),mode='same')
				expA=interpolation.zoom(expA,10)
				expA[expA<0] = 0
				expB = expA.copy()
				expA[Exp<=0] = 0
				expB[self.Exp<=0] = 0
				expS=np.sort(expA[expA>0])
				Nstep = kwargs.pop('BkgNstep',None)
				if Nstep is None:
					for Nstep in range(MaxNstep,0,-1):
						if Nstep==1: break
						nn = [np.sum(Amap[(expA>expS[(expS.size-1)*n/Nstep])&(expA<expS[(expS.size-1)*(n+1)/Nstep])]>0) for n in range(0,Nstep)]
						if np.min(nn)>MinPixToCalBkg: break
				if DET.developing: print 'Nstep',Nstep
				for N in range(Nstep,0,-1):
					expA[expA>expS[expS.size*(N-1)/Nstep]] = -N
					expB[expB>expS[expS.size*(N-1)/Nstep]] = -N
				expA*=-1
				expB*=-1
				expA[expA<0] = 0
				expB[expB<0] = 0
				if DET.developing: pf.writeto('expsteps.fits',expB,clobber=True)
				Bkg = np.zeros_like(self.Exp)

				stepdata=np.zeros((Nstep,4),dtype='float32')
				BkgHdr.update('BkgNstep',Nstep)
				for N in range(1,Nstep+1):
					A = np.float64(Amap[expA==N])
					bkgflux,frtf,ReduChiS,Dof,dright,lowpoint = DET.FitBkg(A[A>0],FRTF=FRTF,CalLowPoint=False,MaxFitIteration=MaxFitIteration)
					Bkg[expB==N] = bkgflux
					BkgHdr.update('BkgFlux'+str(N),bkgflux)
					BkgHdr.update('FRTF'+str(N),frtf)
					stepdata[N-1] = [np.mean(self.Exp[expA==N][A.argsort()][-Dof:]),bkgflux,frtf,expS[(expS.size-1)*N/Nstep]]
				if Nstep==1:
					self.Bkg = bkgflux+np.zeros_like(self.Exp)
					BkgHdr.update('BkgExpA',0)
					BkgHdr.update('BkgExpB',-10)
				elif Nstep==2 and stepdata[0,1]>=stepdata[1,1]:
					self.Bkg = (stepdata[0,1]+stepdata[1,1])/2.+np.zeros_like(self.Exp)
					BkgHdr.update('BkgExpA',1)
					BkgHdr.update('BkgExpB',-20)
				else:
					BkgExpA,BkgExpB = np.polyfit(stepdata[:,0],stepdata[:,1],1)
					#I don't use the slope in log space, because I don't want the lowest-exposure bin over-weighted.
					#logA,logB = np.polyfit(np.log10(stepdata[:,0]),np.log10(stepdata[:,1]),1)
					#if logA>1:
						#Warning: Bkg-Exp slope > 1. The background may be enlarged by the wing region of a large extened source or a very bright point source in the image center.
						#print color('Warning: Bkg-Exp slope > 1. y=%fx+%f in log' % (logA,logB),31,1)
					if BkgExpA<0:
						if BkgExpA<-1e-3: sys.exit('ERROR: negative slope')
						self.Bkg = np.mean(stepdata[:,1])+np.zeros_like(self.Exp)
					else:
						if BkgExpB<0:
							print BkgExpA,BkgExpB,'->',
							x = np.median(stepdata[:,0])
							y = np.polyval((BkgExpA,BkgExpB),x)
							BkgExpA = y/x
							BkgExpB = 0
							print BkgExpA,BkgExpB
							#logA,logB = np.polyfit(np.log10(stepdata[:,0]),np.log10(stepdata[:,1]),1)
							#Warning: Bkg-Exp intersept < 0. The background may be enlarged by the wing region of a large extened source or a very bright point source in the image center.
							#print color('Warning: Bkg-Exp intersept < 0. y=%fx+%f in log' % (logA,logB),31,1)
						self.Bkg = np.polyval((BkgExpA,BkgExpB),self.Exp)
						self.Bkg[self.Exp<=0] = 0
						self.Bkg[self.Bkg<0] = np.min(self.Bkg[self.Bkg>0])
					BkgHdr.update('BkgExpA',BkgExpA)
					BkgHdr.update('BkgExpB',BkgExpB)
					if DET.developing:
						np.savetxt('bkgsteps.dat',stepdata)
						pf.writeto('bkgsteps.fits',Bkg,clobber=True)
						import pylab as pl
						pl.gca().clear()
						pl.plot(stepdata[:,0],stepdata[:,1],'bo')
						pl.plot(stepdata[:,0],np.polyval((BkgExpA,BkgExpB),stepdata[:,0]),'r-')
						pl.savefig('bkgsteps.png')
			else:
				#Old
				Amap *= self.Exp
				A = np.float64(Amap[Amap>0])
				bkgflux,FRTF,ReduChiS,Dof,dright,lowpoint = DET.FitBkg(A[A>0],FRTF=FRTF,CalLowPoint=False,MaxFitIteration=MaxFitIteration)
				#print bkgflux,FRTF,ReduChiS,Dof,dright,lowpoint
				self.Bkg = bkgflux*self.Exp
				BkgHdr.update('FittdBkg',bkgflux)
				BkgHdr.update('FittdFra',FRTF)
				BkgHdr.update('ReduChiS',ReduChiS)
				BkgHdr.update('FittdDof',Dof)
				if DET.developing:
					Amap[dmap>dright]=0
					dmap[dmap>dright]=0
					#pf.writeto('used.fits',Amap,clobber=True)
					LeftAver1=(dmap*Amap).sum(dtype='float64')/Amap.sum(dtype='float64')
					BkgHdr.update('AverBkg1',LeftAver1)
					if DET.debug: print 'LeftAver1',LeftAver1
					#Amap[dmap>lowpoint]=0
					#dmap[dmap>lowpoint]=0
					#LeftAver=(dmap*Amap).sum(dtype='float64')/Amap.sum(dtype='float64')
					#BkgHdr.update('AverBkg2',LeftAver)
					#print 'LeftAver2',LeftAver
				print color("Fitted Background %e, fitting the < %.2f Mean part" %(bkgflux,FRTF),32,0)
		elif type(self.Bkg) is np.float32:
			print color("Average Background %e, input" %(self.Bkg),32,0)
			BkgHdr.update('InputBkg',self.Bkg)
			self.Bkg = self.Bkg*self.Exp
		elif type(self.Bkg) is type('string'):
			BkgReg = DET.BkgRegMask(self.Bkg,Shape=self.Exp.shape)
			self.Bkg = 1.*self.Cmap[BkgReg].sum() / self.Exp[BkgReg].sum()
			print color("Average Background %e, averaged in bkgregion" %(self.Bkg),32,0)
			BkgHdr.update('InRegBkg',self.Bkg)
			self.Bkg = self.Bkg*self.Exp
		else: sys.exit('Wrong Bkg input')
		if DET.developing: pf.writeto(self.FileName+'BkgMap.fits',self.Bkg,BkgHdr,clobber=True)
	#END_OF_MakeBkgMap()

	def exsdetect1(self):
		print color("Initial FOF Detection",32,0)
		toon = (self.dmap>self.Bkg)
		self.dmap[self.dmap<=self.Bkg] = 0
		Pix=np.load(self.VorFile)['vmap'][toon]
		self.Nsource,visited = Percolate(Nplus=self.Nsource,Connections=self.TmpFile_get('Adj'),Vertices=Pix)
		self.pmap[toon] = [visited[n] for n in Pix]
		del toon,Pix,visited
		#self.TmpFile_new('pmap0',self.pmap)
		self.src = self.src.extend(1,self.Nsource-1)
		#Here self.src is only used for PreDel, the data will be cleaned soon
		if DET.General:
			self.CalSrc(ToCalCenter=True)
			self.saveresult(Version=DET.Version,OutFile=self.OutFile)
			exit()
		self.CalSrc()
		self.PreDel()
		#if DET.debug: pf.writeto('deblended0.fits',self.pmap,clobber=True)
		#if DET.debug: self.SaveVorReg('deblended0.reg')
		#if DET.debug: np.savetxt('deblended0.dat',self.src[1:,],fmt='%12.8g',delimiter='\t')
		self.SepExtSrc()
		self.FillHoles(EmpInside=True,OutFile=self.OutFile)
		self.TmpFile_new('pmap0',self.pmap)
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='deblended0')
		self.Core_MakeCore()
		#self.Core_ClafySrc()
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmp0')
		assert (self.pmap[self.dmap<=self.Bkg] == 0).all()
		self.FillHoles(EmpInside=True,OutFile=self.OutFile)
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmp1')
	#END_OF_exsdetect1
	def exsdetect2(self):
		self.MakeSrcRegion()
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmpa')
		self.Merge_Neighb_Ext()
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmpb')
		self.FillHoles(SrcInside=True,OutFile=self.OutFile)
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmpc')
		self.Merge_Neighb_Ext()
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmpd')
		if self.ModiExtSrc:
			self.SepExtSrc(SepExt=self.SepExt)
			if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmpe')
		if self.EmpInside:
			self.FillHoles(EmpInside=True,OutFile=self.OutFile)
			if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmpf')
		self.EstiSrcExp()
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmpg')
		self.FillEachCell_pmap()
		self.CalSrc()
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmph')
		self.FinalDel()
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmpi')
		if DET.developing:
			self.saveresult(Version=DET.Version,OutFile=self.OutFile)
		else:
			self.saveresult(Version=DET.Version,OutFile=self.OutFile,ModiType=True)
		self.TmpFile_clear()
	#END_OF_exsdetect2

	def ShrinkCore(self,pmap=None,Rc=None,vdmap=None):
		#Make each source contain only the birghtest pixel
		#and delete impractical faint ones if asked to
		if pmap is None: pmap=self.pmap
		if Rc is None: Rc=self.PSF.CoreRad
		assert (pmap>=0).all()
		DMax = np.zeros(self.Nsource,dtype='float32')
		PMax = np.zeros((self.Nsource,2),dtype='int32')
		for x,y in np.argwhere(pmap>0):
			n = pmap[x,y]
			if self.dmap[x,y]>DMax[n]:
				DMax[n] = self.dmap[x,y]
				PMax[n] = x,y
		pmap[:,:] = 0
		#For each source, keep only the brightest pixel
		for n in np.where(DMax>0)[0]:
			pmap[tuple(PMax[n])] = n
		if vdmap is None: return
		############################################################
		#Reduce the number, deleting low S/N ones
		S = np.zeros(pmap.max()+1)
		N = np.zeros(pmap.max()+1)
		#ATTENTION: center pixel removed
		S8 = np.array([[1,0],[0,1],[-1,0],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]])
		X,Y = np.where(pmap>0)
		ok = (X>=1) & (Y>=1) & (X<pmap.shape[0]-1) & (Y<pmap.shape[1]-1)
		X,Y = X[ok],Y[ok]
		for n in range(8):
			S[pmap[X,Y]] += vdmap[X+S8[n,0],Y+S8[n,1]]
			N[pmap[X,Y]] += self.Bkg[X+S8[n,0],Y+S8[n,1]]
		for x,y in np.argwhere(pmap>0):
			if N[pmap[x,y]]>0 and S[pmap[x,y]]/N[pmap[x,y]] < 3: pmap[x,y] = 0
		if DET.debug: print 'reduced',(S[N>0]/N[N>0]<3).sum(),'/',(N>0).sum()

		#Combine sources too near each other
		IndX,IndY = np.indices((2*Rc+1,2*Rc+1))-Rc
		IndD = np.sqrt(IndX**2+IndY**2)
		InC = IndD<=Rc
		IndX,IndY,IndD = IndX[InC],IndY[InC],IndD[InC]
		for x0,y0 in np.argwhere(pmap>0):
			n = pmap[x0,y0]
			if n == 0: continue #maybe deleted
			xi,yi = IndX+x0,IndY+y0
			ok = (xi>=0)&(yi>=0)&(xi<pmap.shape[0])&(yi<pmap.shape[1])
			xi,yi = xi[ok],yi[ok]
			ok = pmap[xi,yi]>0
			xi,yi = xi[ok],yi[ok]
			if len(xi)==1: continue #no other
			n = self.dmap[xi,yi].argmax()
			N = pmap[xi[n],yi[n]]
			pmap[xi,yi] = 0
			pmap[xi[n],yi[n]] = N
	#END_OF_def ShrinkCore(self,pmap=None,Rc=None,vdmap=None):

	def KStest(self,N,Bkg,vNmap):
		#need self.Nfull, self.PsfBox
		Xn,Yn = np.where(self.pmap==N)
		self.src.val4[N] = Bkg[Xn,Yn].sum()
		X0 = int(self.src.ImgX[N]+0.5)
		Y0 = int(self.src.ImgY[N]+0.5)
		Xp = Xn-X0+self.PSF.CoreRad
		Yp = Yn-Y0+self.PSF.CoreRad
		if Xn.size<self.Nfull/2:
			self.src.Ccts[N] = vNmap[Xn,Yn].sum()
			return 1,10
		if Xn.size<self.Nfull:
			if not self.PSF.ConsPSF: self.PsfBox = self.PSF.getflux(Npsf=self.PSF.CoreRad,offaxis=[X0,Y0])
			v,P,p,self.src.Ccts[N] = self.CumuCurve(Dist=self.IndD[Xp,Yp],Val=vNmap[Xn,Yn],Psf=self.PsfBox[Xp,Yp])
		elif Xn.size==self.Nfull:
			v,P,p,self.src.Ccts[N] = self.CumuCurve(Dist=self.IndD[Xp,Yp],Val=vNmap[Xn,Yn],offaxis=[X0,Y0])
		else:
			sys.exit('ERROR: core too large')
		if DET.debug:
			import pylab as pl
			pl.gca().clear()
			if p is not None: pl.plot(np.arange(1,P.size+1),p,'y+-',label='p')
			pl.plot(np.arange(1,P.size+1),v,'b+-',label='src')
			pl.plot(P,v,'r+-',label='PSF')
			if Xn.size<self.Nfull:
				pl.legend(loc='lower right')
			if Xn.size==self.Nfull:
				pl.legend(loc='upper left')
			pl.savefig('psf'+str(self.pmap[X0,Y0])+'.png',format='png')
		#if DET.debug: pl.clf()
		Dplus = (np.arange(1,P.size+1)-P).max()/P.size
		return Dplus,P.size

	def Core_MakeCore(self,TimesBkg=0.5,SNR=1,MaxRad=20):

		#make imap, which will be used in MakeSrcRegion() to separated blended sources
		print color("\nFinding Blended Sources on the following Contour Scales",32,0)
		pmap = np.zeros_like(self.pmap)
		vmap = np.load(self.VorFile)['vmap']
		Adj = self.TmpFile_get('Adj')
		bkgmean = self.Bkg[self.Bkg>0].mean()
		i=1
		vdmap = self.TmpFile_get('vdmap')
		if False:
			#old way is working on smoothed image, in order to avoid very dense spurious source candidates#{{{
			#Now I think it is good to be consistent with the separation procedure in MakeSrcRegion()
			#The very dense candidates problem is solved by setting a lower limit on the distances between candidates
			smoothsigma=2
			if DET.debug: print 'bkg mean: %.2f  smooth sigma: %d' %(bkgmean,smoothsigma)
			d = DET.gaussmooth(vdmap.copy(),smoothsigma)
			d[d<0] = 0
			smap = np.zeros(self.pmap.shape,dtype='float32')
			smap[(smap.shape[0]-d.shape[0])/2:(smap.shape[0]+d.shape[0])/2,(smap.shape[1]-d.shape[1])/2:(smap.shape[1]+d.shape[1])/2] = d
			#smap[self.dmap<=self.Bkg] = 0 #this line is wrong, make unseparateable candidates
			#at last, it seems this smoothing is necessary
			#because there is often some bright point inside ext src, looking like point source very much.
			if DET.debug: pf.writeto('smap.fits',smap,clobber=True)
			#Jul18,2012, again, I want to try not smoothing.#}}}
		smap = self.dmap
		CTRSCALESLOWTIMESBKG=4 #4 times bkg. as we are trying to identify pnt src rather than ext src with this, why not higher, leave less candidates and save some time
		for Cscale in self.CalCtrScales(bkgmean*CTRSCALESLOWTIMESBKG,smap.max()):
			if smap.max()<=Cscale: continue
			print color(" %.3f " %(Cscale),32,0),
			pmap[:,:] = 0 #rebuild tmp pmap
			if False: #old way, used on smoothed image
				pmap[(smap>Cscale)] = -1
				self.Nsource=Percolate(Nplus=self.Nsource,pmap=pmap)
			else: #new way, work on graph
				toon = (self.dmap>Cscale)
				Pix= vmap[toon]
				self.Nsource,visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix)
				pmap[toon] = [visited[n] for n in Pix]
			#pf.writeto('p'+str(i)+'.fits',pmap,clobber=True)
			#i+=1
			#The source numbers in pmap follow self.Nsource, and thus never duplicate
			#Then save the detected Sources in tmp pmap into self.pmap
			for n in np.arange(pmap[pmap>0].min(),pmap.max()+1):
				if (pmap==n).any():
					N = np.unique(self.pmap[pmap==n]) #Number of blended source
					if N.size>1:
						for NN in N[1:]:
							self.pmap[self.pmap==NN]=N[0]
						#with a constant linking scale, this should not happen
						#but with varing linking scale, two points may be linked an may not
						#sys.exit('How come N.size!=1!')
					InSourceN = self.pmap==N[0]
					self.pmap[InSourceN] = pmap[InSourceN] #Save the separated blending region
					pmap[InSourceN] = 0 #Mark all the new sources inside this region as already saved
			#self.SaveVorReg(str(i)+'.reg')
			#pf.writeto('i'+str(i)+'.fits',self.pmap,clobber=True)
		print
		if (self.pmap<=0).all():
			if DET.debug: print "No blending found"
			return
		#By now the image is fragmentized to the largest extent, containing thickly dotted source candidates, most of which are spurious.

		################################################################################
		#Make imap which mark each source candidate with only one pixel (temperarily saved in self.pmap)
		#Mark core regions in self.pmap, which will be used in Core_ClafySrc()
		#Calculate src.Ccts, src.ImgX, src.ImgY
		print color("\nMaking PSF Core Circles",32,0)
		################################################################################

		################################################################################
		#Initialize self.pmap and self.src
		#Shrink source regions to one pixel and delete impractical source candidates
		self.ShrinkCore(vdmap=vdmap,Rc=self.PSF.CoreRad*3/2)
		#Now self.pmap has only one pixel for each of the reasonable source candidates
		self.src = self.src.extend(self.src.Nsrc,self.Nsource-1) #this part of self.src saves all the cores, a coremap will be associated to it
		assert np.unique(self.pmap).size == (self.pmap>0).sum()+1 #each source is marked with only one pixel
		for x,y in np.argwhere(self.pmap>0): #initialize self.src
			n = self.pmap[x,y]
			self.src.ImgX[n],self.src.ImgY[n] = x,y
			self.src.Ccts[n] = 1
		################################################################################

		################################################################################
		#Delete spurious candidates with the DelSpu method
		vdmap = self.TmpFile_get('vdmap')
		vNmap = vdmap - self.Bkg
		#First run, initialize Ccts which is needed by the DelSpu method
		self.ReDrawCirclesInPmap(getNcts=True, Rc=self.PSF.CoreRad, dmap=vNmap, OverLap=True)
		self.src.Ccts[:] = self.src.Ncts[:]
		#Second run, remove spurious ones in self.pmap using the DelSpu method in ReDrawCirclesInPmap()
		self.ReDrawCirclesInPmap(getNcts=True, Rc=self.PSF.CoreRad, dmap=vNmap, DelSpu=True)
		#Now make imap
		imap = np.zeros_like(self.pmap)
		pmap0=self.TmpFile_get('pmap0')
		#Attention the imap position is got from FoF identification above
		#Orelse the imap positions can not be separated later
		for N in range(1,self.src.Nsrc):
			if self.pmap[self.src.ImgX[N],self.src.ImgY[N]]>0 and pmap0[self.src.ImgX[N],self.src.ImgY[N]]>0:
				imap[self.src.ImgX[N],self.src.ImgY[N]] = self.pmap[self.src.ImgX[N],self.src.ImgY[N]]
			else:
				self.src.Ccts[N] = 0 #mark as to be deleted
		del pmap0
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='core0')

		########################################################################
		#Old method to optimize the core centers in imap
		#The 3x3 method here is simple and practical
		#However the scatter of the XRT PSF is large, 3x3 may be not enough
		#For chandra it should work better
		if False:
			assert self.src.shape[1] >= 10 #here it is used as a tmp container
			self.src[:,1:10] = 0
			X,Y = np.where(imap>0)
			ok = (X>=2) & (Y>=2) & (X<imap.shape[0]-2) & (Y<imap.shape[1]-2)
			X,Y = X[ok],Y[ok]
			S9x,S9y = np.mgrid[-1:2,-1:2].reshape(2,9) #3x3 square with 9 pixels
			for Nc in range(0,9):
				for Np in range(0,9):
					self.src[imap[X,Y],Nc+1] += vdmap[X+S9x[Nc]+S9x[Np],Y+S9y[Nc]+S9y[Np]]
			del vdmap
			for x,y,n in itertools.izip(X,Y,self.src[imap[X,Y],1:10].argmax(axis=1)):
				imap[x,y], imap[x+S9x[n],y+S9y[n]] = 0, imap[x,y]
			self.src[:,1:10] = 0
		########################################################################

		########################################################################
		#Third run, build BkgP, renew Ccts, get Joint
		#self.ReDrawCirclesInPmap(Numbs=np.int32(self.src.Numb[self.src.Ccts>0]), Rc=(self.PSF.CoreRad+1)/2, dmap=vNmap)
		self.ReDrawCirclesInPmap(Numbs=np.int32(self.src.Numb[self.src.Ccts>0]), Rc=(self.PSF.CoreRad+1), dmap=vNmap)
		SmallCore = self.pmap.copy()
		BkgP,Joint = self.ReDrawCirclesInPmap(Numbs=np.int32(self.src.Numb[self.src.Ccts>0]), getNcts=True, Rc=self.PSF.CoreRad, dmap=vNmap, getBkgP=True, getJoin=True)
		BkgP += self.Bkg
		self.src.Ccts[:] = self.src.Ncts[:]
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='core8')
		#Calculate src info (including Prob), ImgX,ImgY are optimized
		self.CalSrc(Bkg=BkgP,ToCalCenter=True,SmoothCenterSmallCore=SmallCore)
		self.PreDel()
		for x,y in np.argwhere(imap>0):
			if self.src.Prob[imap[x,y]]<self.ProbLowr:
				imap[x,y] = 0
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='core3')
		#exit()

		############################################################
		#BEGIN: This section is added after Version 3.0
		############################################################
		#keep the imap position for Joint sources, because the new calculated ones may be affected by nearby brighter source
		#a few cores inside an ext src will go toward each other, resulting in a few highly jointed cores
		'''
		for x,y in np.argwhere(imap>0):
			N=self.src.Numb[imap[x,y]]
			if N in Joint.keys():
				print "line(%d,%d,%d,%d) # color=red" % (self.src.ImgY[N]+1+0.5,self.src.ImgX[N]+1.5,y+1,x+1)
				self.src.ImgX[N],self.src.ImgY[N] = x,y
		'''
		#This section is abandanded. It was final when the core positions were optimized with ToCalCenter
		#However the optimized positions may make problem.
		#Sometiems, after the core shifted to the optimized new position, the imap is kicked out. So:
		self.ReDrawCirclesInPmap(Numbs=np.int32(self.src.Numb[self.src.Ccts>0]), Rc=self.PSF.CoreRad, dmap=vNmap) #map of all the cores
		#pf.writeto('p.fits',self.pmap,clobber=True)
		#pf.writeto('i.fits',imap,clobber=True)
		#print np.argwhere((self.pmap!=imap)&(imap>0))
		assert np.all(np.unique(self.pmap) == np.unique(imap))
		ImapOutOfCore = np.argwhere((self.pmap!=imap)&(imap>0))
		if len(ImapOutOfCore) > 0:
			for x,y in np.argwhere((self.pmap!=imap)&(imap>0)):
				N=imap[x,y]
				assert np.all(imap[self.pmap==N]!=N)
				self.src.Ccts[N] = 0 #mark as to be deleted
				self.src.Prob[N] = 0 #mark as to be deleted
				imap[x,y] = 0
		assert np.all(self.pmap[imap>0] == imap[imap>0])

		#Check whether those jointing cores are significantly separatable
		#If not, delete the fainter one
		#this procedure is done after the core position optimized, the remaining cores' positions are not modified.
		self.src.Ccts[0] = 0
		Joint = self.ReDrawCirclesInPmap(Numbs=np.int32(self.src.Numb[self.src.Ccts>0]), Rc=self.PSF.CoreRad, dmap=vNmap, getJoin=True) #map of all the cores
		assert np.all(self.pmap[imap>0] == imap[imap>0])
		AreaSeparated = dict()
		CtsSeparated = dict()
		Amap = np.load(self.VorFile)['Amap']
		for N1 in Joint.keys():
			if self.src.Ccts[N1] == 0: continue
			for N2 in Joint[N1]:
				if self.src.Ccts[N2] == 0: continue
				#print N1,N2
				#print self.src.ImgY[N1]+1, self.src.ImgX[N1]+1
				#print self.src.ImgY[N2]+1, self.src.ImgX[N2]+1
				AreaSeparated[N1] = 0.
				AreaSeparated[N2] = 0.
				CtsSeparated[N1] = 0.
				CtsSeparated[N2] = 0.
				SourceN1 = self.pmap==N1
				SourceN2 = self.pmap==N2
				#print np.where(SourceN1&(imap>0))
				#print np.where(SourceN2&(imap>0))
				assert np.sum(SourceN1&(imap>0))==1
				assert np.sum(SourceN2&(imap>0))==1
				X1,Y1 = np.argwhere(SourceN1&(imap>0))[0]
				X2,Y2 = np.argwhere(SourceN2&(imap>0))[0]
				SourceN = (SourceN1|SourceN2)&(self.dmap>0)
				VorSitesInvolved = vmap[SourceN][self.dmap[SourceN].argsort()]
				root = X2,Y2 #N2 is brighter
				low = 0
				high = np.where(VorSitesInvolved==vmap[tuple(root)])[0][0]
				VorSitesToSep = [vmap[X1,Y1]]
				bridge = VorSitesInvolved[self.FindOneBridgePixel(vmap,Adj,VorSitesInvolved,VorSitesToSep,[],high,low,root)]
				Xb,Yb = self.Px[bridge],self.Py[bridge]
				if DET.developing: file('joint.reg','w').write("circle(%d,%d,1) # color=yellow text={b}\n" %(Yb+1,Xb+1))
				assert self.dmap[X1,Y1]>self.dmap[Xb,Yb]
				VorSitesInvolved = [i for i in VorSitesInvolved if self.dmap[self.Px[i],self.Py[i]]>self.dmap[Xb,Yb]]
				#collect above-bridge pixels of source N
				visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=VorSitesInvolved,root=vmap[(X1,Y1)],GetOne=True)
				for i in visited.keys():
					if visited[i]:
						x,y = self.Px[i],self.Py[i]
						if DET.developing: file('joint.reg','a').write("circle(%d,%d,0.5) # text={%d}\n" %(y+1,x+1, N1))
						AreaSeparated[N1] += Amap[x,y]
						CtsSeparated[N1] += self.Cmap[x,y]
				#collect above-bridge pixels of source N2
				visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=VorSitesInvolved,root=vmap[(X2,Y2)],GetOne=True)
				for i in visited.keys():
					if visited[i]:
						x,y = self.Px[i],self.Py[i]
						if DET.developing: file('joint.reg','a').write("circle(%d,%d,0.5) # text={%d}\n" %(y+1,x+1, N2))
						AreaSeparated[N2] += Amap[x,y]
						CtsSeparated[N2] += self.Cmap[x,y]
				NetCts1=CtsSeparated[N1]-AreaSeparated[N1]*self.dmap[Xb,Yb]
				NetCts2=CtsSeparated[N2]-AreaSeparated[N2]*self.dmap[Xb,Yb]
				if NetCts1<4:
					self.src.Ccts[N1] = 0 #mark as to be deleted
					#print 'delimap', N1,np.argwhere(SourceN1&(imap!=0))
					imap[SourceN1] = 0
					if DET.developing: file('joint.reg','a').write("circle(%d,%d,6) # color=blue text={del}\n" % (Y1+1, X1+1))
					break #other jointing source (which are also brighter than this one) are ignored
				elif NetCts2<4:
					self.src.Ccts[N2] = 0 #mark as to be deleted
					#print 'delimap', N2,np.argwhere(SourceN1&(imap!=0))
					imap[SourceN2] = 0
					if DET.developing: file('joint.reg','a').write("circle(%d,%d,6) # color=blue text={del}\n" % (Y2+1, X2+1))
		del Adj,vmap,Amap
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='core1')
		#END: This section is added after Version 3.0
		############################################################
		#exit()

		################################################################################
		#Finalize self.src and imap
		self.src.Ccts[0] = self.NCtsLowP
		self.ShrinkList(self.src.Ccts>0)
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='core2')
		#This is done only once, from now on even spurious source are kept in the src list with a reliability flag
		imap[imap>0] = self.pmap[imap>0]
		assert np.unique(self.pmap).size == np.unique(imap).size
		self.TmpFile_new('imap',imap)
		#imap is saved before optimizing the core centers, so every source falls on an occupied pixel (the center may vary)
		#imap is saved after ShrinkList, so it is associated to self.src (number index)
		#pf.writeto('imap.fits',imap,clobber=True)
		#if DET.developing: self.saveresult(Version=DET.Version,OutFile='core2')
		################################################################################
		#exit()

		############################################################
		#Final run
		BkgP = self.ReDrawCirclesInPmap(getNcts=True, Rc=self.PSF.CoreRad, dmap=vNmap, getBkgP=True)
		BkgP += self.Bkg
		self.src.Ccts[:] = self.src.Ncts[:]
		#assert np.all(imap[imap>0] == self.pmap[imap>0])
		#One ReDrawCirclesInPmap can not kick imap position out of the circle, however two can.
		#such case is rare, and generally it should not be robust pnt src. So I just delete it simply.
		for x,y in np.argwhere((imap>0)&(imap!=self.pmap)):
			self.pmap[self.pmap==imap[x,y]] = 0
			imap[x,y] = 0
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='core4')
		#exit()

		################################################################################
		#Complete the src list
		self.pmap[self.Exp<=0] = 0
		self.CalSrc(Bkg=BkgP,ToCalCenter=False)
		self.PreDel()

		if DET.debug: self.saveresult(Version=DET.Version,OutFile='core5')

		################################################################################
		#By now, the three values of the core info (Ccts,val4,Type) is generated here
		#and saved in the first part of src, whose Numb is associated to this coremap
		self.TmpFile_new('coremap',self.pmap)
	#END_OF_def Core_MakeCore

	#def Core_ClafySrc(self):
	#Input: self.pmap marking the core circles of source candidates
	#Input: self.src 6,7: center pixels of source candidates
	#OutPut: self.src 2: Ccts 4: val4 8: Type

		#Bkg=BkgP
		vNmap = self.TmpFile_get('vdmap') - BkgP
		if DET.debug: pf.writeto('vNmap.fits',vNmap,clobber=True)

		from scipy.special import smirnov
		from scipy.special import kolmogorov

		Npsf = self.PSF.CoreRad
		IndX,IndY = np.indices((2*Npsf+1,2*Npsf+1))-Npsf
		self.IndD = np.sqrt(IndX**2+IndY**2)
		self.Nfull = (self.IndD<=Npsf).sum()
		if self.PSF.ConsPSF: self.PsfBox = self.PSF.getflux(Npsf=Npsf)

		self.src.Type[0] = 0
		Ns = np.unique(self.pmap)
		Ns = Ns[Ns>=1]
		Dvalue = np.zeros(self.src.Nsrc,dtype=self.src.dtype)
		for N in Ns:
			Dvalue[N],self.src.Type[N] = self.KStest(N,BkgP,vNmap)
		if False: #two sided test
			en = np.sqrt(self.src.Type[Ns]/2.)
			d = (en+0.12+0.11/en)*Dvalue[Ns]
			d[d<0.001] = 0.001 #too small makes error
			self.src[Ns,9] = kolmogorov(d)
		#one sided tese
		Dvalue[Dvalue<0] = 0
		self.src.Type[Ns] = smirnov(self.src.Type[Ns],Dvalue[Ns])
		self.src.val4[Ns] = self.src.Ccts[Ns]/np.sqrt(self.src.val4[Ns])
		#selection of val4
		#Net count inside the involved region is not good, because the effection of bkg is not taken into account
		#So it's between Ncts/sqrt(bkg) and Ncts/sqrt(Ntot) (our S/N vs traditional S/N)
		#It seems the tradiational S/N does gives bkg an insufficient weight
		#Our new S/N makes the effection of bkg much more significant, maybe even too much,
		#sources with small net counts and smaller bkg can be misclassified as extended
		#However, it's better to misclassify such very faint sources from very shallow field as extended than other
		#because they can be filtered out by our lower limit on source net counts.

		if DET.debug: self.saveresult(Version=DET.Version,OutFile='classify')
		#exit()

		if self.InputExtSrc is not None:
			InputExtSrc = ~DET.BkgRegMask(self.InputExtSrc,Shape=self.pmap.shape)
			for N in Ns:
				if np.all(InputExtSrc[self.pmap==N]):
					print "Source %d is appointed as extended according to input" % (N)
					self.src.Type[N] = -10 # <-10>
		if self.InputPntSrc is not None:
			InputPntSrc = ~DET.BkgRegMask(self.InputPntSrc,Shape=self.pmap.shape)
			for N in Ns:
				if np.all(InputPntSrc[self.pmap==N]):
					print "Source %d is appointed as unresolved according to input" % (N)
					self.src.Type[N] = 10 # <10>

		if self.OptimizeCore:
			pmap=self.pmap.copy()
			core = ((pmap==np.roll(pmap,1,axis=0)) & (pmap==np.roll(pmap,-1,axis=0)) &
					(pmap==np.roll(pmap,1,axis=1)) & (pmap==np.roll(pmap,-1,axis=1)))
			pmap[~core] = 0
			for N in Ns:
				if self.src.val4[N]>=30: continue #to save time, what's following can not happen in such bright case
				SrcN = pmap==N
				Ccts = vNmap[SrcN].sum()
				val4 = Ccts/np.sqrt(BkgP[SrcN].sum())
				if self.src.val4[N]<val4:
					if DET.debug: print self.src.Numb[N],self.src.val4[N],'->',val4,self.src.Ccts[N],'->',
					self.src.val4[N]=val4
					self.src.Ccts[N]=Ccts*self.PSF.CoreInte/self.PSF.InteInside(np.sqrt(SrcN.sum()/np.pi))
					if DET.debug: print self.src.Ccts[N]
					#self.pmap[SrcN]*=-1
			del pmap
			if DET.debug: self.saveresult(Version=DET.Version,OutFile='classify1')
			#exit()

		saveextsrccore=self.pmap.copy()
		############################################################
		#BEGIN: This section is added after Version 3.0
		Ns_pnt = Ns[~(self.src.BeExtended(N=Ns))]
		offaxis=None
		Rs = np.zeros_like(self.src.Ncts)
		for N in Ns_pnt:
			Sbkg = np.mean(BkgP[self.pmap==N])
			Rs[N] = self.PSF.fluxwhere(Sbkg*TimesBkg,self.src.Ccts[N],offaxis=offaxis)
		self.ReDrawCirclesInPmap(Numbs=Ns_pnt,Rc=Rs) #map of full circles
		#pf.writeto('a.fits',self.pmap,clobber=True)
		for N in Ns_pnt:
			X,Y = np.where(self.pmap==self.src.Numb[N])
			#print N,Rs[N],X.shape,self.src[N]
			nm = self.dmap[X,Y].argsort()
			if nm.size>self.PixNum2CalCenter: nm = nm[-self.PixNum2CalCenter::]
			ImgX = DET.wtd_median(X[nm],self.dmap[X,Y][nm])
			ImgY = DET.wtd_median(Y[nm],self.dmap[X,Y][nm])
			ImgX = int(ImgX+0.5)
			ImgY = int(ImgY+0.5)
			if saveextsrccore[ImgX,ImgY]!=N: #the center of the 2bkg circle is out of the core
				self.src.Type[N] = -12 #set it as extended <-12>
			if DET.developing:
				if (ImgX-self.src.ImgX[N])**2+(ImgY-self.src.ImgY[N])**2>1: print 'shift',self.src.ImgY[N]+1,self.src.ImgX[N]+1,'->',ImgY+1,ImgX+1
		#pf.writeto('a.fits',self.pmap,clobber=True)
		#pf.writeto('b.fits',saveextsrccore,clobber=True)
		#END: This section is added after Version 3.0
		############################################################

		'''
		############################################################
		#BEGIN: This section is added after Version 3.0
		Ns_pnt = Ns[~(self.src.BeExtended(N=Ns))]
		ReClassify = []
		offaxis=None
		Joint = self.ReDrawCirclesInPmap(Numbs=Ns_pnt,Rc=self.PSF.CoreRad,getJoin=True) #map of cores
		Adj = self.TmpFile_get('Adj')
		vmap = np.load(self.VorFile)['vmap']
		Amap = np.load(self.VorFile)['Amap']
		for N in Joint.keys():
			for NN in Joint[N]:
				#Below only for two maybe-point sources jointing each other
				AreaSeparated = {N:0,NN:0}
				CtsSeparated = {N:0,NN:0}
				SourceN1 = self.pmap==N
				SourceN2 = self.pmap==NN
				assert np.sum(SourceN1&(imap>0))==1
				assert np.sum(SourceN2&(imap>0))==1
				X1,Y1 = np.argwhere(SourceN1&(imap>0))[0]
				X2,Y2 = np.argwhere(SourceN2&(imap>0))[0]
				SourceN = (SourceN1|SourceN2)&(self.dmap>0)
				VorSitesInvolved = vmap[SourceN][self.dmap[SourceN].argsort()]
				root = X2,Y2 #NN is brighter
				low = 0
				high = np.where(VorSitesInvolved==vmap[tuple(root)])[0][0]
				VorSitesToSep = [vmap[X1,Y1]]
				bridge = VorSitesInvolved[self.FindOneBridgePixel(vmap,Adj,VorSitesInvolved,VorSitesToSep,[],high,low,root)]
				Xb,Yb = self.Px[bridge],self.Py[bridge]
				if DET.developing: file('joint.reg','w').write("circle(%d,%d,1) # color=yellow text={b}\n" %(Yb+1,Xb+1))
				assert self.dmap[X1,Y1]>self.dmap[Xb,Yb]
				VorSitesInvolved = [i for i in VorSitesInvolved if self.dmap[self.Px[i],self.Py[i]]>self.dmap[Xb,Yb]]
				#collect above-bridge pixels of source N
				visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=VorSitesInvolved,root=vmap[(X1,Y1)],GetOne=True)
				for i in visited.keys():
					if visited[i]:
						x,y = self.Px[i],self.Py[i]
						if DET.developing: file('joint.reg','a').write("circle(%d,%d,0.5) # text={%d}\n" %(y+1,x+1, N))
						AreaSeparated[N] += Amap[x,y]
						CtsSeparated[N] += self.Cmap[x,y]
				#collect above-bridge pixels of source NN
				visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=VorSitesInvolved,root=vmap[(X2,Y2)],GetOne=True)
				for i in visited.keys():
					if visited[i]:
						x,y = self.Px[i],self.Py[i]
						if DET.developing: file('joint.reg','a').write("circle(%d,%d,0.5) # text={%d}\n" %(y+1,x+1, NN))
						AreaSeparated[NN] += Amap[x,y]
						CtsSeparated[NN] += self.Cmap[x,y]
				NetCts1=CtsSeparated[N]-AreaSeparated[N]*self.dmap[Xb,Yb]
				NetCts2=CtsSeparated[NN]-AreaSeparated[NN]*self.dmap[Xb,Yb]
				if max(NetCts1,NetCts2)<4:
					self.src.Type[N] = -13 # <-13>
					self.src.Type[NN] = -13 # <-13>
					if DET.developing: file('joint.reg','a').write("circle(%d,%d,6) # text={%.1f} color=red background;circle(%d,%d,6) # text={%.1f} color=red\n" % (Y1+1, X1+1, NetCts1, Y2+1, X2+1,NetCts2))
				elif NetCts1<4:
					self.src.Type[N] = -13 # <-13>
					if DET.developing: file('joint.reg','a').write("circle(%d,%d,6) # color=blue text={reclassify}\n" % (Y2+1, X2+1))
					ReClassify.append(NN)
				elif NetCts2<4:
					self.src.Type[NN] = -13 # <-13>
					if DET.developing: file('joint.reg','a').write("circle(%d,%d,6) # color=blue text={reclassify}\n" % (Y1+1, X1+1))
					ReClassify.append(N)
				else:
					if DET.developing: file('joint.reg','a').write("circle(%d,%d,4) # text={%.1f} color=green background;circle(%d,%d,4) # text={%.1f} color=green\n" % (Y1+1, X1+1, NetCts1, Y2+1, X2+1,NetCts2))
		del Adj,vmap,Amap
		BkgP = self.ReDrawCirclesInPmap(Numbs=Ns_pnt,getNcts=True, Rc=self.PSF.CoreRad, dmap=vNmap, getBkgP=True)
		BkgP += self.Bkg
		for N in ReClassify:
			Dvalue,self.src.Type[N] = self.KStest(N,BkgP,vNmap)
			self.src.val4[N] = BkgP[self.pmap==N].sum()
			self.src.Type[N] = smirnov(self.src.Type[N],Dvalue)
			self.src.val4[N] = self.src.Ccts[N]/np.sqrt(self.src.val4[N])
		#exit()
		#END: This section is added after Version 3.0
		############################################################
		'''

		############################################################
		#Now classification is done, then makeup circles of point sources
		Ns_pnt = Ns[~(self.src.BeExtended(N=Ns))]
		Sbkg = np.zeros_like(self.src.Ncts)
		Rs = np.zeros_like(Sbkg)
		offaxis=None
		#pf.writeto('pmapp0.fits',self.pmap,clobber=True)
		#remake BkgP using only pnt srcs
		BkgP = self.ReDrawCirclesInPmap(Numbs=Ns_pnt, Rc=self.PSF.CoreRad, getBkgP=True)
		self.pmap[:,:] = saveextsrccore[:,:] #do not modify self.pmap
		BkgP += self.Bkg
		if DET.debug: pf.writeto('BkgP1.fits',BkgP,clobber=True)
		for N in Ns_pnt: #make up source radius
			Sbkg[N] = np.mean(BkgP[self.pmap==N])
			Rs[N] = self.PSF.fluxwhere(Sbkg[N]*TimesBkg,self.src.Ccts[N],offaxis=offaxis)
			#print N,Sbkg[N],self.src.Ccts[N],Rs[N]
		BkgP = self.ReDrawCirclesInPmap(Numbs=Ns_pnt,Rc=Rs,getBkgP=True) #,DelSpu=True,dmap=vNmap)
		BkgP += self.Bkg
		if DET.debug: pf.writeto('BkgP2.fits',BkgP,clobber=True)
		#pf.writeto('pmapp1.fits',self.pmap,clobber=True)
		for N in Ns_pnt:
			Sbkg[N] = np.mean(BkgP[self.pmap==N])
			if np.sum(self.pmap==N)<self.AreaLowr:
				Rs[N] = 0
				self.src.Prob[N] = 0
				self.src.Type[N] = 0
			else: Rs[N] = self.PSF.fluxwhere(Sbkg[N]*TimesBkg,self.src.Ccts[N],offaxis=offaxis)
		Ns_pnt = Ns_pnt[Rs[Ns_pnt]>=0.5]
		BkgP,Joint = self.ReDrawCirclesInPmap(Numbs=Ns_pnt,getBkgP=True,Rc=self.PSF.CoreRad,getJoin=True)
		BkgP+=self.Bkg
		self.TmpFile_new('BkgPcore',BkgP)
		BkgP,Joint = self.ReDrawCirclesInPmap(Numbs=Ns_pnt,getBkgP=True,Rc=Rs,getJoin=True)
		BkgP+=self.Bkg
		self.TmpFile_new('BkgP',BkgP)
		if DET.debug: pf.writeto('BkgP.fits',BkgP,clobber=True)
		#pf.writeto('pmapp2.fits',self.pmap,clobber=True)
		############################################################
		#search pnt which is completely inside another pnt
		pmap1 = np.roll(self.pmap,1,axis=0)
		pmap2 = np.roll(self.pmap,-1,axis=0)
		pmap3 = np.roll(self.pmap,1,axis=1)
		pmap4 = np.roll(self.pmap,-1,axis=1)
		Nudict=dict()
		for N in Joint.keys(): Nudict[N]=[]
		for x,y in np.argwhere(self.pmap>0):
			N = self.pmap[x,y]
			if N in Joint.keys():
				Nudict[N].extend([pmap1[x,y],pmap2[x,y],pmap3[x,y],pmap4[x,y]])
		for N in Joint.keys():
			#SrcN = self.pmap==N #old method
			#Nu = list(np.unique(tuple(pmap1[SrcN])+tuple(pmap2[SrcN])+tuple(pmap3[SrcN])+tuple(pmap4[SrcN])))
			Nu=list(np.unique(Nudict[N]))
			if len(Nu)==2:
				Nu.remove(N)
				if Nu[0]>0: #N is completely surrounded a pnt src Nu[0], not by 0
					if self.src.MaybeExtended(N): # unless it's a reliable pnt
						self.src.Type[N] = -11 # <11> set it as extended
						self.pmap[self.pmap==N] = 0
			else:
				assert len(Nu)>2
		del pmap1,pmap2,pmap3,pmap4,Nudict
		############################################################
		Ns_ext = Ns[self.src.BeExtended(N=Ns)]
		pmapwithextcore=self.pmap.copy()
		#pf.writeto('pwec0.fits',pmapwithextcore,clobber=True)
		for N in Ns_ext:
			pmapwithextcore[saveextsrccore==N] = saveextsrccore[saveextsrccore==N]
		del saveextsrccore
		#pf.writeto('pwec1.fits',pmapwithextcore,clobber=True)
		#exit()
		pmap1 = np.roll(pmapwithextcore,1,axis=0)
		pmap2 = np.roll(pmapwithextcore,-1,axis=0)
		pmap3 = np.roll(pmapwithextcore,1,axis=1)
		pmap4 = np.roll(pmapwithextcore,-1,axis=1)
		Nudict=dict()
		for N in Ns_ext: Nudict[N]=[]
		for x,y in np.argwhere(pmapwithextcore>0):
			N = pmapwithextcore[x,y]
			if N in Ns_ext:
				Nudict[N].extend([pmap1[x,y],pmap2[x,y],pmap3[x,y],pmap4[x,y]])
		for N in Ns_ext:
			if self.src.Prob[N] > 10:
				#print '>5',self.src[N]
				continue
			#SrcN = pmapwithextcore==N
			#Nu = list(np.unique(tuple(pmap1[SrcN])+tuple(pmap2[SrcN])+tuple(pmap3[SrcN])+tuple(pmap4[SrcN])))
			Nu=list(np.unique(Nudict[N]))
			if len(Nu)==2:
				Nu.remove(N)
				#print 'de',self.src[N]
				if Nu[0]>0: #faint extended core inside a bright pnt src
					self.src.Prob[N] = 0 #delete
					pmapwithextcore[pmapwithextcore==N] = Nu[0]
			else:
				#print 'ok',self.src[N]
				assert len(Nu)>2
		del pmap1,pmap2,pmap3,pmap4,Nudict
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmpj')
		#exit()

		#Discussion
		#1. It's infeasible to reclassify pnt sources within full circles, large circles make spurious extended sources
		#2. Either with the circle which reaches 3 times bkg. Such a radius is calculated with the core cts, which is higher for real Pnt src, lower for Ext.
		#3. Varying core size is not the right way. It varies too much.
		#A small core circle slightly larger than HEW is a good choice. However it's only OK for point sources, it would be too small for some extended sources. So we can't identify extended source within this circle, we can identify point source within this circle.

		self.pmap[(self.dmap<=self.Bkg)] = 0

		#Calculate src info (specially Prob), ImgX,ImgY not changed
		pmapwithextcore[self.dmap<=self.Bkg] = 0
		#pf.writeto('pc.fits',pmapwithextcore,clobber=True)
		self.CalSrc(Bkg=BkgP,pmap=pmapwithextcore,ToCalCenter=False)
		del pmapwithextcore
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmpy0')
		#exit()
		self.PreDel()
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tmpy1')
		#exit()
		#for N in Ns_ext: self.pmap[self.pmap==N] = 0
	#END_OF_Core_ClafySrc
	def CumuCurve(self,Dist=None,Val=None,Psf=None,offaxis=None):
		assert Dist.shape==Val.shape
		asort = np.argsort(Dist)
		v = Val[asort]
		if Psf is not None and offaxis is None:
			p = Psf[asort]
			Rat_v_p = np.average(v/p,weights=1/(Dist[asort]+1)**2)
			Ccts = p.sum()*Rat_v_p
			v = np.float64(v.cumsum()/v.sum())
			p = np.float64(p.cumsum()/p.sum())
			#scipy need float64
			pcurve = ip.interp1d(p,np.arange(1,p.size+1),kind='slinear',bounds_error=False,fill_value=-1)
			#DET.convex(v,reverse=True)
			P = pcurve(v)
			P[P==-1] = np.arange(1,P.size+1)[P==-1]
		if Psf is None and offaxis is not None:
			d = np.sqrt(np.arange(1,v.size+1)/np.pi)
			Ccts = np.average(v/self.PSF.getflux(d,1),weights=1/d**2)
			v = v.cumsum() / v.sum() * self.PSF.getfraction(np.sqrt(Val.size/np.pi),offaxis=offaxis)
			#DET.convex(v,reverse=True)
			P = np.array([np.pi*self.PSF.getradius(f,offaxis=offaxis)**2 for f in v])
			p=None
		return np.float32(v),np.float32(P),p,Ccts
	#END_OF_CumuCurve

	def MakeSrcRegion(self):
		#Compare the initial FOF result pmap0 (in which sources are highly blended)
		#with imap, which contains new detected one-pixel sources resulting from FOF on contour scales.
		#if one source in pmap0 contains more than one new sources in imap
		#then it's blended, separate it into new sources, and save in pmap0.
		#Put the extended sources in pmap0 into self.pmap

		if 'imap' not in self.TmpFile.keys(): return
		print color("\nSeparating Extended Sources from Point Sources",32,0)

		#restore the imap, which contains all the one-pixel sources, all of which fall on occupied pixels, and all separatable
		imap = self.TmpFile_get('imap')
		coremap = self.TmpFile_get('coremap')
		#pf.writeto('imap0.fits',imap,clobber=True)
		#delete the one-pixel sources which are already deleted
		#and mark extended sources with negative numbers
		for x,y in np.argwhere(imap>0):
			if self.src.Prob[imap[x,y]]<self.ProbLowr: #sth has happened after this imap generated
				coremap[coremap==imap[x,y]] = 0
				imap[x,y] = 0
			elif self.src.BeExtended(imap[x,y]): imap[x,y]*=-1 #negative means extended
		#pf.writeto('imap1.fits',imap,clobber=True)
		self.TmpFile_set('coremap',coremap)
		del coremap

		#think about this paragraph ??
		#self.pmap now contains pnt src regions
		Numb_pntsrc_imap_selfpmap=np.unique(imap)
		Ns=np.unique(self.pmap)
		Numb_pntsrc_imap_selfpmap=Numb_pntsrc_imap_selfpmap[Numb_pntsrc_imap_selfpmap>0]
		Ns=Ns[Ns>0]
		assert np.all(Numb_pntsrc_imap_selfpmap==Ns)
		self.pmap[imap>0] = imap[imap>0]
		#Save_Ext_in_Pnt = imap[(imap<0)&(self.pmap>0)]
		#self.pmap[imap<0] = imap[imap<0]	#lewton Feb 19 2014, dont' even save ext positions anymore
		#mark extended sources in self.pmap which has only circles of pnt src
		#only pnt src have their regions saved in self.pmap, others only have their numbers marked
		self.src.Prob[self.src.BeExtended()|(self.src.Prob<self.ProbLowr)] = 0 #delete ext sources

		Adj = self.TmpFile_get('Adj')
		vmap = np.load(self.VorFile)['vmap']

		#Sources which lie between curve1 and curve2
		#whose PSF predicted circles do not overflow the FOF edges are taken as extended sources.
		#They are marked with the highest probability of being extended.
		pmap0=self.TmpFile_get('pmap0')
		tmap0=np.zeros_like(pmap0)
		vdmap = self.TmpFile_get('vdmap')
		#pf.writeto('vdmap.fits',vdmap,clobber=True)
		#pf.writeto('vmap.fits',vmap,clobber=True)

		#Old method as published in the paper is comparing the FoF detected region with the PSF circle which ends at the local flux of FoF involved lower limit.
		#There are two disadvantages
		#1. it may lose clusters (especially high-z) whose extended emission has a small scale
		#2. at large radius (PSF wing) the radius is too sensitive to local flux, the circle calculated according to the local flux (bkg level) is not accurate.
		#The new method is first selecting a small circle, then comparing it with a new FoF region modified according to the new lower limit -- the PSF value at this radius.
		#Some very large scale diffuse emission may be lost because at the small radius it's too weak compared to the domaniting point source. However,
		#1. such extended source should be very faint, and such case with a bright overlapping point source should be rare;
		#2. if it's large enough (more extended than the point source region), the diffuse emission outside the point source region can still be detected.
		#One tip to improve: peel the Nout+2 circle part??
		Nout=7
		IndX,IndY = np.indices((2*Nout+1,2*Nout+1))-Nout
		IndD = np.sqrt(IndX**2+IndY**2)
		if DET.developing:
			if os.path.isfile('comwing.reg'): os.remove('comwing.reg')
			fcomwing=file('comwing.reg','a')
		for N in Numb_pntsrc_imap_selfpmap:
			if DET.debug: print 'recheck',N
			SrcN = self.pmap==N
			if not SrcN.any(): continue
			if self.src.MaybeExtended(N) and self.src.Type[N]!=10: # <10>
			# <10> means highest priority to be point source
				x0,y0=int(self.src.ImgX[N]+0.5),int(self.src.ImgY[N]+0.5)
				if DET.debug: print 'check',N,x0,y0
				indX = IndX[max(Nout-x0,0):min(Nout,self.pmap.shape[0]-1-x0)+Nout+1,max(Nout-y0,0):min(Nout,self.pmap.shape[1]-1-y0)+Nout+1]
				indY = IndY[max(Nout-x0,0):min(Nout,self.pmap.shape[0]-1-x0)+Nout+1,max(Nout-y0,0):min(Nout,self.pmap.shape[1]-1-y0)+Nout+1]
				indD = IndD[max(Nout-x0,0):min(Nout,self.pmap.shape[0]-1-x0)+Nout+1,max(Nout-y0,0):min(Nout,self.pmap.shape[1]-1-y0)+Nout+1]
				offaxis=None

				Sbkg = np.mean([self.Bkg[x,y] for (x,y) in [[x0,y0],[x0+1,y0],[x0-1,y0],[x0,y0+1],[x0,y0-1],[x0+1,y0+1],[x0+1,y0-1],[x0-1,y0+1],[x0-1,y0-1],
				[x0+2,y0],[x0+3,y0],[x0+4,y0],[x0+5,y0],
				[x0-2,y0],[x0-3,y0],[x0-4,y0],[x0-5,y0],
				[y0+2,x0],[y0+3,x0],[y0+4,x0],[y0+5,x0],
				[y0-2,x0],[y0-3,x0],[y0-4,x0],[y0-5,x0]
				] if (x>=0)&(y>=0)&(x<self.pmap.shape[0])&(y<self.pmap.shape[1]) ])
				#peelthreshold=self.PSF.getflux(Nout,self.src.Ccts[N]+np.sqrt(self.src.Ccts[N]),offaxis=offaxis)+Sbkg/2 #lewton Feb 24 2014
				peelthreshold=self.PSF.getflux(Nout,self.src.Ccts[N],offaxis=offaxis)+Sbkg #lewton Feb 25 2014
				root=(x0,y0)
				if pmap0[root]==0: root = next(((x,y) for (x,y) in [[x0,y0],
				[x0+1,y0+0],[x0-1,y0+0],[x0+0,y0+1],[x0+0,y0-1],
				[x0+1,y0+1],[x0+1,y0-1],[x0-1,y0+1],[x0-1,y0-1],
				[x0+0,y0+2],[x0+0,y0-2],[x0+2,y0+0],[x0-2,y0-0],
				[x0+2,y0+1],[x0+2,y0-1],[x0-2,y0+1],[x0-2,y0-1],
				[x0+1,y0+2],[x0+1,y0-2],[x0-1,y0+2],[x0-1,y0-2],
				[x0+2,y0+2],[x0+2,y0-2],[x0-2,y0+2],[x0-2,y0-2]] if pmap0[x,y]>0),None)
				assert root is not None #it may happen, but an empty hole in the center? it must be very faint
				N0=pmap0[root]
				SourceN = pmap0==N0
				tmap0[:,:]=0
				tmap0[SourceN] = -1
				if peelthreshold<=Sbkg:
					if DET.debug: print "VeryFaint,Pnt",N0,"Core",self.src.Ccts[N],"at",Nout,"got",peelthreshold,Sbkg
					#In principle, such case is extended. However we set them as possible pnt src, in the sense that most sources are pnt. Some fluctuations inside ext src may be set as possible pnt here too, they will be further checked later.
					self.src.Type[N] = 7 # <7>
					continue
				else:
					if DET.debug: print "peel",N0,"Core",self.src.Ccts[N],"at",Nout,"got",peelthreshold,Sbkg
					#peel: delete outer pixels by changing -1 to 0
					Skins = [n for n in np.unique(vmap[(tmap0==-1)]).tolist()
						if any((tmap0[self.Px[i],self.Py[i]]==0 for i in Adj[n])) and vdmap[self.Px[n],self.Py[n]]<peelthreshold]
					Nskin=1
					while Skins:
						for n in Skins:
							if DET.developing: print >>fcomwing, "circle(%d,%d,0.5) # text={%d}" %(self.Py[n]+1,self.Px[n]+1,Nskin)
							tmap0[self.Px[n],self.Py[n]] = 0
						Nskin+=1
						Skins = [n for n in np.unique(vmap[(tmap0==-1)]).tolist()
							if any((tmap0[self.Px[i],self.Py[i]]==0 for i in Adj[n])) and vdmap[self.Px[n],self.Py[n]]<peelthreshold]
					#delete other sources blended together if possible
					#try to do this because we are peeling the source in pmap0, which may be a big blended source
					Pix = vmap[tmap0==-1]
					visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix,root=vmap[root],GetOne=True)
					for n in visited.keys():
						if visited[n]==self.Nsource: tmap0[self.Px[n],self.Py[n]]=N0
					'''
					xm,ym = np.median(np.argwhere(tmap0==N0),axis=0)
					#if can't delete, it seems to be inside another source, keep them as pnt src
					if (xm-x0)**2+(ym-y0)**2 > self.PSF.CoreRad**2:
						print (xm-x0)**2+(ym-y0)**2,self.PSF.CoreRad,xm,ym,x0,y0
						if DET.debug: print N,N0,y0+1,x0+1,ym+1,xm+1,'inside'
						continue
					'''
					if tmap0[root] == 0: #more generous
						if DET.debug: print N,N0,y0+1,x0+1,ym+1,xm+1,'specialcase'
						continue
					if DET.developing:
						print >>fcomwing, "circle(%d,%d,%d) # color=red tag={%04d}" %(y0+1,x0+1,Nout,N)
						#for x,y in np.argwhere(tmap0==N0):
						#	print >>fcomwing, "circle(%d,%d,0.5) # color=blue tag={%04d}" %(y+1,x+1,N)
						tmap0[tmap0<0] = 0
						tmap0[tmap0==N0] = N
						self.SaveVorReg(fcomwing,pmap=tmap0)
				insi=indD<=Nout
				xi,yi = indX[insi]+x0,indY[insi]+y0
				####################
				#Comparing area is better than comparing flux, because for faint sources, the underlying diffuse flux can be very low (<1.0photon) in total, however the area may be large.
				####################
				#ATTENTION: after converted to vmap index, they changed from all the points inside the circle to all related occupied pixels (some out of the circle)
				#number of cells overflowing the FoF edge but inside a radius of Nout (not exactly inside)
				#nn = filter(lambda n:tmap0[self.Px[n],self.Py[n]]==0,np.unique(vmap[xi,yi]))
				#OverFlowNumber=len(nn)
				####################
				#Feb 22 2014, I change from checking overflowing number of cells to checking overflowing number of pixels.
				nn = filter(lambda n:tmap0[self.Px[n],self.Py[n]]==0,vmap[xi,yi])
				OverFlowNumber=len(nn)
				####################
				if OverFlowNumber<self.OverFlowLevel:
					#PSF circle is completely surrounded by the FoF region, there should be underlying diffuse emission
					#print "circle(%.1f,%.1f,10) # color=magenta text={7ext %d} width=2" % (y0+1,x0+1,OverFlowNumber)
					#if DET.debug: print N,'ext',OverFlowNumber
					imap[SrcN] = -abs(imap[SrcN])
					self.src.Type[N] = -abs(self.src.Type[N])
					#self.pmap[SrcN] = imap[SrcN]
					self.pmap[SrcN] = 0 #lewton Feb 19 2014
					#LowType MARK: Here the src is not yet extended after coremap built
					#so the modifiation can be preserved using coremap and src
				else:
					#unreliable pnt src, need further checking
					#print "circle(%.1f,%.1f,10) # color=green text={7pnt %d} width=2" % (y0+1,x0+1,OverFlowNumber)
					if DET.debug:
						print N,'pnt',y0+1,x0+1,OverFlowNumber,':',
						#for nnn in nn: print '-',self.Py[nnn]+1,self.Px[nnn]+1,
						#print
						#for n  in range(xi.size): #print vmap[xi[n],yi[n]] in nn
						#for nnn in filter(lambda n:tmap0[self.Px[vmap[xi[n],yi[n]]],self.Py[vmap[xi[n],yi[n]]]]==0,range(xi.size)): print '-',yi[nnn]+1,xi[nnn]+1,
						for x,y in filter(lambda (x,y):vmap[x,y] in nn, zip(xi,yi)): print '-',y+1,x+1,
						print
					#lewton imap[SrcN] = 0 #It's not reliable point sources, delete it from the point sources list
					#so that it won't be removed from extended source region (involved in next FoF run)
					#lewton self.src.Prob[N] = 0
					self.src.Type[N] = 7 # <7>
			#END_OF_if self.src.MaybeExtended
			#Above, point sources go into three types:
			#1. Prob > Upper curve, keep as point sources
			#2. Lower curve < Prob < Upper curve
			#	2.1 if reclassified as extended sources with the peeling method, change type to extended
			#	2.1 else, mark as 7, which at last will be taken as point sources. However, here, it is deleted from imap
			#		thus does not appear as point source, will not be removed from extended source region.
		#About this method:
		#1. "circle overflowing FoF" is better than "annual check", because the latter one can be affected by nearby source, while the first not.
		#2. comparing Nout=10 with FoF is right, while comparing the whole PSF region with the whole FoF is wrong. Because the underlying diffuse emission may have a sale << whole PSF radius
		#END_OF_for N in 
		del vdmap
		if DET.developing: fcomwing.close()
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='pnt')
		#exit()

		#restore the initial FOF result
		pmap0=self.TmpFile_get('pmap0')
		self.TmpFile_del('pmap0')
		assert (pmap0>=0).all()
		if DET.debug: tmpfile=file('tmpbridge.reg','w')
		self.pmap[(pmap0==0)&(imap==0)] = 0 #No more pixel than pmap0
		#pf.writeto('1.fits',self.pmap,clobber=True)
		#pf.writeto('2.fits',pmap0,clobber=True)
		for NN in Numb_pntsrc_imap_selfpmap:
			if self.src.Type[NN] == 7: # <7>
				X0,Y0 = np.argwhere(imap==NN)[0] #only one pixel in imap marked as NN
				N = pmap0[X0,Y0]
				SourceN = pmap0==N
				#print "circle(%d,%d,5) # color=cyan" % (self.src.ImgY[NN]+1,self.src.ImgX[NN]+1)
				if DET.debug: print NN,N,np.sum(SourceN), np.sum(imap[SourceN]!=0)
				assert N>0 and np.sum(SourceN)>0
				if np.sum(imap[SourceN]!=0)>1:
					if DET.debug: print NN,N, self.src.ImgY[NN]+1,self.src.ImgX[NN]+1,
					imap[X0,Y0] = 0
					VorSitesToSep = list(vmap[SourceN&(imap!=0)])
					root = (X0,Y0)
					visited,bridge = self.FindBridgePixels(vmap,Adj,SourceN,VorSitesToSep,root)
					bridgeBkg = np.mean(self.dmap[self.Px[bridge],self.Py[bridge]])
					Prob = self.src.Ncts[NN]/np.sqrt(self.src.Area[NN]*bridgeBkg) #??sqrt??
					#print Prob, self.src.Ncts[NN]/(self.src.Area[NN]*bridgeBkg), self.src.Ncts[NN]
					#if Prob<=self.ReliProbLowr: #ext
					if self.src.Ncts[NN]/(self.src.Area[NN]*bridgeBkg)<1:
						if DET.debug: print bridgeBkg,Prob,'ext'
						#print "circle(%.1f,%.1f,20) # color=yellow text={Ext %.2f} width=2" % (Y0+1,X0+1,self.src.Ncts[NN]/(self.src.Area[NN]*bridgeBkg))
						imap[X0,Y0] = -NN
						self.src.Type[NN] = -7 # <7>
						SrcN = self.pmap==NN
						self.pmap[SrcN] = 0
					else: #pnt
						if DET.debug: print bridgeBkg,Prob,'pnt'
						#print "circle(%.1f,%.1f,20) # color=yellow text={No ext %.2f} width=2" % (Y0+1,X0+1,self.src.Ncts[NN]/(self.src.Area[NN]*bridgeBkg))
						imap[X0,Y0] = NN
						self.src.Type[NN] = 7 # <7>
					if DET.debug:
						for p in (('circle(%d,%d,1) # color=blue width=2\n' % (self.Py[n]+1,self.Px[n]+1)) for n in bridge):
							tmpfile.write(p)
		if DET.debug: tmpfile.close()

		if DET.developing: bfile = file('bridge.reg','w')
		#pf.writeto('3.fits',self.pmap,clobber=True)
		#pf.writeto('4.fits',pmap0,clobber=True)
		#exit()

		#VorFile = np.load(self.VorFile)
		#Esid = VorFile['Esid']
		#Eend = VorFile['Eend']
		#del VorFile
		#site = np.zeros((Esid.shape[0],2),dtype='int32')
		#site[:,0] = pmap0[tuple(Esid[:,0:2].T)]
		#site[:,1] = pmap0[tuple(Esid[:,2:4].T)]

		#Separate point src from ext src
		#pf.writeto('0.fits',pmap0,clobber=True)
		#pf.writeto('i.fits',imap,clobber=True)
		#pf.writeto('p.fits',self.pmap,clobber=True)
		#exit()
		Amap = np.load(self.VorFile)['Amap']
		BkgP=self.TmpFile_get('BkgPcore')
		Nmap = self.Cmap - Amap*BkgP
		N = 1
		Elist = []
		Plist = [] #this Plist method can be faster than modify pmap inside iteration, but may result in some un-connected pnt src
		#here I ignore this, taking such possible exclave as valid
		while N<self.Nsource:
			SourceN = pmap0==N
			if not SourceN.any():
				N += 1
				continue
			if (imap[SourceN]<=0).all(): #including only ext sources or nothing
				#pmap0[SourceN] = -1
				Elist.append(N)
			elif (imap[SourceN]>=0).all(): #including only pnt sources
				NN = imap[SourceN]
				NN = np.unique(NN)
				NN = NN[NN>0].tolist()
				#pmap0[SourceN] = -1
				Elist.append(N)
				Plist.extend(NN)
			else: #ext src blended with pnt src
				while (imap[SourceN]<0).any() and (imap[SourceN]>0).any():
					if DET.debug: print N,'/',self.Nsource,np.unique(imap[SourceN]),'------------------------',
					VorSitesToSep = list(vmap[SourceN&(imap>0)])
					root = tuple(np.argwhere(SourceN&(imap<0))[0]) #starting from one extended source
					visited,bridge = self.FindBridgePixels(vmap,Adj,SourceN,VorSitesToSep,root)
					v_b = visited+bridge
					pmap0[self.Px[v_b],self.Py[v_b]] = -1
					SourceN = pmap0==N

					if np.sum(SourceN)<self.AreaLowr: #the pnt part is not robust, delete it
						print 'pnt delete', np.unique(imap[SourceN])
						for nn in np.unique(imap[SourceN]):
							if nn>0: self.src.Prob[nn] = 0
						imap[SourceN] = 0
						pmap0[SourceN] = -1
					else:
						Ncts = np.sum(Nmap[self.Px[visited],self.Py[visited]])
						Area = np.sum(Amap[self.Px[visited],self.Py[visited]])
						bridgeBkg = self.dmap[self.Px[bridge],self.Py[bridge]]
						bridgeBkg = np.average(bridgeBkg,weights=bridgeBkg)
						#Prob = Ncts/np.sqrt(Area*bridgeBkg) #??sqrt??
						#print 'lewton',root,Ncts,Area,bridgeBkg,Ncts/(Area*bridgeBkg)
						if Ncts/(Area*bridgeBkg)<1 or Area<self.AreaLowE:
						#if Prob<=self.ReliProbLowr: #the ext part is not robust, return its area to nearby pnt srcs
							if DET.debug: print bridgeBkg,'delete',imap[root]
							#print "circle(%.1f,%.1f,20) # color=white text={no sep %.2f} width=2" % (root[1]+1,root[0]+1, Ncts/(Area*bridgeBkg))
							self.src.Prob[-imap[root]] = 0
							imap[root] = 0
							v_b = filter(lambda n:self.pmap[self.Px[n],self.Py[n]]>0,v_b)
							pmap0[self.Px[v_b],self.Py[v_b]] = N
							SourceN = pmap0==N
							if DET.developing:
								for p in (('circle(%d,%d,0.5) # color=green\n' % (self.Py[n]+1,self.Px[n]+1)) for n in visited): bfile.write(p)
						else: #pnt
							if DET.debug: print bridgeBkg,'keep',imap[root]
							#print "circle(%.1f,%.1f,20) # color=white text={Sep %.2f} width=2" % (root[1]+1,root[0]+1, Ncts/(Area*bridgeBkg))
							if DET.developing:
								for p in (('circle(%d,%d,0.5) # color=red\n' % (self.Py[n]+1,self.Px[n]+1)) for n in visited): bfile.write(p)
						if DET.developing:
							for p in (('circle(%d,%d,0.5) # color=blue\n' % (self.Py[n]+1,self.Px[n]+1)) for n in bridge): bfile.write(p)
				#END_OF_while (imap[SourceN]<0).any() and (imap[SourceN]>0).any():
			N += 1
		#END_OF_while N<self.Nsource:
		del Nmap,Amap,BkgP
		if DET.developing: bfile.close()
		#Prepare pmap0 for re-detection
		for p in itertools.ifilter(lambda p:pmap0[p[0],p[1]] in Elist,np.argwhere(pmap0>0)):
			#deblended ext srcs have their regions decided above in separation
			#other non pnt srcs are all deleted and involded in next FOF run
			pmap0[p[0],p[1]] = -1 #<0 means will be involved in next FOF run
		for p in itertools.ifilter(lambda p:self.pmap[p[0],p[1]] in Plist,np.argwhere(self.pmap>0)):
			#remove isolated pnt src from next FOF run, regions for these sources are full psf region calculated above
			#blended pnt src were not included in next FOF run, only the extended parts were involved.
			#so all the pnt srcs have their regions saved in self.pmap
			#but isolated ones have full circle, while deblended ones may have part taken by ext srcs.
			pmap0[p[0],p[1]] = 0 #=0 means not involved in next FOF run
		pmap0[(pmap0>0)&(self.pmap<=0)] = -1
		assert (imap[pmap0<0]<=0).all()
		del imap
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='t0')
		#redetect the extended sources cleand from pnt src contamination, mark with self.Nsource
		#in order to avoid big ext src being separaed into pieces

		#Before, self.Nsource is associated with pmap0 (first FoF and FoF in separation)
		#From now on, pmap0 is no longer used, and self.Nsource is associated with self.src
		self.Nsource = self.src.Nsrc

		toon = pmap0<0
		Pix = vmap[toon]
		self.Nsource,visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix)
		pmap0[toon] = [visited[n] for n in Pix]
		del toon,Pix,Adj
		#make up the src list for the new ext sources
		Nsrc = self.src.Nsrc
		self.src = self.src.extend(self.src.Nsrc,self.Nsource-1)
		#modify self.pmap according to pmap0, replace old soures with the new ext ones
		for N in xrange(Nsrc,self.Nsource):
			SourceN = pmap0==N
			NN = np.unique(self.pmap[SourceN])
			#print NN,N
			self.pmap[SourceN] = pmap0[SourceN]
		BkgP=self.TmpFile_get('BkgP')
		self.CalSrc(Bkg=BkgP)
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='tp')
		self.CalSrc(Bkg=BkgP,Nmin=Nsrc,ToGetCoreInfo=True,LowType=-3,ToCalCenter=True)
		#LowType MARK: these sources detected by FoF but having not cores found inside
		#is where FoF shows its ability to detect faint extended sources
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='t1')
		self.PreDel()
		if DET.debug: self.saveresult(Version=DET.Version,OutFile='t2')
		#exit()
	#END_OF_MakeSrcRegion(self):

	def ReDrawCirclesInPmap(self,**kwargs):
		#rebuild self.pmap accordint to src.Ccts, src.ImgX, src.ImgY
		#calculate src.Ncts, src.Area if requested
		self.pmap[:,:] = 0 #rebuilt
		src    = kwargs.pop('src',self.src)
		Numbs  = kwargs.pop('Numbs',np.where(src.Ccts>0)[0]) #Ccts must be initialized in advance
		getBkgP= kwargs.pop('getBkgP',False) #map of the point source wing which can be added to self.Bkg
		Rc     = kwargs.pop('Rc',None) #set a fixed value or calculate here due to PSF and local Bkg
		dmap   = kwargs.pop('dmap',None)
		Sbkg   = kwargs.pop('Sbkg',None)
		DelSpu = kwargs.pop('DelSpu',False) #delete fluctuations in bright PSF wing
		getNcts= kwargs.pop('getNcts',False) or DelSpu
		getArea= kwargs.pop('getArea',False) or DelSpu
		getJoin= kwargs.pop('getJoin',False)
		OverLap= kwargs.pop('OverLap',False) #defaultly Non OverLap
		assert Rc is not None
		if getNcts:
			Ncts = src.Ncts
			Ncts[:] = 0
		if DelSpu:
			Bcts=np.zeros_like(Ncts)
			getBkgP=True
			getArea=True
		if getArea:
			Area = src.Area
			Area[:] = 0
		if getBkgP:
			BkgP = np.zeros_like(self.Bkg)
		if getJoin:
			Joint=dict()
		if not getBkgP and np.ndim(Rc)==0: Nbox=Rc
		else: Nbox = self.PSF.Npsf
		if np.ndim(Rc)>0: assert np.all(Rc[Numbs]>=0.5)
		IndX,IndY = np.indices((2*Nbox+1,2*Nbox+1))-Nbox
		IndD = np.sqrt(IndX**2+IndY**2)
		if np.ndim(Rc)==0: RcN = Rc
		for N in Numbs[src.Ccts[Numbs].argsort()[::-1]]: #so that DelSpu can work with BkgP while BkgP is being generated
			x0 = np.int32(src.ImgX[N]+0.5)
			y0 = np.int32(src.ImgY[N]+0.5)
			if self.PSF.Instrum == 'SWIFT': offaxis=None
			elif self.PSF.Instrum == 'WFXT': offaxis = np.sqrt(((self.pmap.shape[0]-1)/2.-x0)**2 + ((self.pmap.shape[1]-1)/2.-y0)**2)
			elif self.PSF.Instrum == 'CHANDRA': offaxis=[x0,y0]

			#not out of image
			indX = IndX[max(Nbox-x0,0):min(Nbox,self.pmap.shape[0]-1-x0)+Nbox+1,max(Nbox-y0,0):min(Nbox,self.pmap.shape[1]-1-y0)+Nbox+1]
			indY = IndY[max(Nbox-x0,0):min(Nbox,self.pmap.shape[0]-1-x0)+Nbox+1,max(Nbox-y0,0):min(Nbox,self.pmap.shape[1]-1-y0)+Nbox+1]
			indD = IndD[max(Nbox-x0,0):min(Nbox,self.pmap.shape[0]-1-x0)+Nbox+1,max(Nbox-y0,0):min(Nbox,self.pmap.shape[1]-1-y0)+Nbox+1]

			if np.ndim(Rc)==1:
				RcN = Rc[N]
				#if RcN < 2: continue #lower limit of Radius
				if RcN > Nbox:
					Nbox = int(RcN+1)
					tmpIndX,tmpIndY = np.indices((2*Nbox+1,2*Nbox+1))-Nbox
					tmpIndD = np.sqrt(tmpIndX**2+tmpIndY**2)
					indX = tmpIndX[max(Nbox-x0,0):min(Nbox,self.pmap.shape[0]-1-x0)+Nbox+1,max(Nbox-y0,0):min(Nbox,self.pmap.shape[1]-1-y0)+Nbox+1]
					indY = tmpIndY[max(Nbox-x0,0):min(Nbox,self.pmap.shape[0]-1-x0)+Nbox+1,max(Nbox-y0,0):min(Nbox,self.pmap.shape[1]-1-y0)+Nbox+1]
					indD = tmpIndD[max(Nbox-x0,0):min(Nbox,self.pmap.shape[0]-1-x0)+Nbox+1,max(Nbox-y0,0):min(Nbox,self.pmap.shape[1]-1-y0)+Nbox+1]
			insi = indD<=RcN
			xi,yi = indX[insi]+x0,indY[insi]+y0
			some = (self.pmap[xi,yi]==0)
			if some.any():
				self.pmap[xi[some],yi[some]] = N
				if getNcts: Ncts[N] += dmap[xi[some],yi[some]].sum() #vd or vN?
				if getArea: Area[N] += some.sum()
				if DelSpu:
					Bcts[N] += BkgP[xi[some],yi[some]].sum()
			self.pmap[x0,y0] = N #at least one pixel, so the resulting core map will have the same number of sources
			some = np.where((self.pmap[xi,yi]>0)&(self.pmap[xi,yi]!=N))[0]
			for i in some:
				xx,yy = xi[i],yi[i]
				NN = self.pmap[xx,yy]
				xx0 = np.int32(src.ImgX[NN]+0.5)
				yy0 = np.int32(src.ImgY[NN]+0.5)
				disdif = self.PSF.getflux(np.sqrt((xx-x0)**2 + (yy-y0)**2),src.Ccts[N], offaxis=offaxis) \
						- self.PSF.getflux(np.sqrt((xx-xx0)**2+(yy-yy0)**2),src.Ccts[NN],offaxis=offaxis)
				if disdif>0 or disdif==0 and np.random.random()>0.5:
					self.pmap[xx,yy] = N
					if getNcts: Ncts[N] += dmap[xx,yy]
					if not OverLap and getNcts: Ncts[NN] -= dmap[xx,yy]
					if DelSpu: Bcts[N] += BkgP[xx,yy]
					if getArea: Area[N] += 1
					if not OverLap and getArea: Area[NN] -= 1
				if getJoin:
					if src.Ccts[N]<src.Ccts[NN]:
						JointItem = Joint.get(N,[])
						if NN not in JointItem: Joint[N] = JointItem+[NN]
					else:
						JointItem = Joint.get(NN,[])
						if N not in JointItem: Joint[NN] = JointItem+[N]
			if DelSpu:
				#if Ncts[N]-Bcts[N] < np.sqrt(Bcts[N])*self.ProbLowr or Ncts[N]-Bcts[N] < Bcts[N]*0.5:
				if Ncts[N]-Bcts[N] < np.sqrt(Bcts[N])*self.ProbLowr or Ncts[N]-Bcts[N] < Bcts[N]*0.5 or Area[N] < self.AreaLowr:
					self.pmap[self.pmap==N] = 0
					continue
			outs = (indD>RcN)&(self.pmap[indX+x0,indY+y0]==0) #So that bright pnt src can increase the bkg at faint src position, while faint pnt src can not increase the bkg at bright src position.
			if getBkgP: BkgP[indX[outs]+x0,indY[outs]+y0] += self.PSF.getflux(indD[outs],src.Ccts[N],offaxis=offaxis)
		#END_OF_for N in Numbs:
		if getBkgP and getJoin: return BkgP,Joint
		elif getBkgP: return BkgP
		elif getJoin: return Joint
	#END_OF_def ReDrawCirclesInPmap(self,**kwargs):

#}}}
	def IncludeBridge(self,pmap,bridge,Adj=None): #not used
		def NearestSource(pmap,N):#{{{
			X,Y = self.Px[Adj[N]],self.Py[Adj[N]]
			Non0 = pmap[X,Y]!=0
			X,Y = X[Non0],Y[Non0]
			if X.size==0:
				return False
			elif X.size==1:
				pmap[self.Px[N],self.Py[N]] = pmap[X,Y]
				return True
			elif X.size>0:
				d = (X-self.Px[N])**2+(Y-self.Py[N])**2
				dmin = d==d.min()
				if dmin.sum()==1:
					pmap[self.Px[N],self.Py[N]] = pmap[X[dmin],Y[dmin]]
				else:
					NearSrc = pmap[X[dmin],Y[dmin]]
					nummax = 0
					SrcMax = 0
					for NSrc in np.unique(NearSrc):
						thisnummax = (NearSrc==NSrc).sum()
						if thisnummax>nummax:
							nummax = thisnummax
							SrcMax = NSrc
					assert SrcMax!=0
					pmap[self.Px[N],self.Py[N]] = SrcMax
				return True
		#END_OF_NearestSource
		pmap[self.Px[bridge],self.Py[bridge]] = 0
		tmpbridge=[]
		for N in bridge:
			x,y = self.Px[N],self.Py[N]
			if pmap[x,y]==0:
				if NearestSource(pmap,N):
					for n in tmpbridge:
						if NearestSource(pmap):
							tmpbridge.remove(n)
				else:
					tmpbridge.append(N)
		if len(tmpbridge)>0:
			print tmpbridge
			sys.exit("How come no relative:")
#}}}

	def FindBridgePixels(self,vmap,Adj,SourceN,VorSitesToSep,root):
		bridge=[]
		VorSitesInvolved = vmap[SourceN][self.dmap[SourceN].argsort()]
		low = 0
		high = np.where(VorSitesInvolved==vmap[tuple(root)])[0][0]
		assert high>=1
		while True: #until all the bridge pixels are found
			low = self.FindOneBridgePixel(vmap,Adj,VorSitesInvolved,VorSitesToSep,bridge,high,low,root)
			bridge.append(VorSitesInvolved[low])
			low,high = 0,low #next bridge pixel should be lower than this one
			#Try if the bridge pixels are by now enough to separate the ext sources from all the pnt sources
			Pix = [i for i in VorSitesInvolved if i not in bridge and i not in VorSitesToSep]
			Pix.extend(VorSitesToSep)
			visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix,root=vmap[tuple(root)],GetOne=True)
			if not any([visited[n] for n in VorSitesToSep]): #all bridge pixels are found. They are all included in the ext src
				break
			if high == 0: sys.exit('ERROR: Sources can not be separated!')
		visited = [n for n in visited.keys() if visited[n]]
		return visited,bridge
	def FindOneBridgePixel(self,vmap,Adj,VorSitesInvolved,VorSitesToSep,bridge,high,low,root):
		#print "low,high",low ,self.Py[VorSitesInvolved[low]]+1, self.Px[VorSitesInvolved[low]]+1, high,self.Py[VorSitesInvolved[high]]+1, self.Px[VorSitesInvolved[high]]+1
		while high-low>1: #until low==high-1, one critical pixel is found
			#print low,high,'---',
			mid = (low+high)/2
			#print 'mid',low,high,mid,'   ',self.Py[VorSitesInvolved[mid]]+1, self.Px[VorSitesInvolved[mid]]+1,
			Pix = [i for i in VorSitesInvolved[mid:] if i not in bridge and i not in VorSitesToSep]
			Pix.extend(VorSitesToSep)
			visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix,root=vmap[tuple(root)],GetOne=True)
			if any([visited[n] for n in VorSitesToSep]): #any one of VorSitesToSep visited
				low = mid #low always means not separated
				#print 'too low'
				#for n in [n for n in VorSitesToSep if visited[n]]:
					#print self.Py[n]+1,self.Px[n]+1
			else:
				high = mid #high always means separated
				#print 'too high'
		assert VorSitesInvolved[low] not in VorSitesToSep #they must be separatable
		#print 'circle(%d,%d,0.5) # color=blue\n' % (self.Py[VorSitesInvolved[low]]+1,self.Px[VorSitesInvolved[low]]+1)
		#print self.Py[VorSitesInvolved[low]]+1,self.Px[VorSitesInvolved[low]]+1
		return low
	#END_OF_def FindOneBridgePixel(self):

	def delspuext(self):
		#add check
		vdmap = self.TmpFile_get('vdmap')
		filedelspuext=file('echeck.reg','w')
		for N in np.where(self.src.BeExtended())[0]:
			X,Y = np.where(self.pmap==N)
			if X.size==0: continue
			OCP = (self.dmap>0)&(self.pmap==N)
			X0,Y0 = np.average(np.argwhere(OCP),axis=0,weights=self.dmap[OCP]**2)
			D2 = (X-X0)**2+(Y-Y0)**2
			d = D2.argsort()
			a= vdmap[X[d[:81]],Y[d[:81]]].sum()
			ntot=X.size-160
			b= vdmap[X[d[160:ntot/2+160]],Y[d[160:ntot/2+160]]].sum()
			c= vdmap[X[d[-ntot/2:]],Y[d[-ntot/2:]]].sum()
			print >>filedelspuext, "circle(%.1f,%.1f,5) # text={%.1f,%.1f,%.1f}" %(Y0+1,X0+1,a,b,c)
	def Delspuext(self):
		return
		filedelspuext=file('echeck.reg','w')
		VorFile = np.load(self.VorFile)
		Esid = VorFile['Esid']
		Eend = VorFile['Eend']
		del VorFile
		site = np.zeros((Esid.shape[0],2),dtype='int32')
		site[:,0] = self.pmap[tuple(Esid[:,0:2].T)]
		site[:,1] = self.pmap[tuple(Esid[:,2:4].T)]
		for N in np.where(self.src.BeExtended())[0]:
			edge = (site==N).sum(axis=1)==1
			if not edge.any(): continue
			edge = Eend[edge]
			for e in edge: print >>filedelspuext, "line(%.1f,%.1f,%.1f,%.1f)" %(e[0],e[1],e[2],e[3])
			d1 = edge[:,0]
		filedelspuext.close()

	def DelSpuExt(self): #Not used
		#The modified Bkg is only used for a new S/N, it can not be used for photometry -- the Bkg subtracted in photometry should be the one which was used to define FOF linking length.#{{{
		if DET.developing: fdat = file('deledext.dat','w')
		for N in np.where(self.src.BeExtended())[0]:
			newbkg,edges,area = self.bkgedges(N,onlyinner=True)
			Ctstot = self.Cmap[self.pmap==N].sum() - newbkg*area
			aleft = (self.pmap==N).sum()-area
			Bkgtot = newbkg*aleft
			Ctsnet = Ctstot-Bkgtot
			if Ctsnet<=0 or Ctsnet/np.sqrt(Bkgtot)<3.5 or area/aleft>4 and Ctsnet<20:
				self.src.Type[N] = 0.5 #change the type of such extended source to point source
				if DET.developing: #np.savetxt(fdat,self.src[N:N+1],fmt='%12.8g',delimiter='\t')
					print >>fdat,"De %d	%d	%d	s/n:%f	bkg:%f	frac:%f pos:%d %d" %(self.src[N,0],self.src[N,1],Ctsnet,Ctsnet/np.sqrt(Bkgtot),newbkg,aleft/area,self.src[N,7]+1,self.src[N,6]+1)
			else:
				if DET.developing: #np.savetxt(fdat,self.src[N:N+1],fmt='%12.8g',delimiter='\t')
					print >>fdat,"Ok %d	%d	%d	s/n:%f	bkg:%f	frac:%f pos:%d %d" %(self.src[N,0],self.src[N,1],Ctsnet,Ctsnet/np.sqrt(Bkgtot),newbkg,aleft/area,self.src[N,7]+1,self.src[N,6]+1)
		if DET.developing: fdat.close()
		#It's not used because the contamination is not reduced very significantly while the completeness can be reduced slightly (some >100 ext src may have its core removed as pnt src, so it can be deleted here)
#}}}

	@staticmethod
	#mark all <0 pixels linked to x,y as value N
	def pull(pmap,x,y,N,Lnk=None,xi=np.zeros((11,11)),yi=np.zeros((11,11))): #no longer used
		#use default variable as static variable, maybe not necessary for staticmethod

		#If the occupied pixels are too dense, a source can be too large and impractical.
		#sys.setrecursionlimit(1000) is set to avoid this.
		xi,yi = DET.IndX+x,DET.IndY+y
		if Lnk is None: LnkScal2=DET.Lmap[x,y]
		else: LnkScal2=Lnk
		inregion = (DET.IndD<=LnkScal2) & (xi<pmap.shape[0]) & (xi>=0) & (yi<pmap.shape[1]) & (yi>=0)
		occu = pmap[xi[inregion],yi[inregion]] < 0
		if occu.any():
			pmap[xi[inregion][occu],yi[inregion][occu]] = N # mark it as already pulled out, should be done inside this function
			for fx,fy in np.vstack((xi[inregion][occu],yi[inregion][occu])).T:
				DET.pull(pmap,fx,fy,N,Lnk=Lnk)
				'''
				try:
					DET.pull(pmap,fx,fy,N,Lnk=Lnk)
				except RuntimeError,message:
					if message.__str__().split()[:4]==['maximum','recursion','depth','exceeded']: message=str(fx)+' '+str(fy)
					raise RuntimeError,message
				'''
	#END_OF_DET.pull()

	def Merge_Neighb_Ext(self):
		VorFile = np.load(self.VorFile)
		Esid = VorFile['Esid']
		#Eend = VorFile['Eend']
		del VorFile
		site = np.zeros((Esid.shape[0],2),dtype='int32')
		site[:,0] = self.pmap[tuple(Esid[:,0:2].T)]
		site[:,1] = self.pmap[tuple(Esid[:,2:4].T)]
		edge = (site[:,0]!=site[:,1])
		#Ends = Eend[edge]
		site = site[edge] #(n1,n2) in pmap
		#Ends = np.hstack((Ends,site))
		ext = self.src.BeExtended(site).all(1)
		if not ext.any(): return
		#np.savetxt('a.reg',Ends[ext],fmt="line(%.1f,%.1f,%.1f,%.1f) # tag={%04d} tag={%04d} color=red")
		site = site[ext]
		Ntm = []
		while (site>0).any():
			for s in site:
				if s[0]>0:
					Ntm.append([s[0]])
					site[site==s[0]] *= -1
					break
				if s[1]>0:
					Ntm.append([s[1]])
					site[site==s[1]] *= -1
					break
			for s in site:
				if s[0]<0 and s[1]>0:
					Ntm[-1].append(s[1])
					site[site==s[1]] *= -1
				if s[0]>0 and s[1]<0:
					Ntm[-1].append(s[0])
					site[site==s[0]] *= -1
			for n in Ntm[-1]:
				site[site==n] = 0
		Nmin = self.src.Nsrc
		self.src = self.src.extend(Nmin,self.Nsource+len(Ntm)-1)
		for Ns in Ntm:
			self.Nsource += 1
			for n in Ns:
				self.src.Prob[n] = 0
				self.pmap[self.pmap==n] = self.Nsource-1
		assert self.Nsource==self.src.Nsrc
		self.CalSrc(Nmin=Nmin,ToCalCenter=True,ToGetCoreInfo=True)
	#END_OF_Merge_Neighb_Ext(self)

	@staticmethod
	def boxsmooth(img,N,mode='valid'):
		""" smoothe in a box """
		return convolve(img,np.ones((N,N),dtype='float32')/N/N,mode=mode)

	@staticmethod
	def smooth1d(inputarr,sigma):
		if sigma==0: return inputarr
		degree = sigma*2
		k=np.arange(degree*2+1)
		k=np.exp(-(k-degree)**2/2./sigma**2)
		k/=k.sum()
		return convolve(inputarr,k,mode='same')

	@staticmethod
	def gaussmooth(img,sig,N=None,mode='valid'):
		""" blurs the image by convolving with a gaussian kernel"""
		if N is None: N = int(sig*3)
		x,y = np.mgrid[-N:N+1,-N:N+1]
		g = np.exp(-(x**2+y**2)/2./sig**2)
		g /= g.sum()
		return convolve(img,g,mode=mode)

	def FillEachCell_pmap(self,pmap=None):
		if pmap is None: pmap=self.pmap
		vmap = np.load(self.VorFile)['vmap']
		#vmap[self.Exp<=0] = 0 
		Pvalue = pmap[self.Px[1:],self.Py[1:]]
		pmap[vmap>0] = Pvalue[vmap[vmap>0]-1]

	def FillHoles(self,EmpInside=False,SrcInside=False,OutFile='OutFile'):
		print color("\nFill the Holes in Source Region",32,0)
		Adj = self.TmpFile_get('Oadj') #Original Adjacency list, all the occupied pixels included
		vmap = np.load(self.VorFile)['vmap']
		visited = self.pmap[self.Px,self.Py] #all the occupied pixels. ==0: free; >0:in a source
		assert self.pmap.max()<self.Nsource

		################################################################################
		#pf.writeto('0.fits',vmap,clobber=True)
		#pf.writeto('1.fits',self.pmap,clobber=True)
		N0 = next((vmap[self.Px[n],self.Py[n]] for n in range(1,self.Px.size) if (self.pmap[self.Px[n],self.Py[n]]==0 and all((visited[nn]<=0) for nn in Adj[n]))),None)
		if N0 is not None:
			if DET.debug: print 'A start from',N0,self.Px[N0],self.Py[N0]
			Pix = vmap[(self.pmap==0)&(self.Cmap>0)]
			vi = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix,root=N0,GetOne=True)
			Pix = [n for n in Pix if vi[n]==self.Nsource]
			self.pmap[self.Px[Pix],self.Py[Pix]] = -1
			#pf.writeto('2.fits',self.pmap,clobber=True)
		N0 = next((vmap[self.Px[n],self.Py[n]] for n in xrange(self.Px.size-1,0,-1) if self.pmap[self.Px[n],self.Py[n]]==0),None)
		if N0 is not None and self.pmap[self.Px[N0],self.Py[N0]] == 0 and all((visited[nn]<=0) for nn in Adj[N0]):
			if DET.debug: print 'B start from',N0,self.Px[N0],self.Py[N0]
			Pix = vmap[(self.pmap==0)&(self.Cmap>0)]
			vi = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix,root=N0,GetOne=True)
			Pix = [n for n in Pix if vi[n]==self.Nsource]
			self.pmap[self.Px[Pix],self.Py[Pix]] = -1
			#pf.writeto('3.fits',self.pmap,clobber=True)

		################################################################################
		#Fill the empty holes inside sources
		#two possible origins:
		#1. value >0 but <bkg
		#2. deleted very faint sources
		#search for free pixels which is only connected to one source
		if EmpInside:
			if DET.debug: df = file('hole.reg','a')
			for n in (n for n in vmap[(self.pmap==0)&(self.Cmap>0)] if any(((visited[n]>0) for n in Adj[n]))):
			#each freepixel which has as least one direct neighbor pixel >0
				Nsrc = itertools.ifilter(None,(visited[n] for n in Adj[n])).next() #the first >0 direct neighbor
				stack = [n]
				OnlyOneSrc = True
				while stack:
					site = stack.pop()
					if visited[site]==0:
						visited[site] = self.Nsource
						if any(( (visited[n]>0 and visited[n]!=self.Nsource and visited[n]!=Nsrc) for n in Adj[site] )):
							OnlyOneSrc = False
							break
						stack.extend([n for n in Adj[site] if visited[n]==0])
				tree = visited==self.Nsource
				if OnlyOneSrc:
					visited[tree] = Nsrc
					self.pmap[self.Px[tree],self.Py[tree]] = Nsrc
					if DET.debug:
						for i in np.where(tree)[0]: print >>df, "circle(%d,%d,0.5)" %(self.Py[i]+1,self.Px[i]+1)
				else:
					visited[tree] = 0
			if DET.debug: df.close()
			#pf.writeto('4.fits',self.pmap,clobber=True)

		################################################################################
		#Search for point sources which is only connected to one extended source (lying inside it)
		PinsideEp = []
		PinsideEe = []
		if SrcInside:
			n_ext = np.where(self.src.BeExtended())[0]
			if len(n_ext)==0:
				self.pmap[self.pmap<0] = 0
				return
			else:
				self.pmap[self.pmap<0] = -self.Nsource
			print color("\nFind Sources lying Inside Another",32,0)
			for x,y in [(x,y) for (x,y) in np.argwhere(self.pmap>0) if self.pmap[x,y] in n_ext]:
				self.pmap[x,y]=-self.pmap[x,y] #negative means extended
			visited = self.pmap[self.Px,self.Py] #all the occupied pixels. ==0: free; >0:in a source
			if DET.debug: df = file('phole.reg','w')
			for Nstartpix in (n for n in vmap[self.pmap>0] if visited[n]>0 and visited[n]!=self.Nsource and any(((visited[n]<0 and visited[n]>-self.Nsource) for n in Adj[n]))):
				if DET.debug: print 'start',self.pmap[self.Px[Nstartpix],self.Py[Nstartpix]], self.Px[Nstartpix],self.Py[Nstartpix]
				n_e = itertools.ifilter(lambda x:x<0 and x>-self.Nsource,(visited[n] for n in Adj[Nstartpix])).next() #the first <0 direct neighbor
				stack = [Nstartpix] #starting from a point source
				n_p = self.pmap[self.Px[Nstartpix],self.Py[Nstartpix]]
				OnlyOneSrc = True
				ToReCov = []
				while stack:
					site = stack.pop()
					if visited[site]>0 and visited[site]!=self.Nsource:
						if visited[site]!=n_p: ToReCov.append(visited[site])
						visited[site] = self.Nsource
						if any(( (visited[n]<0 and visited[n]!=n_e or visited[n]==-self.Nsource) for n in Adj[site] )):
							#if DET.debug: print [ (n,self.Px[n],self.Py[n]) for n in Adj[site] if (visited[n]<0 and visited[n]!=n_e or visited[n]==-self.Nsource) ]
							OnlyOneSrc = False
							break
						stack.extend([n for n in Adj[site] if visited[n]>0 and visited[n]!=self.Nsource])
				for n_pp in np.unique(ToReCov): #recover the pnt src passed by, so that they can be checked later
					visited[vmap[self.pmap==n_pp]] = n_pp
				if not OnlyOneSrc: #mark as already checked, avoid duplicating
					visited[vmap[self.pmap==n_p]] = self.Nsource
				if all(( (visited[n]==self.Nsource) for n in vmap[self.pmap==self.pmap[self.Px[Nstartpix],self.Py[Nstartpix]]] )) and OnlyOneSrc:
				#travelled all through the pnt src (maybe some starting pixel can not go backward to the pnt src)
				#and didn't reach any ext src other than n_e
				#Thus found one point source which falls inside an extended source
					#the point source is Numb. n_p, the extended source is Numb. n_e
					ns = vmap[self.pmap==n_p]
					visited[ns] = self.Nsource
					#Sources which lie between curve1 and curve2 and which fall inside an extended source are deleted as spurious point source.
					if self.src.MaybeExtended(n_p): # and self.src.Ncts[n_p]<self.src.Ncts[n_e]:
						if DET.debug: print n_p,'ate by',n_e
						self.pmap[self.pmap==n_p] = n_e
						self.src.Prob[n_p] = 0
						self.src.Type[n_p] = -6
					else:
						if DET.debug: print n_p,'lie in',n_e
						newbkg,edges,_ = self.bkgedges(n_p,vmap=vmap,Adj=Adj)
						x0 = np.int32(self.src.ImgX[n_p]+0.5)
						y0 = np.int32(self.src.ImgY[n_p]+0.5)
						if self.PSF.Instrum == 'SWIFT': offaxis=None
						elif self.PSF.Instrum == 'WFXT': offaxis = np.sqrt(((self.pmap.shape[0]-1)/2.-x0)**2 + ((self.pmap.shape[1]-1)/2.-y0)**2)
						elif self.PSF.Instrum == 'CHANDRA': offaxis=[x0,y0]
						Rs = self.PSF.fluxwhere(newbkg,self.src.Ccts[n_p],offaxis=offaxis)**2
						for x,y in np.argwhere(self.pmap==n_p):
							if (x-x0)**2+(y-y0)**2>Rs: self.pmap[x,y] = n_e
						PinsideEp.append(n_p)
						PinsideEe.append(-n_e)
						if DET.debug:
							for i in edges: print >>df, "circle(%d,%d,0.5) # color=red tag={%d}" %(self.Py[i]+1,self.Px[i]+1,n_p)
					if DET.debug:
						for x,y in np.argwhere(self.pmap==n_p): print >>df, "circle(%d,%d,0.5) # tag={%d}" %(y+1,x+1,n_p)
			if DET.debug: df.close()
			self.pmap[self.pmap<0] *= -1
			self.pmap[self.pmap==self.Nsource] = 0
		#pf.writeto('5.fits',self.pmap,clobber=True)
		self.pmap[self.pmap<0] = 0
		if PinsideEp and DET.developing:
			pmap = self.pmap.copy()
			for x,y in np.argwhere(pmap>0):
				if pmap[x,y] in PinsideEe: pmap[vmap==vmap[x,y]] = -pmap[x,y]
				elif pmap[x,y] in PinsideEp: pmap[vmap==vmap[x,y]] = pmap[x,y]
				else: pmap[x,y] = 0
			pf.writeto(OutFile+'_PinsideE.fits',pmap,clobber=True)
	#END_OF_def FillHoles

	def SepExtSrc(self,SepExt=False):
		self.pmap[self.Bkg<=0] = 0
		NExt = list(np.where((self.src.BeExtended())&(self.src.Prob>=self.ProbLowr))[0])
		if len(NExt)==0: return
		print color("\nEliminate Contamination in Extended Source",32,0)
		imap = np.zeros_like(self.pmap)
		vmap = np.load(self.VorFile)['vmap']
		Bmap = np.load(self.VorFile)['Amap']*self.Bkg #Net Count Map
		Adj = self.TmpFile_get('Adj')
		bkgmean = self.Bkg[self.Bkg>0].mean()
		vdmap = self.TmpFile_get('vdmap')
		CutPoint = []
		if DET.developing: cutfile=file('cutpoint.reg','w')
		Nsrc=self.Nsource
		#For each extended source, find cutpoint and separate the region after removing cutpoint
		#Old extended sources are destroied and new ones starts from Nsrc
		for n in NExt[:]:
			toon = (self.pmap==n)
			if not toon.any():
				NExt.remove(n)
				continue
			Pix= vmap[toon]
			root = tuple(np.argwhere(toon)[self.dmap[toon].argmax()])
			visited,cutpoint = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix,root=vmap[root],GetCut=True)
			##Maybe caused by varying linking scale. An ext src may be found to be separated.
			#visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=[n for n in visited.keys() if visited[n]==0])
			#for k in visited.keys(): self.pmap[self.Px[k],self.Py[k]] = visited[k]
			self.pmap[self.Px[cutpoint],self.Py[cutpoint]] = 0
			CutPoint.extend(cutpoint)
			if DET.developing:
				for i in cutpoint: print >>cutfile,"circle(%.1f,%.1f,0.5)" %(self.Py[i]+1,self.Px[i]+1)
			toon = (self.pmap==n)
			Pix= vmap[toon]
			self.Nsource,visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix,root=vmap[root])
			self.pmap[toon] = [visited[n] for n in Pix]
		NExt = np.arange(Nsrc,self.Nsource).tolist()
		for n in CutPoint: #re-assign cutpoint randomly
			for i in Adj[n]:
				if self.pmap[self.Px[i],self.Py[i]]>0:
					self.pmap[self.Px[n],self.Py[n]] = self.pmap[self.Px[i],self.Py[i]]
					break
		if DET.developing: cutfile.close()
		if len(NExt)==0: return
		################################################################################
		if SepExt:#{{{
			print color("\nSeparating blended Extended Sources",32,0)
			Pmap = self.pmap.copy() #contain only the new built extended sources
			for x,y in np.argwhere(Pmap>0):
				if Pmap[x,y] not in NExt: Pmap[x,y] = 0
			if self.InputExtSrc is not None:
				InputExtSrc = ~DET.BkgRegMask(self.InputExtSrc,Shape=self.pmap.shape)
				Bmap[InputExtSrc] = 0
				#below I add these so that: if set manually, just follow it, do not find more
				NInputInExt = np.unique(Pmap[InputExtSrc])
				Pmap[InputExtSrc] *= -1
				for n in NInputInExt:
					if n>0: Pmap[Pmap==n] = 0
				Pmap[InputExtSrc] *= -1
				Pmap[InputExtSrc] = np.max(Pmap[InputExtSrc])
			#pf.writeto('1.fits',Pmap,clobber=True)
			#exit()
			for Cscale in [1,1.5,2,3,4,5,6,7,8,9]:
				if DET.debug: print Cscale,'times'
				imap[:,:] = 0 #rebuild tmp imap
				if self.InputExtSrc is None:
					toon = (self.dmap>Cscale*self.Bkg)&(Pmap>0)
				else:
					toon = ((self.dmap>Cscale*self.Bkg)|InputExtSrc)&(Pmap>0)
				if not toon.any(): continue
				Pix= vmap[toon]
				self.Nsource,visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix)
				imap[toon] = [visited[n] for n in Pix]
				#The source numbers in imap follow self.Nsource, and thus never duplicate
				#Then save the detected Sources in tmp imap into Pmap
				for n in np.arange(imap[imap>0].min(),imap.max()+1):
					if (imap==n).any():
						N = np.unique(Pmap[imap==n]) #Number of blended source
						if N.size>1:
							for NN in N[1:]:
								Pmap[Pmap==NN]=N[0]
							#with a constant linking scale, this should not happen
							#but with varing linking scale, two points may be linked an may not
						InSourceN = Pmap==N[0]
						N = np.unique(imap[InSourceN])
						N = N[N>0].tolist()
						if len(N)>1:
							for NN in N[:]: #this [:] is important, or else cannot travesal
								SrcN = imap==NN
								Ctot = self.Cmap[SrcN].sum()
								Cbkg = Bmap[SrcN].sum()*Cscale
								if (Ctot-Cbkg)/np.sqrt(Cbkg)<self.ProbLowr+self.ExtSepLevel: #not significant enough
									N.remove(NN)
									imap[SrcN] = 0
								#else: print NN,(Ctot-Cbkg)/np.sqrt(Cbkg),Ctot,Cbkg,np.where(imap==NN),Cscale
						if len(N)>1:
							Pmap[InSourceN] = imap[InSourceN] #Save the separated blending region
						imap[InSourceN] = 0 #Mark all the new sources inside this region as already saved
			imap[:,:] = 0
			for n in NExt:
				InSourceN = self.pmap==n
				N = np.unique(Pmap[InSourceN])
				N = N[N>0]
				if N.size>1:
					for NN in N:
						OCP = (self.Cmap>0)&(Pmap==NN)
						imap[tuple(np.argwhere(OCP)[self.dmap[OCP].argmax()])] = NN
			del Pmap
			############################################################
			#modifi imap, delete nearby isource to keep isources at least self.ExtLowDist to each other
			X,Y=np.where(imap>0)
			self.ExtLowDist2=self.ExtLowDist**2
			NXToDel=[]
			for i in range(X.size):
				for j in range(i+1,X.size):
					dx=abs(X[i]-X[j])
					dy=abs(Y[i]-Y[j])
					if dx>=self.ExtLowDist or dy>=self.ExtLowDist: continue
					if dx**2+dy**2<self.ExtLowDist2:
						NXToDel.append(i)
						break
			for i in NXToDel:
				imap[X[i],Y[i]] = 0
			#pf.writeto('i.fits',imap,clobber=True)
			############################################################
			for N in NExt:
				SourceN = self.pmap==N
				while (imap[SourceN]>0).sum()>1:
					if DET.debug: print N,'/',self.Nsource,'------------------------'
					bridge=[]
					VorSitesInvolved = vmap[SourceN][self.dmap[SourceN].argsort()]
					low = 0
					VorSitesToSep = SourceN&(imap>0)
					root = tuple(np.argwhere(VorSitesToSep)[self.dmap[VorSitesToSep].argmax()])
					high = np.where(VorSitesInvolved==vmap[root])[0][0]
					assert high>=1
					VorSitesToSep = vmap[VorSitesToSep].tolist()
					VorSitesToSep.remove(vmap[root])
					while True: #until all the bridge pixels are found
						while high-low>1: #until low==high-1, one critical pixel is found
							mid = (low+high)/2
							Pix = [i for i in VorSitesInvolved[mid:] if i not in bridge and i not in VorSitesToSep]
							Pix.extend(VorSitesToSep)
							visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix,root=vmap[root],GetOne=True)
							if any([visited[n] for n in VorSitesToSep]): #any one of VorSitesToSep visited
								low = mid #low always means not separated
							else:
								high = mid #high always means separated
						assert VorSitesInvolved[low] not in VorSitesToSep
						bridge.append(VorSitesInvolved[low])
						low,high = 0,low #next bridge pixel should be lower than this one
						Pix = [i for i in VorSitesInvolved if i not in bridge and i not in VorSitesToSep]
						Pix.extend(VorSitesToSep)
						visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=Pix,root=vmap[root],GetOne=True)
						if not any([visited[n] for n in VorSitesToSep]): break
						if high == 0: sys.exit('ERROR: Sources can not be separated!')
					#Now all bridge pixels are found. They are all included in the ext src
					visited = [n for n in visited.keys() if visited[n]]
					n = visited+bridge
					self.pmap[self.Px[n],self.Py[n]] = imap[root]
					SourceN = self.pmap==N
					if (imap[SourceN]>0).sum()==1:
						root = tuple(np.argwhere(SourceN&(imap>0))[0])
						visited = Percolate(Nplus=self.Nsource,Connections=Adj,Vertices=vmap[SourceN],root=vmap[root],GetOne=True)
						self.pmap[SourceN] = 0
						for i in visited.keys():
							if visited[i]>0: self.pmap[self.Px[i],self.Py[i]] = imap[root]

						break
				#END_OF_while
		#END_OF_if SepExt:#}}}
		################################################################################
		Nsrc = self.src.Nsrc
		self.src = self.src.extend(self.src.Nsrc,self.Nsource-1)
		self.CalSrc(Nmin=Nsrc)
		self.PreDel()
		if 'coremap' in self.TmpFile.keys():
			self.CalSrc(Nmin=Nsrc,ToCalCenter=True,ToGetCoreInfo=True,LowType=-2)
		else:
			self.CalSrc(Nmin=Nsrc)
		#LowType MARK: new piece may be generated after source separtion
	#END_OF_def SepExtSrc(self):

	def bkgedges(self,N,vmap=None,Adj=None,Amap=None,onlyinner=False):
		#The edge pixels are defined as the pixels on both sides of the source edges
		#which belong to this source N, or to NO other sources (if all sources in pmap >0)
		#which belong to this source N, or to NO other point sources (if extended sources in pmap <0)

		#If onlyinner is True, the modified Bkg is slightly overestimated, however it should be representative of the locak background fluctuation. It is used to calculate a new S/N, which should be helpful to filter out spurious extended sources.
		if Adj is None: Adj = self.TmpFile_get('Oadj') #Original Adjacency list, all the occupied pixels included
		if vmap is None: vmap = np.load(self.VorFile)['vmap']
		if Amap is None: Amap = np.load(self.VorFile)['Amap']
		edges=[]
		for ns in vmap[self.pmap==N]:
			nss = [n for n in Adj[ns] if self.pmap[self.Px[n],self.Py[n]]<=0]
			if nss:
				edges.append(ns)
				if not onlyinner: edges.extend(nss)
		edges=np.unique(edges)
		area = Amap[self.Px[edges],self.Py[edges]].sum()
		newbkg = self.Cmap[self.Px[edges],self.Py[edges]].sum()/area
		return newbkg,edges,area

	def MendextReg(self,todolist=None):
		#complete the region of each source in self.pmap (include empty pixels and faint ignored pixels)

		print color("\nMending: Delete impratical sources and complete the other ones",32,0)
		start_time=time.time()

		#First, fill each cell using vmap
		self.FillEachCell_pmap()
		if DET.debug: pf.writeto('deblended3.fits',self.pmap,clobber=True)
		if DET.debug: self.SaveVorReg('deblended3.reg')
		if DET.debug: np.savetxt('deblended3.dat',self.src[1:,],fmt='%12.8g',delimiter='\t')

		#Second, sweep in x axis and y axis
		N=0
		while N<self.Nsource: #self.Nsource may increase
			N+=1
			if N>=self.src.Nsrc or not self.src.BeExtended(N): continue
			#print 'MendextReg',N
			#newn=[N]
			xs,ys=np.where(self.pmap==N)
			#first run in x direction
			for x in np.unique(xs):
				n0=np.where(xs==x)[0]
				for y in np.arange(ys[n0].min(),ys[n0].max()+1):
					nn = self.pmap[x,y]
					if nn==N: continue
					if nn==0 and self.Cmap[x,y]>0: #include not detected occupied pixels
						self.pmap[x,y]=N
						#modiN.append(N)
					#if (N>=self.src.Nsrc or self.src[N,8]!=1) and nn>0 and nn!=N:
					#a pixels belog to another source, and this source is not point (including new sources not yet distinguished)
						#the new sources is also not point (including new and spurious)
						#if nn>=self.src.Nsrc or self.src[nn,8]!=1 or self.src[nn,1]<self.NCtsLowP: newn.append(nn)
			#then run again in y direction
			for y in np.unique(ys):
				n0=np.where(ys==y)[0]
				for x in np.arange(xs[n0].min(),xs[n0].max()+1):
					nn =self.pmap[x,y]
					if nn==N: continue
					if nn==0 and self.Cmap[x,y]>0:
						self.pmap[x,y]=N
						#modiN.append(N)
					#if (N>=self.src.Nsrc or self.src[N,8]!=1) and nn>0 and nn!=N:
					#	if nn>=self.src.Nsrc or self.src[nn,8]!=1 or self.src[nn,1]<self.NCtsLowP: newn.append(nn)
			#all the sources near this source joint to be a new source??? why? forgot
			#anyway, it does work
		#END_OF_while N<self.Nsource:

		'''
		for n in np.unique(modiN):
			if (self.pmap==n).any():
				self.Nsource += 1
				self.pmap[self.pmap==n] = self.Nsource
				if n<self.src.Nsrc:
					Ntokeepold.append([n,self.Nsource]) #old sources will be deleted later
		'''
		if DET.debug: pf.writeto('deblended4.fits',self.pmap,clobber=True)
		if DET.debug: self.SaveVorReg('deblended4.reg')
		if DET.debug: np.savetxt('deblended4.dat',self.src[1:,],fmt='%12.8g',delimiter='\t')
		self.pmap[self.Cmap==0] = 0 #should not be vmap completed before ExamineSrc

	#END_OF_def MendextReg

	@staticmethod
	def convex(V,reverse=False,vtmp=np.zeros((2,100),dtype='float32')):
		if vtmp.shape[0]<V.size: vtmp = np.zeros((2,V.size),dtype='float32')
		vtmp[0,:V.size] = V[:]
		scale = V.size-10
		while scale >= 5:
			for i in np.arange(V.size-scale-1):
				vtmp[1,i+1:i+scale-1] = vtmp[0,i] + (vtmp[0,i+scale]-vtmp[0,i])*np.arange(1,scale-1)/scale
				if reverse: vtmp[0,i+1:i+scale-1] = vtmp[:,i+1:i+scale-1].max(axis=0)
				else: vtmp[0,i+1:i+scale-1] = vtmp[:,i+1:i+scale-1].min(axis=0)
			scale = scale/2
		V[:] = vtmp[0,:V.size]
	@staticmethod
	def convexold(V,reverse=False):
		if V.size<20: return
		vtmp = np.zeros(V.size-12,dtype='float32')
		scale = V.size-10
		while True:
			for i in np.arange(V.size-scale-1):
				vtmp[:] = 0
				vtmp[:scale-2] = V[i] + (V[i+scale]-V[i])*np.arange(1,scale-1)/scale
				for j in np.arange(i+1,i+scale-1):
					if reverse: V[j] = max(V[j], vtmp[j-i-1])
					else: V[j] = min(V[j], vtmp[j-i-1])
			scale = scale*2/3
			if scale < 10: break
	#END_OF_def convex(V):

	def EstiSrcExp(self):
		numtor = np.zeros(self.src.Nsrc,dtype='float32')
		dentor = np.zeros(self.src.Nsrc,dtype='float32')
		for x,y in np.argwhere((self.pmap>0)&(self.Exp>0)):
			numtor[self.pmap[x,y]] += self.Cmap[x,y]
			dentor[self.pmap[x,y]] += self.Cmap[x,y]/self.Exp[x,y]
		dentor[0] = 1
		self.src.SExp[:] = numtor/dentor

	def CalSrc(self,Nmin=1,Bkg=None,pmap=None,ToCalCenter=False,ToGetCoreInfo=False,LowType=None,SmoothCenterSmallCore=None):
		if Bkg is None: Bkg = self.Bkg
		if pmap is None: pmap = self.pmap
		Nmap = self.Cmap - np.load(self.VorFile)['Amap']*Bkg #Net Count Map
		if pmap.max()>=self.src.Nsrc: print pmap.max(),self.src.Nsrc
		assert pmap.max()<self.src.Nsrc
		self.src.Ncts[Nmin:] = 0 # Net Count
		self.src.Area[Nmin:] = 0 # Source Area (ATTENTION: Number of occupied pixels OR all pixels)
		self.src.Prob[Nmin:] = 0 # Total Count (temporarily);
		for x,y in np.argwhere(pmap>=Nmin):
			n = pmap[x,y]
			self.src.Ncts[n] += Nmap[x,y]
			self.src.Area[n] += 1
			self.src.Prob[n] += self.Cmap[x,y]
		if ToCalCenter:
			if SmoothCenterSmallCore is not None:
				sdmap = DET.gaussmooth(self.dmap,self.PSF.CoreRad*2/3,N=self.PSF.CoreRad*4/3,mode='same')
				sdmap[SmoothCenterSmallCore==0] = 0
			for n in np.arange(Nmin,self.src.Nsrc):
				if np.all(pmap!=self.src.Numb[n]):
					self.src[n,1:]=0
					continue
				if self.src.Ncts[n]<self.NCtsLowP:
					continue
				X,Y = np.where(pmap==self.src.Numb[n])
				if SmoothCenterSmallCore is not None:
					nm = sdmap[X,Y].argmax()
					self.src.ImgX[n],self.src.ImgY[n] = X[nm],Y[nm]
				else:
					nm = self.dmap[X,Y].argsort()
					if nm.size>self.PixNum2CalCenter: nm = nm[-self.PixNum2CalCenter::]
					self.src.ImgX[n] = DET.wtd_median(X[nm],self.dmap[X,Y][nm]) #not Fortran style
					self.src.ImgY[n] = DET.wtd_median(Y[nm],self.dmap[X,Y][nm]) #not Fortran style
		#self.src 5: Confidence Probability
		ok = (self.src.Ncts>=self.NCtsLowP)&(self.src.Numb>=Nmin)
		if ok.any():
			#self.src.Prob[ok] = np.float32(poisson.cdf(self.src.Prob[ok],self.src.Prob[ok]-self.src.Ncts[ok]))
			self.src.Prob[ok] = self.src.Ncts[ok]/np.sqrt(self.src.Prob[ok]-self.src.Ncts[ok])
		#0:Num  1:NCts  2:Temp_NCts  3:Area  4:F_HE  5:Prob  6:ImgX  7:ImgY  8:Flag(1:point 2:ext 0:other)
		if ToGetCoreInfo:
			#the core info (Ccts,val4,Type) are generated in Core_ClafySrc() and saved in the first part of src
			#when src is extended with new sources created (whether because of merging of seperating)
			#core information can be found in the first part of src making use of the coremap
			coremap = self.TmpFile_get('coremap')
			vmap = np.load(self.VorFile)['vmap']
			if DET.developing: ftmp=file('core7.reg','w')
			for N in np.where(ok)[0]:
				x,y = np.int32(self.src.ImgX[N]+0.5),np.int32(self.src.ImgY[N]+0.5)
				n = coremap[x,y]
				#if n>0 and self.src.Type[n]!=7: # <7>
				if n>0: #lewton Jan21 20:00
				#the source position falls inside a core circle
				#unreliable point sources need further checking
					self.src.Ccts[N] = self.src.Ccts[n]
					self.src.val4[N] = self.src.val4[n]
					self.src.Type[N] = self.src.Type[n]
				else:
					SourceN=self.pmap==N
					ncorepixel=np.unique(coremap[SourceN])
					ncorepixel=list(ncorepixel[ncorepixel>0])
					if len(ncorepixel)>1: #extended source with a few cores found
						if DET.debug: print 'Multicores',ncorepixel,self.src.Ccts[ncorepixel]
						ncpbig=ncorepixel[np.argmax(self.src.Ccts[ncorepixel])]
						for ncp in ncorepixel:
							if not self.src.MaybeExtended(N=ncp) and self.src.Type[ncp]!=7:
								#there may be such pnt src whose radius is even smaller than the CoreRad
								#so that a part of its core goes into nearby ext src
								assert np.sum((coremap==ncp)&SourceN)<=np.sum((coremap==ncp)&(self.dmap>0))
								ncorepixel.remove(ncp)
							elif self.src.Ccts[ncp] <= self.src.Ccts[ncpbig]/5: ncorepixel.remove(ncp)
					if len(ncorepixel)==0: #no core circle inside this region
						assert LowType is not None
						#LowType is a mark for such case where ther is no core circle inside an ext source
						self.src.Ccts[N] = 10+np.random.normal()
						self.src.val4[N] = np.sqrt(self.src.Ccts[N])
						self.src.Type[N] = LowType
						for n in np.unique(vmap[SourceN]): #build a new core
							coremap[vmap==n] = N
					elif len(ncorepixel)==1: #one core circle inside this region
						n = ncorepixel[0]
						self.src.Ccts[N] = self.src.Ccts[n]
						self.src.val4[N] = self.src.val4[n]
						self.src.Type[N] = self.src.Type[n]
						#if self.src.Type[n]!=7: 
						print "Warning: source position outside of core.",self.src[N]
						if DET.developing:
							print >>ftmp,"circle(%d,%d,1) # color=red width=3" % (y+1,x+1)
							for xx,yy in np.argwhere(SourceN):
								print >>ftmp,"circle(%d,%d,1) # color=blue width=1" % (yy+1,xx+1)
					else:
						#extended source with a few cores found, candidate of blended source
						self.src.Ccts[N] = 10+np.random.normal()
						self.src.val4[N] = np.sqrt(self.src.Ccts[N])
						self.src.Type[N] = -1
						if DET.debug:
							print 'multiple cores BEGIN',
							for n in ncorepixel: print self.src[n]
							print 'multiple cores END'
						if DET.developing:
							print >>ftmp,"circle(%d,%d,1) # color=magenta width=3" % (y+1,x+1)
							for xx,yy in np.argwhere(SourceN):
								print >>ftmp,"circle(%d,%d,1) # color=blue width=1" % (yy+1,xx+1)
			self.TmpFile_set('coremap',coremap)
			if DET.developing: ftmp.close()
	#END_OF_CalSrc

	def PreDel(self,spuri=None,ProbLowr=None):
		#delete spurious sources from self.src and self.pmap
		if ProbLowr is None: ProbLowr = self.ProbLowr
		if spuri is None: spuri = (self.src.Area<self.AreaLowr)|(self.src.Prob<ProbLowr)|(self.src.Ncts<self.NCtsLowP)
		self.src.Ncts[spuri] = 0
		self.src.Ccts[spuri] = 0
		self.src.Prob[spuri] = 0
		for x,y in np.argwhere(self.pmap>0):
			if self.src.Prob[self.pmap[x,y]]==0: self.pmap[x,y]=0
		#self.src.Prob[self.src.Prob==-1] = 0

	def ShrinkList(self,ok):
		if np.any(ok):
			self.src.Numb[ok] = range(ok.sum())
			self.src.Numb[~ok] = 0
			self.pmap[self.pmap>0] = self.src.Numb[self.pmap[self.pmap>0]]
			self.src = self.src[ok].view(SrcList)
		else:
			self.src = SrcList()
			self.pmap[:,:] = 0

	def FinalDel(self):
		print color("Eliminate impractical sources and Renumber the others",32,0)
		self.PreDel()
		self.src.Ncts[0] = self.NCtsLowE #to make self.src[0] survive
		self.src.Prob[0] = self.ProbLowr
		ok = ((self.src.Ncts>=self.NCtsLowP) & (self.src.Prob>=self.ProbLowr) & np.invert((self.src.BeExtended() & (self.src.Ncts<self.NCtsLowE))))
		self.ShrinkList(ok)

	@staticmethod
	def line2polygon(data,tag=None,color=None):
		assert np.ndim(data)==2 and np.shape(data)[1]==4
		################################################################################
		#initialize lines dict
		################################################################################
		lines=dict()
		for pts in data:
			if (pts[0],pts[1]) != (pts[2],pts[3]):
				line = lines.get((pts[0],pts[1]),[])
				if (pts[2],pts[3]) not in line:
					line.append((pts[2],pts[3]))
					lines[(pts[0],pts[1])] = line
				line = lines.get((pts[2],pts[3]),[])
				if (pts[0],pts[1]) not in line:
					line.append((pts[0],pts[1]))
					lines[(pts[2],pts[3])] = line
		################################################################################
		#assert one point two lines
		################################################################################
		"""
		Take care of the one point four lines case
		Step 1
		v[0] -> k -> v[1] -> ... ->
		if reach v[0], v[0]~v[1]
		if reach v[2], v[0]~v[3]
		if reach v[3], v[0]~v[2]
		Step 2
		Divide one point into two, in the directions of middle point of each pair of line outer ends, to distances of 1/10 of that of the middle points.
		"""
		for k in lines.keys():
			v=list(lines[k])
			if len(v)==4:
				tmp=dict()
				for x in lines.keys(): tmp[x] = list(lines[x])
				tmp[v[0]].remove(k)
				head = k
				tail = v[1]
				while True:
					tmp[head].remove(tail)
					tmp[tail].remove(head)
					head=tail
					assert len(tmp[head])>0
					tail = tmp[head][0]
					if tail==v[0]:
						N2C=1
						break
					elif tail==v[2]:
						N2C=3
						break
					elif tail==v[3]:
						N2C=2
						break
				for n in [0,1,2,3]:
					lines[v[n]].remove(k)
				K1 = tuple((np.array(v[0])+np.array(v[N2C])+18*np.array(k))/20)
				lines[v[0]].append(K1)
				lines[v[N2C]].append(K1)
				NO=[1,2,3]
				NO.remove(N2C)
				K2 = tuple((np.array(v[NO[0]])+np.array(v[NO[1]])+18*np.array(k))/20)
				for n in NO: lines[v[n]].append(K2)
				lines.pop(k)
				lines[K1]=[v[0],v[N2C]]
				lines[K2]=[v[NO[0]],v[NO[1]]]
		for v in lines.values():
			assert len(v)==len(v[0])==len(v[1])==2
		#END_OF_for k in lines.keys():
		################################################################################
		#Make Polygons
		################################################################################
		Polygons=[]
		while len(lines)>0:
			polygon=[]
			starting = lines.keys()[0]
			head = starting
			tail = lines[head][0]
			polygon.append(list(head))
			lines.pop(head)
			head = tail
			if lines[head][0] != starting: tail = lines[head][0]
			else: tail = lines[head][1]
			while True:
				polygon.append(list(head))
				lines.pop(head)
				head = tail
				if lines[head][0]==starting or lines[head][1]==starting:
					polygon.append(list(head))
					lines.pop(head)
					break
				if lines[head][0] in lines.keys(): tail = lines[head][0]
				else: tail = lines[head][1]
			polygon=np.array(polygon)
			Polygons.append(polygon)
		################################################################################
		#Which are holes?
		################################################################################
		Holes=[]
		for i in np.arange(len(Polygons)):
			for j in np.arange(len(Polygons)):
				if i!=j:
					if np.max(Polygons[i][:,0]) < np.max(Polygons[j][:,0]) and \
					np.min(Polygons[i][:,0]) > np.min(Polygons[j][:,0]) and \
					np.max(Polygons[i][:,1]) < np.max(Polygons[j][:,1]) and \
					np.min(Polygons[i][:,1]) > np.min(Polygons[j][:,1]):
						Holes.append(i)
		################################################################################
		#Output ds9 region
		################################################################################
		Output=[]
		LineTail=" #"
		if tag is not None: LineTail+=" tag={%s}" % (tag)
		if color is not None: LineTail+=" color=%s" % (color)
		LineTail+="\n"
		for i in np.arange(len(Polygons)):
			polygon = Polygons[i]
			if i in Holes: Output.append('-polygon('+','.join(["%.1f" % x for x in polygon.flatten()])+')'+LineTail)
			else: Output.append('polygon('+','.join(["%.1f" % x for x in polygon.flatten()])+')'+LineTail)
		return Output
	#END_OF_def line2polygon(data):

	def SaveVorReg(self,RegFile,pmap=None):
		VorFile = np.load(self.VorFile)
		Esid = VorFile['Esid']
		Eend = VorFile['Eend']
		del VorFile

		if type(RegFile)==str:
			freg=open(RegFile,'w')
		elif type(RegFile)==file:
			freg=RegFile
		else:
			sys.exit('ERROR: a file or file name is needed')
		if pmap is None: pmap = self.pmap
		site = np.zeros((Esid.shape[0],2),dtype='int32')
		site[:,0] = pmap[tuple(Esid[:,0:2].T)]
		site[:,1] = pmap[tuple(Esid[:,2:4].T)]
		edge = (site[:,0]!=site[:,1])
		Ends = Eend[edge]
		site = site[edge]
		Ends = np.hstack((Ends,site))
		if pmap.max()<self.src.Nsrc:
			if self.OutPutPolygon:
				ext = ((site>0) & self.src.BeExtended(site))
				for N in np.unique(site[ext]):
					freg.writelines(DET.line2polygon(Ends[(site==N).any(1),:4],tag="%04d" %(N),color="yellow"))
				pnt = ((site>0) & ~self.src.BeExtended(site))
				for N in np.unique(site[pnt]):
					freg.writelines(DET.line2polygon(Ends[(site==N).any(1),:4],tag="%04d" %(N),color='green'))
			else:
				ext = ((site>0) & self.src.BeExtended(site)).any(1)
				if ext.any(): np.savetxt(freg,Ends[ext],fmt="image;line(%.1f,%.1f,%.1f,%.1f) # tag={%04d} tag={%04d} color=yellow")
				pnt = ((site>0) & ~self.src.BeExtended(site)).any(1)
				if pnt.any(): np.savetxt(freg,Ends[pnt],fmt="image;line(%.1f,%.1f,%.1f,%.1f) # tag={%04d} tag={%04d} color=green")
		else:
			np.savetxt(freg,Ends,fmt="image;line(%.1f,%.1f,%.1f,%.1f) # tag={%04d} tag={%04d} color=green")
		if type(RegFile)==str: freg.close()
	#END_OF_def SaveVorReg()

	def saveresult(self,**kwargs):
		Version = kwargs.pop('Version','Unknown')
		OutFile = kwargs.pop('OutFile','OutFile')
		print color('Save result',32,0)

		self.Hdr.update('SepExt',self.SepExt)
		self.Hdr.update('ModiExt',self.ModiExtSrc)
		self.Hdr.update('OptmCore',self.OptimizeCore)
		self.Hdr.update('CtrLevel',self.CtrLevel)
		self.Hdr.update('ExtLowD',self.ExtLowDist)
		self.Hdr.update('ExtSepL',self.ExtSepLevel)
		self.Hdr.update('ReProbLr',self.ReliProbLowr)
		self.Hdr.update('OverFloL',self.OverFlowLevel)
		self.Hdr.update('Version',Version)
		if self.fitsmask:
			print color(">>	"+OutFile+".fits",34,1)
			pf.writeto(OutFile+'.fits',self.pmap,self.Hdr,clobber=True)
		print color(">>	"+OutFile+".reg",34,1)
		self.SaveVorReg(OutFile+'.reg')
		print color(">>	"+OutFile+".dat",34,1)
		fdat = file(OutFile+'.dat','w')
		if kwargs.pop('ModiType',False) and False:
			ext = self.src.BeExtended()
			self.src.Type[ext] = 2
			self.src.Type[~ext] = 1
		fdat.write("#0:Number\t1:NetCts\t2:NCtsCore\t3:SrcArea\t4:SNRcore\t5:SNR\t6:Img_X\t7:Img_Y\t8:ExtFlag(1:point,2:ext)\t9:ExpTime\n")
		#here ?? to add calerr.py
		np.savetxt(fdat,self.src[1:,],fmt='%12.8g',delimiter='\t')
		fdat.close()
	#END_OF_def saveresult(self):

	@staticmethod
	def BkgRegMask(Regfile,Shape=None):
		'''
		Return mask of background region.
		array==0 means background
		...to
		'''
		if type(Regfile)==np.ndarray:
			return (Regfile==0)
		if Regfile.split('.')[-1] == 'reg':
			regions= file(Regfile).readlines()
			if len(grep('^image',regions))==0:
				sys.exit("Please save the "+Regfile+" in image coordinate system!")
			circles = grep('background',grep('^circle',regions))
			if len(circles)>0:
				BkgFlag = 1
				circles = np.float32([s.split()[0].replace('circle(','').replace(')','').split(',') for s in circles])
			else:
				BkgFlag = 0
				circles = grep('^circle',regions)
				if len(circles)==0: sys.exit('ERROR: No circle regions in '+Regfile)
				circles = np.float32([s.split()[0].replace('circle(','').replace(')','').split(',') for s in circles])
			assert Shape is not None
			m = np.zeros(Shape,dtype='int16')
			for d in np.int32(circles+0.5):
				x,y,r = d[1]-1,d[0]-1,d[2]
				X,Y = np.indices((2*r+1,2*r+1))-r
				dists=X**2+Y**2
				X=X[dists<=r**2]
				Y=Y[dists<=r**2]
				m[X+x,Y+y]=1
			return (m==BkgFlag)
		elif Regfile.split('.')[-1] == 'fits':
			reg = np.float32(pf.getdata(Regfile))
			if Shape is not None:
				if reg.shape!=Shape: sys.exit('ERROR: BkgReg shape not match')
			if reg.min()<0: sys.exit('ERROR: Negative value in the source region fits file')
			return (reg==0)
		else: sys.exit('ERROR: Only suffix .reg and .fits are valid')
	#END_OF_DET.BkgRegMask

	def savetime(self):
		self.pmap[self.dmap<=self.Bkg] = 0
		if self.PSF.Instrum=='CHANDRA':
			t1=self.PSF.ChandraPSF
			t2=self.PSF.ChandraPData
			self.PSF.ChandraPSF=None
			self.PSF.ChandraPData=None
		cPickle.dump(self.PSF,file('psf.dat','w'))
		cPickle.dump(self.src,file('src.dat','w'))
		t3=self.PSF
		self.PSF=None
		t4=self.src
		self.src=None
		self.TmpFile_save()
		cPickle.dump(self,file('det.dat','w'))
		self.PSF=t3
		self.src=t4
		if self.PSF.Instrum=='CHANDRA':
			self.PSF.ChandraPSF=t1
			self.PSF.ChandraPData=t2
		self.TmpFile_read()
		#assert (self.pmap[self.dmap<=self.Bkg] == 0).all()
		self.pmap[self.dmap<=self.Bkg] = 0

	def CalCtrScales(self,Low,High):
		#self.CtrLevel: divide the range into self.CtrLevel parts
		#Generate a Geometric Progression q^n (n from 1 to self.CtrLevel) that sum{q^n} == High-Low
		#Return the Geometric Series (the sum of the terms of Geometric Sequence) as the contour scales
		#Make q**self.CtrLevel == 1000
		q = 10**(3./self.CtrLevel)
		#The sequence is from q^1 to q^self.CtrLevel. n[0] is not the first one, because although q^0=1, s[0]=0
		n = np.arange(0,self.CtrLevel+1)
		#The Series make sense for only those n>=1.
		s = (q**n-1)/(q-1)
		if DET.debug: print "CalCtrScales:",Low,High, Low + (High-Low)*s[:-1]/s[-1]
		return Low + (High-Low)*s[:-1]/s[-1]

	@staticmethod
	def FindNearestSource(pmap,x,y,maxdist2): #no longer used
		#First, Find the nearest point in pmap to x,y, within a maximum distance
		xn,yn = None,None
		xi,yi = DET.IndX+x,DET.IndY+y
		for distance in np.unique(DET.IndD[DET.IndD<=maxdist2]):
			InReg = (DET.IndD<=distance) & (xi<pmap.shape[0]) & (xi>=0) & (yi<pmap.shape[1]) & (yi>=0)
			DaYu0 = pmap[xi[InReg],yi[InReg]] > 0
			if DaYu0.any():
				xn,yn = np.array(xi[InReg][DaYu0]),np.array(yi[InReg][DaYu0])
				break
		if xn is None:
			return False
		elif xn.size==1:
			pmap[x,y] = pmap[xn,yn]
			return True
		elif xn.size>1:
			NearSrc = pmap[xn,yn]
			nummax = 0
			SrcMax = 0
			for NSrc in np.unique(NearSrc):
				thisnummax = (NearSrc==NSrc).sum()
				if thisnummax>nummax:
					nummax = thisnummax
					SrcMax = NSrc
			if SrcMax==0: sys.exit("ERROR: No way")
			pmap[x,y] = SrcMax
			return True

	@staticmethod
	def DiffSideOfLine((x1,y1),(x2,y2),(xa,ya),(xb,yb)):
		#(x1,y1),(x2,y2) define the line
		#check whether (xa,ya),(xb,yb) on different sides of the line
		x1 = float(x1)
		y1 = float(y1)
		x2 = float(x2)
		y2 = float(y2)
		xa = float(xa)
		ya = float(ya)
		xb = float(xb)
		yb = float(yb)
		if y1==y2:
			return (ya-y1)*(yb-y1)<=0
		elif ya==yb:
			x = (x2-x1)*(ya-y1)/(y2-y1)+x1
			return (x-xa)*(x-xb)<=0
		else:
			k12 = (x2-x1)/(y2-y1)
			kab = (xb-xa)/(yb-ya)
			if k12==kab:
				if min(xa,xb)==max(x1,x2) or max(xa,xb)==min(x1,x2): return False
				elif min(xa,xb)==min(x1,x2) or max(xa,xb)==max(x1,x2): return True
				else: return (xa-x1)*(xa-x2)<0 and (xa-x1)/(ya-y1)==k12 or (xb-x1)*(xb-x2)<0 and (xb-x1)/(yb-y1)==k12
			else:
				#x = ((k12*kab*(ya-y1)+kab*x1-k12*xa)) / (kab-k12)
				y = (xa-x1+k12*y1-kab*ya) / (k12-kab)
				return (y-ya)*(y-yb)<=0

	@staticmethod
	def LinePassingPixels((x1,y1),(x2,y2)):
		if x1==x2:
			y=range(int(min(y1,y2)),int(max(y1,y2))+1)
			#return [int(x1+0.5)]*len(y),y
			return [int(x1+0.5)-1]*len(y)+[int(x1+0.5)]*len(y)+[int(x1+0.5)+1]*len(y),y+y+y
		elif y1==y2:
			x=range(int(min(x1,x2)),int(max(x1,x2))+1)
			#return x,[int(y1+0.5)]*len(x)
			return x+x+x, [int(y1+0.5)-1]*len(x)+[int(y1+0.5)]*len(x)+[int(y1+0.5)+1]*len(x)
		elif abs(y1-y2)>abs(x1-x2):
			y=np.arange(int(min(y1,y2)),int(max(y1,y2))+1)
			a = 1.*(x2-x1)/(y2-y1)
			b = x1-a*y1
			#return np.int32(a*y+b+0.5),y
			return np.hstack((np.int32(a*y+b+0.5),np.int32(a*y+b+0.5)-1,np.int32(a*y+b+0.5)+1)),np.hstack((y,y,y))
		else:
			x=np.arange(int(min(x1,x2)),int(max(x1,x2))+1)
			a = 1.*(y2-y1)/(x2-x1)
			b = y1-a*x1
			#return x,np.int32(a*x+b+0.5)
			return np.hstack((x,x,x)),np.hstack((np.int32(a*x+b+0.5),np.int32(a*x+b+0.5)-1,np.int32(a*x+b+0.5)+1))
