#!/usr/bin/env python
from scipy.interpolate import interp1d
from numpy import log10

#May 27
_Xfromsimu =  [-1.000,  0.500,  0.700,  0.800,  1.000,  1.100,  1.200,  1.400,  1.600,  1.800,  2.000,  2.200,  2.400,  8.000]
_YLfromsimu = [-7.000, -7.000, -7.000, -7.000, -5.000, -4.400, -3.700, -2.800, -2.100, -1.650, -1.400, -1.300, -1.300, -1.300]
_YUfromsimu = [-7.000, -7.000, -7.000, -7.000, -3.500, -2.300, -1.700, -1.200, -0.950, -0.750, -0.650, -0.500, -0.500, -0.500]
ClassifyCurveL = interp1d(_Xfromsimu,_YLfromsimu,bounds_error=False,fill_value=1.)
ClassifyCurveU = interp1d(_Xfromsimu,_YUfromsimu,bounds_error=False,fill_value=1.)

#July 4
_Xfromsimu =  [-1.000,  0.500,  0.700,  0.800,  1.000,  1.100,  1.200,  1.400,  1.600,  1.800,  2.000,  2.200,  2.400,  8.000]
_YLfromsimu = [-7.000, -7.000, -7.000, -7.000, -5.000, -4.400, -3.700, -2.800, -2.100, -1.650, -1.400, -1.300, -1.300, -1.300]
_YUfromsimu = [-3.000, -3.000, -3.000, -3.000, -2.600, -2.250, -1.800, -1.200, -0.950, -0.750, -0.650, -0.500, -0.500, -0.500]
ClassifyCurveL = interp1d(_Xfromsimu,_YLfromsimu,bounds_error=False,fill_value=1.)
ClassifyCurveU = interp1d(_Xfromsimu,_YUfromsimu,bounds_error=False,fill_value=1.)

#Oct 18
_Xfromsimu =  [-1.000,  1.000,  1.001,  1.200,  1.300,  1.301,  1.400,  1.600,  1.800,  2.000,  2.200,  2.400,  8.000]
_YLfromsimu = [ 0.000,  0.000, -5.000, -3.700, -3.200, -3.200, -2.800, -2.100, -1.650, -1.400, -1.300, -1.300, -1.300]
_YUfromsimu = [ 0.000,  0.000,  0.000,  0.000,  0.000, -1.500, -1.230, -0.950, -0.750, -0.650, -0.500, -0.500, -0.500]
ClassifyCurveL = interp1d(_Xfromsimu,_YLfromsimu,bounds_error=False,fill_value=1.)
ClassifyCurveU = interp1d(_Xfromsimu,_YUfromsimu,bounds_error=False,fill_value=1.)

#Nov 1
_Xfromsimu =  [ 0.1, 5.00, 5.00,  10.00,  15.00,  15.00,  20.00,  25.00,  40.00,  60.00,  100.0,  160.,   250.,   1e+08]
_YLfromsimu = [ 1. , 1.  , 1e-5,   1e-5,   1e-4,   1e-4,   5e-4, 1.5e-3,   8e-3,   2e-2,  4e-02,  5e-02,  5e-02,  5e-02]
_YUfromsimu = [ 1. , 1.  , 1.  ,   1.  ,   1.  ,   0.03,   0.05,   0.07,   0.12,   0.18,   0.24,    0.3,  0.3,  0.3]
ClassifyCurveL = interp1d(log10(_Xfromsimu),log10(_YLfromsimu),bounds_error=False,fill_value=1.)
ClassifyCurveU = interp1d(log10(_Xfromsimu),log10(_YUfromsimu),bounds_error=False,fill_value=1.)

#Feb 02 2014
_Xfromsimu =  [ 0.1, 5.00, 5.00,  10.00,  15.00,  15.00,  20.00,  25.00,  40.00,  60.00,  100.0,  160.,   250.,   1e+08]
_YLfromsimu = [ 1. , 1.  , 1e-4,   1e-4,   1e-4,   1e-4,   5e-4, 1.5e-3,   8e-3,   2e-2,  4e-02,  5e-02,  5e-02,  5e-02]
_YUfromsimu = [ 1. , 1.  , 1.  ,   1.  ,   1.  ,   0.03,   0.05,   0.07,   0.12,   0.18,   0.24,    0.3,  0.3,  0.3]
ClassifyCurveL = interp1d(log10(_Xfromsimu),log10(_YLfromsimu),bounds_error=False,fill_value=1.)
ClassifyCurveU = interp1d(log10(_Xfromsimu),log10(_YUfromsimu),bounds_error=False,fill_value=1.)

#Feb 04 2014
_Xfromsimu =  [ 0.1, 5.00, 5.00,  10.00,  15.00,  15.00,  20.00,  25.00,  40.00,  60.00,  100.0,  160.,   250.,   1e+08]
_YLfromsimu = [ 1. , 1.  , 1e-4,   1e-4,   1e-4,   1e-4,   5e-4, 1.5e-3,   6e-3,  1e-02,  1e-02,  1e-02,  1e-02,  1e-02]
_YUfromsimu = [ 1. , 1.  , 1.  ,   1.  ,   1.  ,   0.03,   0.05,   0.07,   0.12,   0.18,   0.24,    0.3,  0.3,  0.3]
ClassifyCurveL = interp1d(log10(_Xfromsimu),log10(_YLfromsimu),bounds_error=False,fill_value=1.)
ClassifyCurveU = interp1d(log10(_Xfromsimu),log10(_YUfromsimu),bounds_error=False,fill_value=1.)

#Feb 04 2014
_Xfromsimu =  [ 0.1, 5.00, 5.00,  10.00,  15.00,  15.00,  20.00,  25.00,  40.00,  60.00,  100.0,  160.,   250.,   1e+08]
_YLfromsimu = [ 1. , 1.  , 1e-4,   1e-4,   1e-4,   1e-4,   5e-4, 1.5e-3,   6e-3,  1e-02,  1e-02,  1e-02,  1e-02,  1e-02]
_YUfromsimu = [ 1. , 1.  , 1.  ,   1.  ,   0.05,   0.05,   0.07,   0.09,   0.13,   0.18,   0.24,    0.3,  0.3,  0.3]
ClassifyCurveL = interp1d(log10(_Xfromsimu),log10(_YLfromsimu),bounds_error=False,fill_value=1.)
ClassifyCurveU = interp1d(log10(_Xfromsimu),log10(_YUfromsimu),bounds_error=False,fill_value=1.)

if True and False:
	new_Xfromsimu =  [ 0.1, 5.00, 5.00,  10.00,  15.00,  15.00,  20.00,  25.00,  40.00,  60.00,  100.0,  160.,   250.,   1e+08]
	new_YLfromsimu = [ 1. , 1.  , 1e-4,   1e-4,   1e-4,   1e-4,   5e-4, 1.5e-3,   6e-3,  1e-02,  1e-02,  1e-02,  1e-02,  1e-02]
	new_YUfromsimu = [ 1. , 1.  , 1.  ,   1.  ,   0.05,   0.05,   0.07,   0.09,   0.13,   0.18,   0.24,    0.3,  0.3,  0.3]
	ClassifyCurveL = interp1d(log10(new_Xfromsimu),log10(new_YLfromsimu),bounds_error=False,fill_value=1.)
	ClassifyCurveU = interp1d(log10(new_Xfromsimu),log10(new_YUfromsimu),bounds_error=False,fill_value=1.)

if __name__ == '__main__':
	import pylab as pl
	import numpy as np

	if True and False:
		S=np.loadtxt('spu')
		R=np.loadtxt('rec')
		pl.plot(S[:,4],-S[:,9],'bo')
		pl.plot(R[:,4],-R[:,9],'rs')

	pl.plot(np.array(_Xfromsimu),np.array(_YLfromsimu),'r-',lw=2)
	pl.plot(np.array(_Xfromsimu),np.array(_YUfromsimu),'b-',lw=2)
	if 'new_Xfromsimu' in locals():
		pl.plot(new_Xfromsimu,new_YLfromsimu,'m--',label='NewL')
		pl.plot(new_Xfromsimu,new_YUfromsimu,'c--',label='NewU')
		newClassifyCurveL = interp1d(new_Xfromsimu,new_YLfromsimu,bounds_error=False,fill_value=1.)
		newClassifyCurveU = interp1d(new_Xfromsimu,new_YUfromsimu,bounds_error=False,fill_value=1.)
		pl.legend(loc='lower right')
	pl.xlabel('S/N in core region',fontsize='x-large')
	pl.ylabel('1 - KS probability',fontsize='x-large')
	#xticks,tmp=pl.xticks()
	yticks,tmp=pl.yticks()
	#pl.yticks(yticks.tolist(),["$10^{%d}$" % x for x in yticks])
	pl.loglog()
	_Xfromsimu.pop(-1)
	pl.xticks(_Xfromsimu,["%d" % x for x in _Xfromsimu])
	pl.xlim(3,300)
	pl.ylim(1e-6,1)
	pl.setp(pl.gca().get_xticklabels(),fontsize='x-large')
	pl.setp(pl.gca().get_yticklabels(),fontsize='x-large')
	pl.subplots_adjust(bottom=0.12,top=0.91,left=0.13,right=0.92)
	pl.show()
