#!/usr/bin/env python
################################################################################
#1. center optimization should not vary much
#2. weighted median is good for bright isolated source
#3. do weighted mean inside a small circle to avoid affection of nearby sources
#4. jointing sources bias their position towards each other
#5. a method: check if inside the circle thers is other brghter source, in such case do no variation
################################################################################
#EXSdetect
#Extended X-ray Source Detection
#Refer to our paper for details
#
#Copyright (C) 2011 Teng Liu
#
#This program is free software: you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#Teng Liu's email: lewtonstein@gmail.com
################################################################################
import sys, getopt, warnings, re
grep = lambda string,slist: filter(re.compile(string).search, slist)
CIAO_PYTHON = grep('ciao',sys.path)
for tmp in CIAO_PYTHON: sys.path.remove(tmp)
import profile
for tmp in CIAO_PYTHON: sys.path.append(tmp)

from EXSdetect_SrcList import SrcList
from EXSdetect_DET import DET
from EXSdetect_PSF import PSF
################################################################################
def main():
	color = lambda s,ncolor,nfont: "\033["+str(nfont)+";"+str(ncolor)+"m"+s+"\033[0;0m"
	Str2Bool = lambda string: string.lower() in ("yes", "y", "true", "t", "1")
	import numpy as np
	import pyfits as pf
	import os,cPickle,time
	import SweepLine
	from glob import glob
	from EXSdetect_Parameters import Version,debug,developing,specialtry,OutFile,Instrument,CoreRad,Bkg,ExpMap,MinExp,OtherImage,ReCalculate,PixNum2CalCenter,CtrLevel,CtrScals,PixSize,InputExtSrc,InputPntSrc,SepExt,ReliProbLowr,FillEmptyHoles,ModiExtSrc,OptimizeCore,ExtLowDist,ExtSepLevel,OverFlowLevel,FRTF,BkgNstep,BkgRadius,BkgRegion,MaxFitIteration,MinCoreCts,General,LinkingScale,MinAreaSeparated
	DET.Version=Version
	DET.debug=debug
	DET.developing=developing
	PSF.debug=debug
	DET.General=General
	DEToptions=dict()

	def usage():
		try:
			pipe = os.popen('more -R 2>/dev/null', 'w')
			s = file(os.path.dirname(sys.argv[0])+'/EXSdetect_Manual.txt','r').read()
			pipe.write(s)
			assert pipe.close() is None
		except IOError:
			pass # Ignore broken pipes caused by quitting the pager program
		except:
			try:
				pipe = os.popen('more ', 'w')
				s = file(os.path.dirname(sys.argv[0])+'/EXSdetect_Manual.txt','r').read()
				pipe.write(s)
				assert pipe.close() is None
			except IOError:
				pass # Ignore broken pipes caused by quitting the pager program
			except:
				print 'The \"more\" command failed'
		exit()

	if developing:
		f=file('run.log','a')
		print >>f,time.strftime('%y-%b-%d %H:%M:%S',time.localtime())
		for arg in sys.argv:
			print >>f,arg,
		print >>f
		f.close()
	S_opt = "l:b:c:s:m:e:o:p:i:hdR"
	L_opt = ["general","instrument=","linkscale=","bkg=","contourlevel=","contourscales=","minsourcedist","expmap=","other=","psf=","pixelsize=","coreradius=","sepext=","modiext=","BkgRadius=","BkgRegion=","BkgNstep=","CutLines=","InputPntSrc=","InputExtSrc=","debug","dev","help"]
	opts,args=getopt.getopt(sys.argv[1:],S_opt,L_opt)
	if len(args)>0:
		for arg in args:
			if os.path.isfile(arg):
				ImageFile=arg
				sys.argv.remove(arg)
				break
		opts,args=getopt.getopt(sys.argv[1:],S_opt,L_opt)
	for opt,arg in opts:
		if opt == "-h" or opt == "--help":
			usage()
	if len(args)>0: sys.exit("I don't understand"+str(args))
	if 'ImageFile' not in locals():
		print "Please specify one image!\n"
		usage()

	for opt,arg in opts:
		if opt == "-l" or opt == "--linkscale":
			LinkingScale = float(arg)
			print color("The Linking Scale to use in FOF: %.2g" % (LinkingScale),34,1)
		elif opt == "-i" or opt == "--instrument":
			Instrument=arg.upper()
		elif opt == "-R":
			ReCalculate=True
		elif opt == "-p" or opt == "--pixelsize":
			PixSize = np.float32(arg)
		elif opt == "--coreradius":
			assert arg.isdigit()
			CoreRad = np.int32(arg)
		elif opt == "-s" or opt == "--contourscales":
			CtrScals = map(float,arg.split(','))
			CtrScals.sort()
			print color("The Deblending Threshold Searal: ",34,1),
			for t in CtrScals: print " %.2f" %(t),
			if CtrScals[0]<=0: sys.exit('ERROR: Threshold should >0!')
			print
		elif opt == "-e" or opt == "--expmap":
			if os.path.isfile(arg):
				ExpMap = arg
				print color("Using the Exposure map:",34,1),ExpMap
			else: sys.exit("ERROR: No Such Exposure Map File:",34,1),arg
		elif opt == "-b" or opt == "--bkg":
			#if arg.replace('.','0').isdigit():
			try:
				Bkg = np.float32(arg) #type 'numpy.float32', which has the attribute min()
				print color("The average Background count in each Pixel:",34,1),Bkg
				if Bkg<=0: sys.exit("ERROR: Background <= 0")
			except:
				if os.path.isfile(arg): Bkg = arg
		elif opt == "-c" or opt == "--contourlevel":
			if arg.isdigit():
				CtrLevel = int(arg)
				print color("The deblending Contour Level:",34,1),CtrLevel
			else: sys.exit('ERROR: --contourlevel %s is not a number' %(arg))
		elif opt == "--psf":
			if arg.isdigit():
				MinSDist = int(arg)
				print color("The minimum source distance:",34,1),MinSDist
			else: sys.exit('ERROR: -p '+arg+' is not a number!')
		elif opt == "-o" or opt == "--outfile":
			OutFile = arg
		elif opt == "-d" or opt == "--debug":
			debug=True
			developing = True
			DET.debug=True
			DET.developing = True
			PSF.debug=True
		elif opt == "--BkgRegion":
			if os.path.isfile(arg):
				BkgRegion = arg
				print color("The region to measure background is defined in file:",34,1),BkgRegion
			else: sys.exit('ERROR: '+arg+' is not a file!')
		elif opt == "--InputExtSrc":
			if os.path.isfile(arg):
				InputExtSrc = arg
				print color("Some already known extended sources in file:",34,1),InputExtSrc
			else: sys.exit('ERROR: '+arg+' is not a file!')
		elif opt == "--InputPntSrc":
			if os.path.isfile(arg):
				InputPntSrc = arg
				print color("Some already known point sources in file:",34,1),InputPntSrc
			else: sys.exit('ERROR: '+arg+' is not a file!')
		elif opt == "--BkgRadius":
			if arg.isdigit():
				BkgRadius = int(arg)
				print color("The radius to measure background:",34,1),BkgRadius
			else: sys.exit('ERROR: '+arg+' is not a number!')
		elif opt == "--sepext":
			SepExt = Str2Bool(arg)
		elif opt == "--CutLines":
			CutLines = arg
		elif opt == "--BkgNstep":
			BkgNstep = int(arg)
		elif opt == "--modiext":
			ModiExtSrc = Str2Bool(arg)
		elif opt == "--general":
			DET.General = True
		elif opt == "--dev":
			developing = True
			DET.developing = True
	optlocals=locals()
	for opt in ('Bkg','MinCoreCts','CtrLevel','InputExtSrc','InputPntSrc','SepExt','ReliProbLowr','FillEmptyHoles','BkgNstep','MinExp','ModiExtSrc','OptimizeCore','ExtLowDist','ExtSepLevel','OverFlowLevel','PixNum2CalCenter','OutFile','FRTF','BkgRadius','BkgRegion','MaxFitIteration','CutLines','MinAreaSeparated'):
		if opt in optlocals.keys(): DEToptions[opt] = optlocals[opt]
	DEToptions['BkgMap'] = None
	DEToptions['SrcList'] = SrcList()
	DEToptions['LnkScal2'] = LinkingScale**2

	if not DET.General:
		if Instrument is None:
			Instrument = pf.getheader(ImageFile).get('TELESCOP',None)
			if Instrument is None:
				sys.exit('ERROR: No TELESCOP keywork found, please specify an instrument.')
			else:
				Instrument=Instrument.upper()
			if debug: print 'Instrument:',Instrument

		if Instrument=='SWIFT':
			if CoreRad is None: CoreRad = 5
			if specialtry: CoreRad = 3
			psf = PSF(Instrument=Instrument,CoreRadius=CoreRad)
			if specialtry: import EXSdetect_Boundary_Swift_sharp as EXSdetect_Boundary_Swift
			else: import EXSdetect_Boundary_Swift
			SrcList.CD = EXSdetect_Boundary_Swift
		elif Instrument=='WFXT':
			if CoreRad is None: CoreRad = 3
			if PixSize == 0:
				PixSize = abs(np.float32(pf.getheader(ImageFile).get('CDELT1')))*3600 #in unit of arcsec
				if round(PixSize,8)!=round(abs(np.float32(pf.getheader(ImageFile).get('CDELT2'))*3600),8):
					sys.exit('ERROR: why CDELT1!=CDELT2 in the header')
			if PixSize == 0:
				sys.exit('ERROR: Can not find CDELT1 key from the header, please specify --pixelsize')
			psf = PSF(Instrument=Instrument,CoreRadius=CoreRad,PixSize=PixSize)
		elif Instrument=='CHANDRA':
			import CurveDef_CHANDRA
			SrcList.CD = CurveDef_CHANDRA
			if CoreRad is None: CoreRad = 5
			psf = PSF(Instrument=Instrument,CoreRadius=CoreRad,ImageFile=ImageFile)
		else:
			sys.exit('ERROR: Unrecogonized instrument %s' %(Instrument))
		DEToptions['PSF'] = psf

	if True:
		img = pf.getdata(ImageFile)
		if not DET.General and img.dtype.type not in (np.int8,np.int16,np.int32,np.int64):
			sys.exit('ERROR: '+ImageFile+' :the image should contain photon count, which must be integer!')
		img = np.float32(img)
		DEToptions['Hdr'] = pf.getheader(ImageFile)
		if ExpMap is None:
			g = glob('sum*.exp')
			if len(g)==1:
				ExpMap = g[0]
				print color("Using the Exposure map:",34,1),ExpMap
				exp = np.float32(pf.getdata(ExpMap))
				img[exp<=0] = 0
				del exp
			else:
				if not DET.General: print 'Warning: No Exposure ExpMap',g
		else:
			exp = np.float32(pf.getdata(ExpMap))
			img[exp<=0] = 0
			del exp

		FileName = ImageFile.rsplit('.',1)[0]
		DEToptions['FileName'] = FileName
		VorFile=glob('Vor'+FileName+'.npz')
		if len(VorFile)==1 and os.path.isfile(VorFile[0]):
			VorFile = VorFile[0]
			print color("Using "+VorFile,34,1)
			'''
			v=np.load(VorFile)
			pf.writeto('Vpmap.fits',v['vmap'],clobber=True)
			pf.writeto('VAmap.fits',v['Amap'],clobber=True)
			exit()
			'''
		else:
			VorFile = 'Vor'+FileName+'.npz'
			v = SweepLine.Voronoi(img,FileName=FileName,caldvd=True,calarea=True,caladj=False,caldst=True)
			np.savez('Vor'+FileName, vmap = np.int32(v.pmap), Amap = np.float32(v.Amap), dmap = np.float32(v.dmap),
				Esid = np.int32([[e.p0[0],e.p0[1],e.p1[0],e.p1[1]] for e in v.Edges.values()]),
				Eend = np.float32([[e.base[1],e.base[0],e.summit[1],e.summit[0]] for e in v.Edges.values()])+1,
				PPdis = np.float32(v.PPdis),
				EgPt = np.int32(v.EdgePoint))
			del v
		DEToptions['VorFile'] = VorFile

		if os.path.isfile('src.dat') and os.path.isfile('det.dat') and os.path.isfile('psf.dat') and True:
			print color("<< "+'det.dat src.dat psf.dat',34,1)
			#function object can not be pickled
			d=cPickle.load(file('det.dat','r'))
			d.src=cPickle.load(file('src.dat','r'))
			d.src=d.src.view(SrcList)
			d.PSF=cPickle.load(file('psf.dat','r'))
			if d.PSF.Instrum=='CHANDRA':
				from ciao_contrib.runtool import calquiz
				import psf as ChandraPSF
				d.PSF.ChandraPSF = ChandraPSF
				calquiz(telescope="CHANDRA", product="REEF")
				d.PSF.ChandraPData = d.PSF.ChandraPSF.psfInit(calquiz.outfile)
			d.TmpFile_read()
			if specialtry: import EXSdetect_Boundary_Swift_sharp as EXSdetect_Boundary_Swift
			else: import EXSdetect_Boundary_Swift
			SrcList.CD = EXSdetect_Boundary_Swift
		else:
			d= DET(img,ExpMap,**DEToptions)
			d.exsdetect1()
			if developing: d.savetime()
		#exit()

		d.exsdetect2()

if __name__=="__main__":
	main()
	#profile.run('main()')
	exit()

