############################################################
OutFile='EXS'
#higher priority given to "-o / --outfile" option
############################################################
Instrument = None
#by default, get the 'TELESCOP' key in the fits header
#higher priority given to "-i / --instrument" option
############################################################
CoreRad = None
#by default, 5 for Swift-XRT, 3 for Chandra
#higher priority given to "--coreradius" option
############################################################
Bkg = None
'''
Three types of acceptable values:
A. None	Build background map with default method.
B. float	Background map = Exposure map * Bkg
C. string	Background map = Exposure map * Average value inside the region as defined in the file Bkg
Higher priority given to -b/--bkg option
'''
############################################################
ExpMap = None
############################################################
Version='14.09.01.00'
MinCoreCts=20
debug=False
developing=False
specialtry=False
OtherImage = None
ReCalculate = False
PixNum2CalCenter=27
CtrLevel = 10
CtrScals = (0.5,1.5,5.7,22,88)
PixSize = 0
ModiExtSrc = True
SepExt = False
MinExp = 2000
OptimizeCore = True
#ExtLowDist suggested 5-100
ExtLowDist = 10
#ExtSepLevel suggested 1-30
ExtSepLevel = 2
#OverFlowLevel suggested: 1-20  depends on bkg map
#Number of pixels PSF overflowing FoF
#the higher OverFlowLevel, the more extended sources
OverFlowLevel = 7
FRTF = 0.8
BkgNstep = None
#The background fitting may fail because at the image border, stacking of multiple exposures can make the exposure time distribution in one exposure time bin very non-uniform (having two typical values maybe), thus the CPD can be significantly different from the empirical formula. In this case, manually enlarge the BkgNstep to have thinner exposure time bins may be helpful.
BkgRadius = None
BkgRegion = None
MaxFitIteration = 100
InputPntSrc = None
InputExtSrc = None
General=False
LinkingScale = 2
FillEmptyHoles = False
ReliProbLowr = 12
MinAreaSeparated = 3
