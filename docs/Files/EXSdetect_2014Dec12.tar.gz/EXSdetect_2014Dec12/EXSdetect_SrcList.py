import numpy as np
import EXSdetect_Boundary_Swift
class SrcList(np.ndarray):
	Ncol = 10
	debug = False
	CD = EXSdetect_Boundary_Swift
	def __new__(subtype, input_array=None):
		if input_array is None:
			return np.zeros((1,10),dtype='float32').view(subtype) #data[0] useless
		obj = np.asarray(input_array).view(subtype)
		#Fill in the attributes of a new object created by the explicit constructor: SrcList()
		array = obj.__array__()
		#help: __array__(...)
		#a.__array__(|dtype) -> reference if type unchanged, copy otherwise.
		#Returns either a new reference to self if dtype is not given or a new array
		#of provided data type if dtype is different from the current dtype of the array.
		if array.ndim==2:
			obj.Nsrc = array.shape[0]
			obj.Numb = array[:,0]
			obj.Ncts = array[:,1]
			obj.Ccts = array[:,2]
			obj.Area = array[:,3]
			obj.val4 = array[:,4]
			obj.Prob = array[:,5]
			obj.ImgX = array[:,6]
			obj.ImgY = array[:,7]
			obj.Type = array[:,8]
			obj.SExp = array[:,9]
		return obj
		#Ccts,val4,Type: core_count, val4, KS_Null_probability
		#ImgX,ImgY image coordinates, not in Fortran style (ds9)
	#END_OF___new__
	def __repr__(self):
		return str(self.Nsrc)+'\n'+str(self)
	def __array_finalize__(self, obj):
		#Entry 1: New object created by the explicit constructor: SrcList()
		#The attributes will be filled after returning to __new__()
		if obj is None: return
		#Entry 2,3, from .view() method ...
		#Get the attributes of self from obj
		if obj.ndim==2 and obj.shape[1]==SrcList.Ncol:
			array = obj.__array__()
			self.Nsrc = array.shape[0] # number of sources +1
			self.Numb = array[:,0]
			self.Ncts = array[:,1]
			self.Ccts = array[:,2]
			self.Area = array[:,3]
			self.val4 = array[:,4]
			self.Prob = array[:,5]
			self.ImgX = array[:,6]
			self.ImgY = array[:,7]
			self.Type = array[:,8]
			self.SExp = array[:,9]
		#Problem: src[:2] ok; src[[1,2]] wrong
		#Maybe because for simple slicing, we get a view; while for advanced slicing we get a copy
		#the obj in simplie slicing case is the result, while in advanced case it's the original object
		#So we have to do .view() for advanced slicing
	#END_OF___array_finalize__
	def extend(self,Nmin,Nmax):
		if SrcList.debug: print 'New Sources from %d to %d' %(Nmin,Nmax)
		if np.any(self.Numb!=np.arange(Nmin)):
			sys.exit('ERROR: src number error')
		src = np.zeros((Nmax-Nmin+1,SrcList.Ncol),dtype=self.dtype)
		src[:,0] = np.arange(Nmin,Nmax+1)
		return np.vstack((self.__array__(),src)).view(SrcList)
	#END_OF__extend
	def __array_wrap__(self, obj, context=None):
		#obj is the result of an "ufunc"
		if obj.ndim==2 and obj.shape[1]==SrcList.Ncol and obj.dtype is self.dtype: return obj.view(type(self))
		else: return obj.__array__()
	#END_OF___array_wrap__

	def BeExtended(self,N=None):
		if N is None: N = range(self.Nsrc)
		return self.Type[N] <= 10**SrcList.CD.ClassifyCurveL(np.log10(self.val4[N])) #it's OK if val4==0

	def MaybeExtended(self,N=None):
		if N is None: N = range(self.Nsrc)
		return self.Type[N] <= 10**SrcList.CD.ClassifyCurveU(np.log10(self.val4[N]))
#END_OF_class SrcList
