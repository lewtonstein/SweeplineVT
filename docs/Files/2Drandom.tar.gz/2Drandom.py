#!/usr/bin/env python
import numpy as np
import pylab as pl

def ComputeTriangleArea(A, B, C):
	return abs(np.cross(B - A, B - C)) / 2.0

def IsPointInTriangle(A, B, C, P):
	area_abc = ComputeTriangleArea(A, B, C)
	area_pab = ComputeTriangleArea(A, B, P)
	area_pbc = ComputeTriangleArea(P, B, C)
	area_pac = ComputeTriangleArea(P, A, C)
	return round(area_pab+area_pac+area_pbc-area_abc,7)==0

def ComputeCentralSymmetryPoint(src, center):
	return np.array([center[0]*2-src[0], center[1]*2-src[1]])

def RandomInTriangle(A, B, C, N=1, ToPlot=False):
	#Select AB as the longest edge
	ABdAB=(A[0]-B[0])**2+(A[1]-B[1])**2 #dot product (length**2)
	ACdAC=(A[0]-C[0])**2+(A[1]-C[1])**2
	BCdBC=(B[0]-C[0])**2+(B[1]-C[1])**2
	if ABdAB<ACdAC and BCdBC<=ACdAC:
		B,C=C,B
		ABdAB=(A[0]-B[0])**2+(A[1]-B[1])**2
		ACdAC=(A[0]-C[0])**2+(A[1]-C[1])**2
	elif ABdAB<BCdBC and ACdAC<=BCdBC:
		A,C=C,A
		ABdAB=(A[0]-B[0])**2+(A[1]-B[1])**2
		BCdBC=(B[0]-C[0])**2+(B[1]-C[1])**2
	if ToPlot:
		pl.plot([A[0],B[0]], [A[1],B[1]])
		pl.plot([A[0],C[0]], [A[1],C[1]])
		pl.plot([B[0],C[0]], [B[1],C[1]])
	#print 'Points',A,B,C
	ACdAB=(A[0]-C[0])*(A[0]-B[0])+(A[1]-C[1])*(A[1]-B[1])
	Len1 = np.sqrt(ABdAB)
	Len2 = np.cross(A-B,A-C)/Len1 #cross produce (area) / AB
	Proj = ACdAB/ABdAB
	#print 'Len1:',Len1,'Len2:',Len2,'Proj:',Proj
	Points=[]
	for i in range(N):
		r1,r2 = np.random.random(size=2)
		P = np.array([r1*(B[0]-A[0])-r2*Len2/Len1*(B[1]-A[1])+A[0],r1*(B[1]-A[1])+r2*Len2/Len1*(B[0]-A[0])+A[1]])
		if not IsPointInTriangle(A, B, C, P):
			if r1<Proj: #Aside
				#pl.plot(P[0], P[1], "g.")
				P = ComputeCentralSymmetryPoint(P, np.array([(C[0] + A[0])/2., (C[1] + A[1])/2.]))
				#pl.plot(P[0], P[1], "b.")
			else:
				#pl.plot(P[0], P[1], "m.")
				P = ComputeCentralSymmetryPoint(P, np.array([(C[0] + B[0])/2., (C[1] + B[1])/2.]))
				#pl.plot(P[0], P[1], "r.")
		if ToPlot: pl.plot(P[0], P[1], "k.")
		Points.append(P)
	return Points

def Usage():
	print """2Drandom.py inputfile [number] [output] [--border xlow,xhigh,ylow,yhigh]

	inputfile: 2D data in the first two columns
	number: default 100
	output: file name can not be a number
	--border xlow,xhigh,ylow,yhigh: Set image border. Any one of the four can be empty.
	"""
	exit()
if __name__=='__main__':
	import SweepLine,sys
	from scipy import interpolate

	Nsim=100
	if sys.argv[1]=='-h' or sys.argv[1]=='--help': Usage()
	InputFile=sys.argv[1]
	OutFile=InputFile.rsplit('.',1)[0]+'_2Drandom.dat'
	border={}
	n=2
	while n<len(sys.argv):
		argv = sys.argv[n]
		if argv == '--border':
			try:
				n+=1
				arg = sys.argv[n].split(',')
				assert len(arg)==4
				if arg[0]!='': border['xlow']=float(arg[0])
				if arg[1]!='': border['xhigh']=float(arg[1])
				if arg[2]!='': border['ylow']=float(arg[2])
				if arg[3]!='': border['yhigh']=float(arg[3])
			except:
				print 'ERROR: --border',arg
				exit()
		elif argv.isdigit(): Nsim=int(argv)
		else: OutFile=argv
		n+=1
	#END_OF_while n<len(sys.argv):

	SweepLine.Voronoi(events=np.loadtxt(InputFile),FileName=InputFile.rsplit('.',1)[0],calTriangle=True,border=border,RemoveEdgePoint=True)
	
	ToPlot=True
	ToPlot=False
	d=np.loadtxt(InputFile.rsplit('.',1)[0]+'_Triangles.dat')
	if d.ndim==1: d=d.reshape((1,d.size))
	A=d[:,0:2]
	B=d[:,2:4]
	C=d[:,4:6]
	W=d[:,7]
	
	rand2index=interpolate.interp1d(np.hstack((0,W.cumsum()/np.sum(W))),np.arange(len(W)+1))
	rand01=np.random.random_sample(size=Nsim)
	ind = np.int32(rand2index(rand01))
	if np.__version__>='1.9.0':
		Ni,Nn = np.unique(ind,return_counts=True)
	else:
		Ni = np.unique(ind)
		Nn = [np.sum(ind==n) for n in Ni]
	outrand=[]
	for n in range(len(Ni)): outrand.extend(RandomInTriangle(A[Ni[n]],B[Ni[n]],C[Ni[n]],N=Nn[n],ToPlot=ToPlot))
	outrand=np.array(outrand)
	np.savetxt(OutFile,outrand,fmt="%f")
	print "%d random points saved in %s" % (Nsim,OutFile)
	
	if ToPlot:
		#pl.axes().set_aspect('equal')
		pl.show()
